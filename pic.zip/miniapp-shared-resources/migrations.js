(function () {
  'use strict';

  // eslint-disable-next-line
  // @ts-nocheck

  // eslint-disable-next-line @typescript-eslint/ban-types
  function asyncPipeline() {
    for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
      fns[_key] = arguments[_key];
    }
    return arg => {
      return fns.reduce((acc, fn) => {
        return acc.then(fn);
      }, Promise.resolve(arg));
    };
  }

  // NOTE: This simply updates the version of the data to the one provided.
  function updateVersion(version) {
    return options => {
      return {
        ...options,
        currentVersion: version
      };
    };
  }
  function migrate(options, opts) {
    let fns = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    /* If we are already at the target version, return the data as is.
     * AKA stop the migration to the target version.
     * eg. if we wanted to migrate to v3 and we're there, we don't need to migrate to v3.
     * if we don't update the version to a higher one, next migrations will ignore
     * the data, leaving us with the desired version.
     */
    if (options.currentVersion === options.targetVersion) {
      return options;
    }

    /* If the migration does not match the version of the data, return the data as is.
     * AKA skip applying migrations if data does not match the version we're looking for.
     * eg if the data is at version 1, and the migration is v2->v3, skip.
     * read the note above to see a the use case for this.
     */
    if (options.currentVersion !== opts.migrateFrom) {
      return options;
    }
    return asyncPipeline(...fns, updateVersion(opts.migrateTo))(options);
  }

  let count = 0;
  const generateId = () => String(new Date().getTime() + count++);

  const createResource = (mediaUrl, type) => {
    const id = generateId();
    return {
      id,
      resource: {
        id,
        source: 'picsart',
        location: mediaUrl,
        type
      }
    };
  };

  let V4SendMessage = /*#__PURE__*/function (V4SendMessage) {
    V4SendMessage["select"] = "select";
    V4SendMessage["apply"] = "apply-res";
    return V4SendMessage;
  }({});
  let V4ReceiveMessage = /*#__PURE__*/function (V4ReceiveMessage) {
    V4ReceiveMessage["apply"] = "apply";
    V4ReceiveMessage["configs"] = "configs";
    V4ReceiveMessage["interaction"] = "interaction";
    V4ReceiveMessage["bootstrapEditing"] = "bootstrap-editing";
    V4ReceiveMessage["bootstrapContent"] = "bootstrap-content";
    V4ReceiveMessage["bootstrapPublishing"] = "bootstrap-publishing";
    return V4ReceiveMessage;
  }({});

  let V5ReceiveMessages = /*#__PURE__*/function (V5ReceiveMessages) {
    V5ReceiveMessages["openFileChooserResponse"] = "chooser-res";
    V5ReceiveMessages["refreshTokenResponse"] = "refresh-token-res";
    V5ReceiveMessages["remoteSettingsResponse"] = "remote-settings-res";
    V5ReceiveMessages["fetchAlbumsResponse"] = "fetch-media-albums-res";
    V5ReceiveMessages["fetchMediaAssetsResponse"] = "fetch-media-assets-res";
    V5ReceiveMessages["requestPermissionResponse"] = "request-permission-res";
    V5ReceiveMessages["generateResultImageResponse"] = "generate-result-image-res";
    return V5ReceiveMessages;
  }({});

  const searchParams = new URLSearchParams(window.location.search);
  const platformQuery = searchParams.get('platform');
  searchParams.get('child') === 'true';

  const normalizedUserAgent = window.navigator.userAgent.toLowerCase();
  const isAndroidDevice = /android/.test(normalizedUserAgent);
  const isAndroid = () => isAndroidDevice && /; wv\)/.test(normalizedUserAgent) && window.top === window.self;
  const isWindows = () => {
    var _window;
    return !!((_window = window) !== null && _window !== void 0 && (_window = _window.chrome) !== null && _window !== void 0 && _window.webview);
  };
  const isIOS = () => {
    var _window$webkit;
    return !!((_window$webkit = window['webkit']) !== null && _window$webkit !== void 0 && _window$webkit.messageHandlers.bridge) && window.top === window.self;
  };
  const isAndroidProtocol$1 = () => platformQuery === 'android' || isAndroid();
  const isWindowsProtocol = () => platformQuery === 'windows' || isWindows();
  const isIOSProtocol$1 = () => platformQuery === 'ios' || isIOS();
  const isWebProtocol = () => platformQuery === 'web';

  let ReceiveMessages = /*#__PURE__*/function (ReceiveMessages) {
    ReceiveMessages["close"] = "close";
    ReceiveMessages["resume"] = "resume";
    ReceiveMessages["bootstrap"] = "bootstrap";
    ReceiveMessages["deactivate"] = "deactivate";
    ReceiveMessages["gotoAction"] = "goto-action";
    ReceiveMessages["syncContext"] = "sync-context";
    ReceiveMessages["syncRequest"] = "sync-request";
    ReceiveMessages["customEvent"] = "custom-event";
    ReceiveMessages["redirectResponse"] = "redirect-res";
    ReceiveMessages["resolveMessage"] = "resolve-message";
    ReceiveMessages["visibilityChanged"] = "visibility-changed";
    return ReceiveMessages;
  }({});

  const onEvent = eventName => (_ref, cb) => {
    var _eventListeners$get;
    let {
      receiveEventListeners: eventListeners
    } = _ref;
    if (!eventListeners.has(eventName)) {
      eventListeners.set(eventName, new Set());
    }
    (_eventListeners$get = eventListeners.get(eventName)) === null || _eventListeners$get === void 0 || _eventListeners$get.add(cb);
    return () => {
      var _eventListeners$get2;
      (_eventListeners$get2 = eventListeners.get(eventName)) === null || _eventListeners$get2 === void 0 || _eventListeners$get2.delete(cb);
    };
  };
  onEvent(ReceiveMessages.bootstrap);
  onEvent(ReceiveMessages.resolveMessage);
  onEvent(ReceiveMessages.redirectResponse);
  onEvent(ReceiveMessages.close);
  onEvent(ReceiveMessages.syncContext);
  onEvent(ReceiveMessages.customEvent);
  onEvent(ReceiveMessages.deactivate);
  onEvent(ReceiveMessages.resume);
  onEvent(ReceiveMessages.syncRequest);
  onEvent(ReceiveMessages.gotoAction);
  onEvent(ReceiveMessages.visibilityChanged);

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  const noop = () => {};

  let SendMessages = /*#__PURE__*/function (SendMessages) {
    SendMessages["error"] = "error";
    SendMessages["share"] = "share";
    SendMessages["ready"] = "ready";
    SendMessages["dialog"] = "dialog";
    SendMessages["close"] = "close-res";
    SendMessages["overlay"] = "overlay";
    SendMessages["notifier"] = "notifier";
    SendMessages["redirect"] = "redirect";
    SendMessages["navigate"] = "navigate";
    SendMessages["analytics"] = "analytics";
    SendMessages["download"] = "download";
    SendMessages["downloadFile"] = "export";
    SendMessages["saveState"] = "save-state";
    SendMessages["openFileChooser"] = "chooser";
    SendMessages["configureUi"] = "configure-ui";
    SendMessages["syncContext"] = "sync-context";
    SendMessages["refreshToken"] = "refresh-token";
    SendMessages["customEvent"] = "custom-event-res";
    SendMessages["resolveMessage"] = "resolve-message";
    SendMessages["zoomIntoLayers"] = "zoom-into-layers";
    SendMessages["fetchAlbums"] = "fetch-media-albums";
    SendMessages["getRemoteSettings"] = "remote-settings";
    SendMessages["fetchMediaAssets"] = "fetch-media-assets";
    SendMessages["requestPermission"] = "request-permission";
    SendMessages["showOverlay"] = "show-overlay";
    SendMessages["generateResultVideo"] = "generate-result-video";
    SendMessages["redirectToPackageId"] = "redirect-to-package-id";
    SendMessages["generateResultImage"] = "generate-result-image";
    SendMessages["calculateTextLayerSizes"] = "calculate-text-layer-sizes";
    SendMessages["requestPlatformBootstrap"] = "request-platform-bootstrap";
    SendMessages["forwardToParent"] = "forward-to-parent";
    SendMessages["refreshMonetizationData"] = "refresh-monetization-data";
    SendMessages["getPulseTrackingState"] = "get-pulse-tracking-state";
    SendMessages["drag"] = "drag";
    return SendMessages;
  }({});

  [SendMessages.dialog, SendMessages.share, SendMessages.download, SendMessages.openFileChooser, SendMessages.fetchAlbums, SendMessages.fetchMediaAssets, SendMessages.requestPermission, SendMessages.forwardToParent, SendMessages.drag];

  const SUPPORTED_TRANSFERABLE_TYPES = [ImageBitmap];
  const isTransferable = payload => {
    return SUPPORTED_TRANSFERABLE_TYPES.some(type => payload instanceof type);
  };
  const extractTransferables = function (payload) {
    let visited = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : new Set();
    const transferables = [];
    if (payload == null || typeof payload !== 'object' || visited.has(payload)) {
      return transferables;
    }
    visited.add(payload);
    if (isTransferable(payload)) return [payload];
    for (const value of Object.values(payload)) {
      if (value && typeof value === 'object') {
        transferables.push(...extractTransferables(value, visited));
      }
    }
    return transferables;
  };
  const getTransferableObjects = message => {
    if (!message) return [];
    return extractTransferables(message.payload);
  };

  function sendToWeb(data, transferables) {
    return window.parent.postMessage(data, '*', transferables);
  }

  const sendToIos = data => window['webkit'].messageHandlers.bridge.postMessage(data);

  const sendToWindows = data => window.chrome.webview.postMessage(data);

  const channel = new MessageChannel();
  let nativeJsPortTwo = channel.port2;
  channel.port1;
  const androidResolvePromise = new Promise(resolve => {
  });

  const sendToAndroid = async data => {
    await androidResolvePromise;
    nativeJsPortTwo.postMessage(data);
  };

  const sendToEmbeddedWeb = (data, contextOptions) => {
    var _contextOptions$pubsu;
    (_contextOptions$pubsu = contextOptions.pubsub) === null || _contextOptions$pubsu === void 0 || _contextOptions$pubsu.publishToPlatform(data);
  };

  const handleWebProtocol = message => {
    const transferableObjects = getTransferableObjects(message);
    transferableObjects.length === 0 ? sendToWeb(JSON.stringify(message)) : sendToWeb(message, transferableObjects);
  };
  const sendMessageStringToPlatform = async (message, contextOptions) => {
    if (contextOptions.isEmbeddedWebProtocol) return sendToEmbeddedWeb(message, contextOptions);
    if (isWebProtocol()) return handleWebProtocol(message);
    if (isIOSProtocol$1()) return sendToIos(JSON.stringify(message));
    if (isWindowsProtocol()) return sendToWindows(JSON.stringify(message));
    if (isAndroidProtocol$1()) return sendToAndroid(JSON.stringify(message));
    return sendToWeb(JSON.stringify(message));
  };

  const isBootstrapAction = data => data.action === ReceiveMessages.bootstrap;
  const isConfirmAction = data => data.action === SendMessages.syncContext;
  const isResolveMessageAction = data => data.action === ReceiveMessages.resolveMessage;
  const isGetRemoteSettingsAction = data => data.action === SendMessages.getRemoteSettings;
  const isRefreshTokenAction = data => data.action === SendMessages.refreshToken;
  const isFetchAlbumsAction = data => data.action === SendMessages.fetchAlbums;
  const isFetchMediaAssetsAction = data => data.action === SendMessages.fetchMediaAssets;
  const isRequestPermissionAction = data => data.action === SendMessages.requestPermission;
  const isGenerateResultImageAction = data => data.action === SendMessages.generateResultImage;
  const isOpenFileChooserAction = data => data.action === SendMessages.openFileChooser;
  const isStickerLayerData = data => data.type === 'sticker';
  const isReceiveFileChooserResponseAction = data => data.action === V5ReceiveMessages.openFileChooserResponse;
  const isExportFilesAction = data => data.action === SendMessages.downloadFile;
  const isSendDialogMessageAction = data => data.action === SendMessages.dialog;
  const isShowNotifierMessageAction = data => data.action === SendMessages.notifier;
  const isOldConfirmAction = data => data.action === V4SendMessage.apply || data.action === V4SendMessage.select;
  const isResolvableAction = data => typeof data.resolveId === 'string';
  const isGenerateResultImageResponseAction = data => data.action === V5ReceiveMessages.generateResultImageResponse;
  const isOpenFileChooserResponseAction = data => data.action === V5ReceiveMessages.openFileChooserResponse;
  const isSyncContextAction = data => data.action === SendMessages.syncContext;
  const isDownloadFileAction = data => data.action === SendMessages.downloadFile;
  const isConfigureUIAction = data => data.action === SendMessages.configureUi;
  const isRedirectToPackageIdAction = data => data.action === SendMessages.redirectToPackageId;

  const imageUrlToResource = options => {
    const {
      data
    } = options;
    if (isConfirmAction(data)) {
      var _data$payload$images;
      const resources = {};
      (_data$payload$images = data.payload.images) === null || _data$payload$images === void 0 || _data$payload$images.forEach(_ref => {
        var _data$payload$resourc;
        let {
          layer
        } = _ref;
        if ((_data$payload$resourc = data.payload.resources) !== null && _data$payload$resourc !== void 0 && _data$payload$resourc[layer.url]) return;
        const {
          id,
          resource
        } = createResource(layer.url, 'photo');
        resources[id] = resource;
        layer.url = id;
      });
      data.payload.resources = {
        ...data.payload.resources,
        ...resources
      };
    }
    return options;
  };

  const resourceToImageUrl = options => {
    const {
      data
    } = options;
    if (isBootstrapAction(data) || isReceiveFileChooserResponseAction(data) || isConfirmAction(data)) {
      var _data$payload$images;
      (_data$payload$images = data.payload.images) === null || _data$payload$images === void 0 || _data$payload$images.forEach(_ref => {
        var _data$payload$resourc;
        let {
          layer
        } = _ref;
        layer.url = ((_data$payload$resourc = data.payload.resources) === null || _data$payload$resourc === void 0 ? void 0 : _data$payload$resourc[layer.url].location) || '';
      });
      delete data.payload.resources;
    }
    return options;
  };

  const storeKeys$6 = {
    bootstrapPayload: 'v5BootstrapPayload'
  };

  const getMiniappPackageIdAndVersion = options => {
    var _options$contextOptio, _options$data$payload, _options$contextOptio2;
    const miniapp = (_options$contextOptio = options.contextOptions) === null || _options$contextOptio === void 0 ? void 0 : _options$contextOptio.internalContext.miniapp;
    const miniappFromPayload = (_options$data$payload = options.data.payload) === null || _options$data$payload === void 0 ? void 0 : _options$data$payload.miniapp;

    // NOTE:: we need to fake the 'contextOptions' object cause the migration script will run for the older
    // versions of the SDK and the 'contextOptions' object will not be provided.

    if (miniappFromPayload && (_options$contextOptio2 = options.contextOptions) !== null && _options$contextOptio2 !== void 0 && _options$contextOptio2.fakeContext) {
      options.contextOptions.internalContext = options.contextOptions.internalContext || {};
      options.contextOptions.internalContext.miniapp = miniappFromPayload;
    }
    return {
      miniappPackageId: (miniapp === null || miniapp === void 0 ? void 0 : miniapp.packageId) || (miniappFromPayload === null || miniappFromPayload === void 0 ? void 0 : miniappFromPayload.packageId),
      miniappVersion: (miniapp === null || miniapp === void 0 ? void 0 : miniapp.appVersion) || (miniappFromPayload === null || miniappFromPayload === void 0 ? void 0 : miniappFromPayload.appVersion)
    };
  };

  const typeMap = new Map([['Content', V4ReceiveMessage.bootstrapContent], ['Edit', V4ReceiveMessage.bootstrapEditing], ['Publish', V4ReceiveMessage.bootstrapPublishing]]);
  const receiveMessages$8 = options => {
    const needToStorePayload = isBootstrapAction(options.data) || isConfirmAction(options.data);
    const {
      data: {
        payload
      }
    } = options;
    if (isBootstrapAction(options.data)) {
      var _options$data$payload;
      const changeTheVersion = Number(((_options$data$payload = options.data.payload.platformVersion) === null || _options$data$payload === void 0 ? void 0 : _options$data$payload.split('v')[1]) || 0) < 6;
      options.data.payload = {
        ...options.data.payload,
        platformVersion: changeTheVersion ? 'v5' : options.data.payload.platformVersion,
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: changeTheVersion ? 'v5-v4' : options.data.payload.version
      };
      options.data.action = typeMap.get(payload.miniapp.extensions[0].type);
    }
    if (isConfirmAction(options.data)) {
      options.data.action = V4ReceiveMessage.configs;
    }
    if (needToStorePayload) {
      const {
        miniappVersion,
        miniappPackageId
      } = getMiniappPackageIdAndVersion(options);
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: options.data.payload,
        key: storeKeys$6.bootstrapPayload
      });
    }
    return options;
  };

  const sendMessages = options => {
    const {
      miniappPackageId,
      miniappVersion
    } = getMiniappPackageIdAndVersion(options);
    const currentPayload = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$6.bootstrapPayload
    });
    const {
      data
    } = options;
    if (isOldConfirmAction(data)) {
      var _data$payload$images, _data$payload$texts;
      const image = (_data$payload$images = data.payload.images) === null || _data$payload$images === void 0 ? void 0 : _data$payload$images[0];
      const text = (_data$payload$texts = data.payload.texts) === null || _data$payload$texts === void 0 ? void 0 : _data$payload$texts[0];
      const selectedLayerId =
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      data.action === DeprecatedSendMessage.apply ? currentPayload.selectedLayerIds[0] : generateId();
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      if (image) {
        image.layer.id = image.layer.id || selectedLayerId;
      }
      if (text) {
        text.layer.id = text.layer.id || selectedLayerId;
      }
      data.payload.selectedLayerIds = [...currentPayload.selectedLayerIds];
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      if (data.action === DeprecatedSendMessage.select) {
        data.payload.images = [...currentPayload.images];
        data.payload.texts = [...currentPayload.texts];
        if (image) {
          data.payload.images.push(image);
        }
        if (text) {
          data.payload.texts.push(text);
        }
      } else {
        data.payload.images = currentPayload.images.map(item => {
          if (image && item.layer.id === (image === null || image === void 0 ? void 0 : image.layer.id)) return {
            ...image,
            ...item,
            layer: {
              ...item.layer,
              ...image.layer
            }
          };
          return item;
        });
        data.payload.texts = currentPayload.texts.map(item => {
          if (text && item.layer.id === (text === null || text === void 0 ? void 0 : text.layer.id)) return {
            ...text,
            ...item,
            layer: {
              ...item.layer,
              ...text.layer
            }
          };
          return item;
        });
      }
      data.payload.videos = [];
      data.action = SendMessages.syncContext;
    }
    return options;
  };

  const exportFiles$1 = options => {
    if (isExportFilesAction(options.data)) {
      options.data.payload = {
        ...options.data.payload,
        ...(options.data.payload.images || []).reduce((acc, image) => {
          const {
            id,
            resource
          } = createResource(image.layer.url, 'photo');
          acc.images.push({
            ...image,
            layer: {
              ...image.layer,
              url: id
            }
          });
          acc.resources[id] = resource;
          return acc;
        }, {
          images: [],
          resources: {}
        })
      };
    }
    return options;
  };

  const isServerSupported = () => isIOS() || isAndroid() || isWindows();

  const receiveProtocols = ['http://', 'https://'];
  const sendProtocols = ['http://', 'https://', 'blob:', 'data:'];
  const useLocalServer = (url, from) => (from ? receiveProtocols : sendProtocols).every(protocol => !url.startsWith(protocol)) && isServerSupported();
  const canStoredInLocalServer = url => isServerSupported() && sendProtocols.some(protocol => url.startsWith(protocol));

  const getExtension = mimeType => mimeType.split('/')[1];

  // NOTE:: here we are scheduling the out-coming requests, cause there is a limit of browser open tcp count
  // and all the parallel requests coming here must be put into schedule per threshold(maybe configured per browser).
  // The scheduler will try to pick more requests as far as the cycle provides any resolved promise
  const tcpLimit = 6;
  const scheduledQueue = [];
  const activeQueue = [];
  const schedulerCheck = () => {
    if (activeQueue.length <= tcpLimit && scheduledQueue.length) {
      const next = scheduledQueue.shift();
      if (next) {
        const promise = next();
        activeQueue.push(promise);
        promise.then(() => {
          activeQueue.splice(activeQueue.indexOf(promise), 1);
          schedulerCheck();
        });
      }
    }
  };
  const withScheduler = executor => {
    return function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      return new Promise((resolve, reject) => {
        scheduledQueue.push(async () => {
          try {
            const result = await executor(...args);
            resolve(result);
          } catch (err) {
            reject(err);
          }
        });
        schedulerCheck();
      });
    };
  };

  const baseUrl = 'https://localhost:4000';
  const fileQuery = 'file';

  const setImage = async (filename, file) => {
    const formData = new FormData();
    formData.append('image', file, filename);
    const response = await fetch("".concat(baseUrl, "/storage"), {
      method: 'POST',
      body: formData
    });
    return response.ok;
  };
  var setImage$1 = withScheduler(setImage);

  const createLocalServerUrl = url => "".concat(baseUrl, "/storage?").concat(fileQuery, "=").concat(url);
  const getImageUrl = function (url) {
    let from = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return useLocalServer(url, from) ? createLocalServerUrl(url) : url;
  };

  const urlToLocalServer = async url => {
    return fetch(url).then(resp => resp.blob()).then(async blob => {
      const filename = "".concat(generateId(), ".").concat(getExtension(blob.type));
      await setImage$1(filename, blob);
      return filename;
    });
  };
  const absoluteUrlToLocalServer = async options => {
    const {
      data
    } = options;
    if (isBootstrapAction(data)) {
      await Promise.all((data.payload.images || []).map(image => {
        const {
          layer
        } = image;
        const promises = [];
        if (canStoredInLocalServer(layer.url)) {
          promises.push(urlToLocalServer(layer.url).then(localUrl => layer.url === localUrl));
        }
        if (layer.maskUrl && canStoredInLocalServer(layer.maskUrl)) {
          promises.push(urlToLocalServer(layer.maskUrl).then(localUrl => layer.maskUrl === localUrl));
        }
        return Promise.all(promises);
      }));
    }
    return options;
  };

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV4ToV5Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v4',
      migrateTo: 'v5'
    }, [sendMessages, exportFiles$1, imageUrlToResource]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV5ToV4Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v5',
      migrateTo: 'v4'
    }, [resourceToImageUrl, absoluteUrlToLocalServer, receiveMessages$8]);
  }

  const defaultPoint = {
    x: 0.5,
    y: 0.5
  };
  const defaultFlipped = {
    horizontal: false,
    vertical: false
  };
  const defaultTransform = {
    position: defaultPoint,
    rotation: 0,
    scale: 1,
    aspect_scale: 1,
    scale_type: 'fit',
    flipped: defaultFlipped,
    position_space: 'self'
  };
  const defaultPattern = {
    opacity: 0
  };
  const defaultMask = {
    manual: false,
    inverted: false,
    shapes: []
  };
  const defaultStroke = {
    pattern: defaultPattern,
    width: 0,
    linecap: 'butt',
    linejoin: 'round'
  };
  const defaultImageLayerParams = {
    photo: '',
    transform: defaultTransform,
    opacity: 100,
    blendmode: 'normal',
    stroke: defaultStroke
  };
  const defaultStickerParams = {
    sticker: '',
    transform: defaultTransform,
    opacity: 100,
    blendmode: 'normal',
    stroke: defaultStroke
  };
  const defaultTextLayerParams = {
    text: '',
    lines: [],
    alignment: 'center',
    letter_spacing: 1,
    line_spacing: 1,
    bend: 0,
    fill: defaultPattern,
    opacity: 100,
    transform: defaultTransform,
    blendmode: 'normal',
    format: [],
    perspective_points: []
  };

  const storeKeys$5 = {
    bootstrapPayload: 'v6BootstrapPayload'
  };

  function isV5Sticker(image, currentPayload) {
    if (currentPayload.stickers) {
      return currentPayload.stickers.some(sticker => sticker.uuid === image.layer.id);
    } else {
      return false;
    }
  }
  function toReplayV2(options) {
    var _options$data$payload, _options$data$payload2, _options$data$payload3, _options$data$payload5;
    if (!isConfirmAction(options.data)) return options;
    const {
      miniappPackageId,
      miniappVersion
    } = getMiniappPackageIdAndVersion(options);
    const currentPayload = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$5.bootstrapPayload
    });
    const images = [];
    const stickers = [];
    (_options$data$payload = options.data.payload.images) === null || _options$data$payload === void 0 || _options$data$payload.forEach(image => {
      const isSticker = isV5Sticker(image, currentPayload);
      if (isSticker) {
        var _currentPayload$stick, _existingLayer$settin, _existingLayer$settin2;
        const existingLayer = (_currentPayload$stick = currentPayload.stickers) === null || _currentPayload$stick === void 0 ? void 0 : _currentPayload$stick.find(_ref => {
          let {
            uuid
          } = _ref;
          return uuid === image.layer.id;
        });
        const haveChanges = (existingLayer === null || existingLayer === void 0 || (_existingLayer$settin = existingLayer.settings) === null || _existingLayer$settin === void 0 ? void 0 : _existingLayer$settin.sticker) !== image.layer.url || (existingLayer === null || existingLayer === void 0 || (_existingLayer$settin2 = existingLayer.settings) === null || _existingLayer$settin2 === void 0 || (_existingLayer$settin2 = _existingLayer$settin2.mask) === null || _existingLayer$settin2 === void 0 ? void 0 : _existingLayer$settin2.mask) !== image.layer.maskUrl;
        stickers.push({
          uuid: image.layer.id,
          type: 'sticker',
          settings: {
            ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.settings) || defaultStickerParams),
            sticker: image.layer.url,
            mask: {
              ...defaultMask,
              mask: image.layer.maskUrl
            }
          },
          meta: {
            ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.meta) || {}),
            ...(haveChanges && {
              miniappPackageId: currentPayload.miniapp.packageId
            })
          }
        });
      } else {
        var _currentPayload$image, _existingLayer$settin3, _existingLayer$settin4;
        const existingLayer = (_currentPayload$image = currentPayload.images) === null || _currentPayload$image === void 0 ? void 0 : _currentPayload$image.find(_ref2 => {
          let {
            uuid
          } = _ref2;
          return uuid === image.layer.id;
        });
        const haveChanges = (existingLayer === null || existingLayer === void 0 || (_existingLayer$settin3 = existingLayer.settings) === null || _existingLayer$settin3 === void 0 ? void 0 : _existingLayer$settin3.photo) !== image.layer.url || (existingLayer === null || existingLayer === void 0 || (_existingLayer$settin4 = existingLayer.settings) === null || _existingLayer$settin4 === void 0 || (_existingLayer$settin4 = _existingLayer$settin4.mask) === null || _existingLayer$settin4 === void 0 ? void 0 : _existingLayer$settin4.mask) !== image.layer.maskUrl;
        images.push({
          uuid: image.layer.id,
          type: 'photo',
          settings: {
            ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.settings) || defaultImageLayerParams),
            photo: image.layer.url,
            mask: {
              ...defaultMask,
              mask: image.layer.maskUrl
            }
          },
          meta: {
            ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.meta) || {}),
            ...(haveChanges && {
              miniappPackageId: currentPayload.miniapp.packageId
            })
          }
        });
      }
    });
    const texts = (_options$data$payload2 = options.data.payload.texts) === null || _options$data$payload2 === void 0 ? void 0 : _options$data$payload2.map(text => {
      var _currentPayload$texts, _exitingLayer$setting, _exitingLayer$setting2;
      const exitingLayer = (_currentPayload$texts = currentPayload.texts) === null || _currentPayload$texts === void 0 ? void 0 : _currentPayload$texts.find(_ref3 => {
        let {
          uuid
        } = _ref3;
        return uuid === text.layer.id;
      });
      const hasTextLayerChanged = (exitingLayer === null || exitingLayer === void 0 || (_exitingLayer$setting = exitingLayer.settings) === null || _exitingLayer$setting === void 0 ? void 0 : _exitingLayer$setting.text) !== text.layer.text || (exitingLayer === null || exitingLayer === void 0 || (_exitingLayer$setting2 = exitingLayer.settings) === null || _exitingLayer$setting2 === void 0 ? void 0 : _exitingLayer$setting2.font) !== text.layer.font;
      return {
        uuid: text.layer.id,
        type: 'text',
        meta: {
          ...((exitingLayer === null || exitingLayer === void 0 ? void 0 : exitingLayer.meta) || {}),
          ...(hasTextLayerChanged && {
            miniappPackageId: currentPayload.miniapp.packageId
          })
        },
        settings: {
          ...((exitingLayer === null || exitingLayer === void 0 ? void 0 : exitingLayer.settings) || defaultTextLayerParams),
          text: text.layer.text,
          font: text.layer.font
        }
      };
    });
    (_options$data$payload3 = options.data.payload.texts) === null || _options$data$payload3 === void 0 || _options$data$payload3.forEach(text => {
      var _options$data$payload4;
      const resourceId = text.layer.font || '';
      const resource = (_options$data$payload4 = options.data.payload.resources) === null || _options$data$payload4 === void 0 ? void 0 : _options$data$payload4[resourceId];
      if (resource) {
        resource.type = 'font';
      }
    });
    (_options$data$payload5 = options.data.payload.images) === null || _options$data$payload5 === void 0 || _options$data$payload5.forEach(image => {
      var _options$data$payload6;
      const resourceId = image.layer.url || '';
      const resource = (_options$data$payload6 = options.data.payload.resources) === null || _options$data$payload6 === void 0 ? void 0 : _options$data$payload6[resourceId];
      if (resource) {
        resource.type = 'photo';
      }
    });
    Object.values(options.data.payload.resources || {}).forEach(resource => {
      resource.type = resource.type || '';
    });
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.images = images;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.texts = texts;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.stickers = stickers;
    // NOTE:: this is required for keeping the shape of the payload
    options.data.payload.resources = options.data.payload.resources || {};
    options.data.payload.selectedLayerIds = options.data.payload.selectedLayerIds || [];
    options.data.payload.shapes = options.data.payload.shapes || [];
    options.data.payload.videos = options.data.payload.videos || [];
    return options;
  }

  // V5 miniapps SDK code uses mime type to determine the extension of the image while uploading to local server
  // it means without this code snippet, the image will be uploaded with .jpeg extension
  const getImageMimeType = (image, options) => {
    const resourceId = isStickerLayerData(image) ? image.settings.sticker : image.settings.photo;
    const resources = options.data.payload.resources;
    if (resources && resources[resourceId] && resources[resourceId].location) {
      const location = resources[resourceId].location;
      const extension = location.split('.').pop();

      // only two types of image were supported
      if ((extension === null || extension === void 0 ? void 0 : extension.toLocaleLowerCase()) === 'png') {
        return 'image/png';
      } else {
        return 'image/jpeg';
      }
    }
    return 'image/jpeg';
  };

  function fromReplayV2(options) {
    var _ref, _options$data$payload;
    const images = (_ref = [...(options.data.payload.images || []), ...(options.data.payload.stickers || [])]) === null || _ref === void 0 ? void 0 : _ref.map(image => {
      var _image$settings$mask;
      const result = {
        layer: {
          id: image.uuid,
          url: isStickerLayerData(image) ? image.settings.sticker : image.settings.photo
        },
        mimeType: getImageMimeType(image, options)
      };
      if ((_image$settings$mask = image.settings.mask) !== null && _image$settings$mask !== void 0 && _image$settings$mask.mask) {
        result.layer.maskUrl = image.settings.mask.mask;
      }
      return result;
    });
    const texts = (_options$data$payload = options.data.payload.texts) === null || _options$data$payload === void 0 ? void 0 : _options$data$payload.map(text => {
      return {
        layer: {
          text: text.settings.text,
          font: text.settings.font,
          id: text.uuid,
          fontFamily: ''
        },
        mimeType: 'text/plain'
      };
    });
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.images = images;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.texts = texts;
    return options;
  }

  function fileChooserMaxCount(options) {
    if (options.data.action === SendMessages.openFileChooser) {
      options.data.payload.maxCount = options.data.payload.multiSelectEnabled ? 10 : 1;
    }
    return options;
  }

  function receiveMessages$7(options) {
    const needToStorePayload = isBootstrapAction(options.data) || isConfirmAction(options.data);
    if (isBootstrapAction(options.data)) {
      // NOTE: this needed only for v4, should be removed with v5-v4 migrations
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v6',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v6-v5'
      };
    }
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    if (needToStorePayload) {
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: {
          ...(options.getPayloadPerMiniapp({
            packageId: miniappPackageId,
            version: miniappVersion,
            key: storeKeys$5.bootstrapPayload
          }) || {}),
          ...JSON.parse(JSON.stringify(options.data.payload))
        },
        key: storeKeys$5.bootstrapPayload
      });
    }
    options.data.payload = {
      ...(options.getPayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        key: storeKeys$5.bootstrapPayload
      }) || {}),
      ...options.data.payload
    };
    return options;
  }

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV5ToV6Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v5',
      migrateTo: 'v6'
    }, [fileChooserMaxCount, toReplayV2]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV6ToV5Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v6',
      migrateTo: 'v5'
    }, [receiveMessages$7, fromReplayV2]);
  }

  const storeKeys$4 = {
    bootstrapPayload: 'v7BootstrapPayload'
  };

  function receiveMessages$6(options) {
    const needToStorePayload = isBootstrapAction(options.data) || isConfirmAction(options.data);
    if (isBootstrapAction(options.data)) {
      // NOTE: this needed only for v4, should be removed with v5-v4 migrations
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v7',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v7-v6'
      };
    }
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    if (needToStorePayload) {
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: {
          ...(options.getPayloadPerMiniapp({
            packageId: miniappPackageId,
            version: miniappVersion,
            key: storeKeys$4.bootstrapPayload
          }) || {}),
          ...JSON.parse(JSON.stringify(options.data.payload))
        },
        key: storeKeys$4.bootstrapPayload
      });
    }
    options.data.payload = {
      ...(options.getPayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        key: storeKeys$4.bootstrapPayload
      }) || {}),
      ...options.data.payload
    };
    return options;
  }

  function fromReplayV2Video(options) {
    var _ref;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    options.data.payload.videos = (_ref = options.data.payload.videos || []) === null || _ref === void 0 ? void 0 : _ref.map(video => {
      return {
        ...video,
        settings: {
          ...video.settings,
          url: video.settings.video
        },
        mimeType: 'video/mp4'
      };
    });
    return options;
  }

  const defaultVideoLayerParams = {
    video: '',
    transform: defaultTransform,
    blendmode: 'normal',
    visible: true,
    start_time: 0,
    duration: -1,
    trim_start: 0,
    trim_end: -1,
    volume: 100
  };

  function toReplayV2Video(options) {
    var _options$data$payload;
    if (!isConfirmAction(options.data)) return options;
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const currentPayload = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$4.bootstrapPayload
    });
    const videos = [];
    (_options$data$payload = options.data.payload.videos) === null || _options$data$payload === void 0 || _options$data$payload.forEach(video => {
      var _currentPayload$video, _existingLayer$settin;
      const existingLayer = (_currentPayload$video = currentPayload.videos) === null || _currentPayload$video === void 0 ? void 0 : _currentPayload$video.find(_ref => {
        let {
          uuid
        } = _ref;
        return uuid === video.uuid;
      });
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const haveChanges = (existingLayer === null || existingLayer === void 0 || (_existingLayer$settin = existingLayer.settings) === null || _existingLayer$settin === void 0 ? void 0 : _existingLayer$settin.video) !== video.settings.url;
      videos.push({
        ...video,
        settings: {
          ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.settings) || defaultVideoLayerParams),
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          video: video.settings.url
        },
        meta: {
          ...((existingLayer === null || existingLayer === void 0 ? void 0 : existingLayer.meta) || {}),
          ...(haveChanges && {
            miniappPackageId: currentPayload.miniapp.packageId
          })
        }
      });
    });
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          ...options.data.payload,
          videos
        }
      }
    };
  }

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV6ToV7Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v6',
      migrateTo: 'v7'
    }, [toReplayV2Video]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV7ToV6Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v7',
      migrateTo: 'v6'
    }, [receiveMessages$6, fromReplayV2Video]);
  }

  function generateResultImageResponse(options) {
    if (!isGenerateResultImageResponseAction(options.data)) return options;
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          ...options.data.payload,
          location: getImageUrl(options.data.payload.resource.location),
          type: options.data.payload.resource.type,
          id: options.data.payload.resource.id,
          source: 'user_generated'
        }
      }
    };
  }

  const storeKeys$3 = {
    bootstrapPayload: 'v8BootstrapPayload',
    dialogResolveIds: 'v8DialogResolveIds'
  };

  function receiveMessages$5(options) {
    const needToStorePayload = isBootstrapAction(options.data) || isConfirmAction(options.data);
    if (isBootstrapAction(options.data)) {
      // NOTE: this needed only for v4, should be removed with v5-v4 migrations
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v8',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v8-v7'
      };
    }
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    if (needToStorePayload) {
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: {
          ...(options.getPayloadPerMiniapp({
            packageId: miniappPackageId,
            version: miniappVersion,
            key: storeKeys$3.bootstrapPayload
          }) || {}),
          ...JSON.parse(JSON.stringify(options.data.payload))
        },
        key: storeKeys$3.bootstrapPayload
      });
    }
    //TODO do not update payload with full context
    // options.data.payload = {
    // ...(options.getPayloadPerMiniapp({
    //     packageId: miniappPackageId,
    //     version: miniappVersion,
    //     key: storeKeys.bootstrapPayload,
    //   }) || {}),
    //   ...options.data.payload,
    // };

    // Automatically respond to unsupported resolvable messages.
    if (isResolvableAction(options.data)) {
      sendMessageStringToPlatform({
        action: SendMessages.resolveMessage,
        resolveId: options.data.resolveId,
        payload: {},
        sid: options.data.sid
      }, options.contextOptions);
    }
    return options;
  }

  function exportFiles(options) {
    if (!isExportFilesAction(options.data)) return options;
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          layers: Object.values(options.data.payload.resources || {}).map(resource => ({
            props: {
              image: {
                value: {
                  location: resource.location
                }
              }
            },
            uuid: resource.id,
            type: 'image',
            name: 'photo',
            locked: false,
            mediaType: 'photo',
            renderer: {
              packageId: 'system.image',
              version: '1.0.0'
            },
            meta: {}
          }))
        }
      }
    };
  }

  function sendDialogMessage(options) {
    if (!isSendDialogMessageAction(options.data)) return options;
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const dialogResolveIds = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$3.dialogResolveIds
    }) || [];
    options.storePayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      payload: [...dialogResolveIds, options.data.resolveId],
      key: storeKeys$3.dialogResolveIds
    });
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          title: options.data.payload.title,
          description: options.data.payload.description,
          primaryText: options.data.payload.buttons[0].text,
          secondaryText: options.data.payload.buttons[1].text
        }
      }
    };
  }

  var e$2 = Symbol.for("immer-nothing"),
    t$2 = Symbol.for("immer-draftable"),
    r$2 = Symbol.for("immer-state");
  function a$1(e) {
    throw new Error("[Immer] minified error nr: ".concat(e, ". Full error at: https://bit.ly/3cXEKWf"));
  }
  var o$2 = Object.getPrototypeOf;
  function i$2(e) {
    return !!e && !!e[r$2];
  }
  function s$2(e) {
    var _e$constructor;
    return !!e && (u$2(e) || Array.isArray(e) || !!e[t$2] || !!((_e$constructor = e.constructor) !== null && _e$constructor !== void 0 && _e$constructor[t$2]) || y$2(e) || m$2(e));
  }
  var c$2 = Object.prototype.constructor.toString();
  function u$2(e) {
    if (!e || "object" != typeof e) return !1;
    const t = o$2(e);
    if (null === t) return !0;
    const r = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
    return r === Object || "function" == typeof r && Function.toString.call(r) === c$2;
  }
  function d$2(e, t) {
    0 === l$2(e) ? Object.entries(e).forEach(_ref => {
      let [r, n] = _ref;
      t(r, n, e);
    }) : e.forEach((r, n) => t(n, r, e));
  }
  function l$2(e) {
    const t = e[r$2];
    return t ? t.type_ : Array.isArray(e) ? 1 : y$2(e) ? 2 : m$2(e) ? 3 : 0;
  }
  function p$2(e, t) {
    return 2 === l$2(e) ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t);
  }
  function f$2(e, t, r) {
    const n = l$2(e);
    2 === n ? e.set(t, r) : 3 === n ? e.add(r) : e[t] = r;
  }
  function y$2(e) {
    return e instanceof Map;
  }
  function m$2(e) {
    return e instanceof Set;
  }
  function h$2(e) {
    return e.copy_ || e.base_;
  }
  function _$2(e, t) {
    if (y$2(e)) return new Map(e);
    if (m$2(e)) return new Set(e);
    if (Array.isArray(e)) return Array.prototype.slice.call(e);
    if (!t && u$2(e)) {
      if (!o$2(e)) {
        const t = Object.create(null);
        return Object.assign(t, e);
      }
      return {
        ...e
      };
    }
    const n = Object.getOwnPropertyDescriptors(e);
    delete n[r$2];
    let a = Reflect.ownKeys(n);
    for (let t = 0; t < a.length; t++) {
      const r = a[t],
        o = n[r];
      !1 === o.writable && (o.writable = !0, o.configurable = !0), (o.get || o.set) && (n[r] = {
        configurable: !0,
        writable: !0,
        enumerable: o.enumerable,
        value: e[r]
      });
    }
    return Object.create(o$2(e), n);
  }
  function b$2(e) {
    let t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    return g$2(e) || i$2(e) || !s$2(e) || (l$2(e) > 1 && (e.set = e.add = e.clear = e.delete = v$2), Object.freeze(e), t && d$2(e, (e, t) => b$2(t, !0))), e;
  }
  function v$2() {
    a$1(2);
  }
  function g$2(e) {
    return Object.isFrozen(e);
  }
  var w$2,
    x$2 = {};
  function k$2(e) {
    const t = x$2[e];
    return t || a$1(0), t;
  }
  function O$2() {
    return w$2;
  }
  function S$2(e, t) {
    t && (k$2("Patches"), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
  }
  function P$2(e) {
    T$2(e), e.drafts_.forEach(E$2), e.drafts_ = null;
  }
  function T$2(e) {
    e === w$2 && (w$2 = e.parent_);
  }
  function j$2(e) {
    return w$2 = {
      drafts_: [],
      parent_: w$2,
      immer_: e,
      canAutoFreeze_: !0,
      unfinalizedDrafts_: 0
    };
  }
  function E$2(e) {
    const t = e[r$2];
    0 === t.type_ || 1 === t.type_ ? t.revoke_() : t.revoked_ = !0;
  }
  function D$2(t, n) {
    n.unfinalizedDrafts_ = n.drafts_.length;
    const o = n.drafts_[0];
    return void 0 !== t && t !== o ? (o[r$2].modified_ && (P$2(n), a$1(4)), s$2(t) && (t = z$2(n, t), n.parent_ || M$2(n, t)), n.patches_ && k$2("Patches").generateReplacementPatches_(o[r$2].base_, t, n.patches_, n.inversePatches_)) : t = z$2(n, o, []), P$2(n), n.patches_ && n.patchListener_(n.patches_, n.inversePatches_), t !== e$2 ? t : void 0;
  }
  function z$2(e, t, n) {
    if (g$2(t)) return t;
    const a = t[r$2];
    if (!a) return d$2(t, (r, o) => I$2(e, a, t, r, o, n)), t;
    if (a.scope_ !== e) return t;
    if (!a.modified_) return M$2(e, a.base_, !0), a.base_;
    if (!a.finalized_) {
      a.finalized_ = !0, a.scope_.unfinalizedDrafts_--;
      const t = a.copy_;
      let r = t,
        o = !1;
      3 === a.type_ && (r = new Set(t), t.clear(), o = !0), d$2(r, (r, i) => I$2(e, a, t, r, i, n, o)), M$2(e, t, !1), n && e.patches_ && k$2("Patches").generatePatches_(a, n, e.patches_, e.inversePatches_);
    }
    return a.copy_;
  }
  function I$2(e, t, r, n, o, c, u) {
    if (i$2(o)) {
      const a = z$2(e, o, c && t && 3 !== t.type_ && !p$2(t.assigned_, n) ? c.concat(n) : void 0);
      if (f$2(r, n, a), !i$2(a)) return;
      e.canAutoFreeze_ = !1;
    } else u && r.add(o);
    if (s$2(o) && !g$2(o)) {
      if (!e.immer_.autoFreeze_ && e.unfinalizedDrafts_ < 1) return;
      z$2(e, o), t && t.scope_.parent_ || M$2(e, o);
    }
  }
  function M$2(e, t) {
    let r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
    !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && b$2(t, r);
  }
  var N$2 = {
      get(e, t) {
        if (t === r$2) return e;
        const n = h$2(e);
        if (!p$2(n, t)) return function (e, t, r, _n$get) {
          const n = L$2(t, r);
          return n ? "value" in n ? n.value : (_n$get = n.get) === null || _n$get === void 0 ? void 0 : _n$get.call(e.draft_) : void 0;
        }(e, n, t);
        const a = n[t];
        return e.finalized_ || !s$2(a) ? a : a === A$2(e.base_, t) ? (U$2(e), e.copy_[t] = Y$2(a, e)) : a;
      },
      has: (e, t) => t in h$2(e),
      ownKeys: e => Reflect.ownKeys(h$2(e)),
      set(e, t, n) {
        const a = L$2(h$2(e), t);
        if (a !== null && a !== void 0 && a.set) return a.set.call(e.draft_, n), !0;
        if (!e.modified_) {
          const a = A$2(h$2(e), t),
            s = a === null || a === void 0 ? void 0 : a[r$2];
          if (s && s.base_ === n) return e.copy_[t] = n, e.assigned_[t] = !1, !0;
          if (((o = n) === (i = a) ? 0 !== o || 1 / o == 1 / i : o != o && i != i) && (void 0 !== n || p$2(e.base_, t))) return !0;
          U$2(e), X$2(e);
        }
        var o, i;
        return e.copy_[t] === n && (void 0 !== n || t in e.copy_) || Number.isNaN(n) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = n, e.assigned_[t] = !0), !0;
      },
      deleteProperty: (e, t) => (void 0 !== A$2(e.base_, t) || t in e.base_ ? (e.assigned_[t] = !1, U$2(e), X$2(e)) : delete e.assigned_[t], e.copy_ && delete e.copy_[t], !0),
      getOwnPropertyDescriptor(e, t) {
        const r = h$2(e),
          n = Reflect.getOwnPropertyDescriptor(r, t);
        return n ? {
          writable: !0,
          configurable: 1 !== e.type_ || "length" !== t,
          enumerable: n.enumerable,
          value: r[t]
        } : n;
      },
      defineProperty() {
        a$1(11);
      },
      getPrototypeOf: e => o$2(e.base_),
      setPrototypeOf() {
        a$1(12);
      }
    },
    F$2 = {};
  function A$2(e, t) {
    const n = e[r$2];
    return (n ? h$2(n) : e)[t];
  }
  function L$2(e, t) {
    if (!(t in e)) return;
    let r = o$2(e);
    for (; r;) {
      const e = Object.getOwnPropertyDescriptor(r, t);
      if (e) return e;
      r = o$2(r);
    }
  }
  function X$2(e) {
    e.modified_ || (e.modified_ = !0, e.parent_ && X$2(e.parent_));
  }
  function U$2(e) {
    e.copy_ || (e.copy_ = _$2(e.base_, e.scope_.immer_.useStrictShallowCopy_));
  }
  d$2(N$2, (e, t) => {
    F$2[e] = function () {
      return arguments[0] = arguments[0][0], t.apply(this, arguments);
    };
  }), F$2.deleteProperty = function (e, t) {
    return F$2.set.call(this, e, t, void 0);
  }, F$2.set = function (e, t, r) {
    return N$2.set.call(this, e[0], t, r, e[0]);
  };
  function Y$2(e, t) {
    const r = y$2(e) ? k$2("MapSet").proxyMap_(e, t) : m$2(e) ? k$2("MapSet").proxySet_(e, t) : function (e, t) {
      const r = Array.isArray(e),
        n = {
          type_: r ? 1 : 0,
          scope_: t ? t.scope_ : O$2(),
          modified_: !1,
          finalized_: !1,
          assigned_: {},
          parent_: t,
          base_: e,
          draft_: null,
          copy_: null,
          revoke_: null,
          isManual_: !1
        };
      let a = n,
        o = N$2;
      r && (a = [n], o = F$2);
      const {
        revoke: i,
        proxy: s
      } = Proxy.revocable(a, o);
      return n.draft_ = s, n.revoke_ = i, s;
    }(e, t);
    return (t ? t.scope_ : O$2()).drafts_.push(r), r;
  }
  function C$2(e) {
    if (!s$2(e) || g$2(e)) return e;
    const t = e[r$2];
    let n;
    if (t) {
      if (!t.modified_) return t.base_;
      t.finalized_ = !0, n = _$2(e, t.scope_.immer_.useStrictShallowCopy_);
    } else n = _$2(e, !0);
    return d$2(n, (e, t) => {
      f$2(n, e, C$2(t));
    }), t && (t.finalized_ = !1), n;
  }
  var R$2 = new class {
      constructor(t) {
        var _this = this;
        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.produce = (t, r, n) => {
          if ("function" == typeof t && "function" != typeof r) {
            const e = r;
            r = t;
            const n = this;
            return function () {
              let t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : e;
              for (var _len2 = arguments.length, a = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
                a[_key2 - 1] = arguments[_key2];
              }
              return n.produce(t, e => r.call(this, e, ...a));
            };
          }
          let o;
          if ("function" != typeof r && a$1(6), void 0 !== n && "function" != typeof n && a$1(7), s$2(t)) {
            const e = j$2(this),
              a = Y$2(t, void 0);
            let i = !0;
            try {
              o = r(a), i = !1;
            } finally {
              i ? P$2(e) : T$2(e);
            }
            return S$2(e, n), D$2(o, e);
          }
          if (!t || "object" != typeof t) {
            if (o = r(t), void 0 === o && (o = t), o === e$2 && (o = void 0), this.autoFreeze_ && b$2(o, !0), n) {
              const e = [],
                r = [];
              k$2("Patches").generateReplacementPatches_(t, o, e, r), n(e, r);
            }
            return o;
          }
          a$1(1);
        }, this.produceWithPatches = (e, t) => {
          if ("function" == typeof e) return function (t) {
            for (var _len3 = arguments.length, r = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
              r[_key3 - 1] = arguments[_key3];
            }
            return _this.produceWithPatches(t, t => e(t, ...r));
          };
          let r, n;
          return [this.produce(e, t, (e, t) => {
            r = e, n = t;
          }), r, n];
        }, "boolean" == typeof (t === null || t === void 0 ? void 0 : t.autoFreeze) && this.setAutoFreeze(t.autoFreeze), "boolean" == typeof (t === null || t === void 0 ? void 0 : t.useStrictShallowCopy) && this.setUseStrictShallowCopy(t.useStrictShallowCopy);
      }
      createDraft(e) {
        s$2(e) || a$1(8), i$2(e) && (e = function (e) {
          i$2(e) || a$1(10);
          return C$2(e);
        }(e));
        const t = j$2(this),
          n = Y$2(e, void 0);
        return n[r$2].isManual_ = !0, T$2(t), n;
      }
      finishDraft(e, t) {
        const n = e && e[r$2];
        n && n.isManual_ || a$1(9);
        const {
          scope_: o
        } = n;
        return S$2(o, t), D$2(void 0, o);
      }
      setAutoFreeze(e) {
        this.autoFreeze_ = e;
      }
      setUseStrictShallowCopy(e) {
        this.useStrictShallowCopy_ = e;
      }
      applyPatches(e, t) {
        let r;
        for (r = t.length - 1; r >= 0; r--) {
          const n = t[r];
          if (0 === n.path.length && "replace" === n.op) {
            e = n.value;
            break;
          }
        }
        r > -1 && (t = t.slice(r + 1));
        const n = k$2("Patches").applyPatches_;
        return i$2(e) ? n(e, t) : this.produce(e, e => n(e, t));
      }
    }(),
    V$2 = R$2.produce;
  R$2.produceWithPatches.bind(R$2);
  var $$2 = R$2.setAutoFreeze.bind(R$2);
  let K$2;
  R$2.setUseStrictShallowCopy.bind(R$2), R$2.applyPatches.bind(R$2), R$2.createDraft.bind(R$2), R$2.finishDraft.bind(R$2);
  const W$2 = new Uint8Array(16);
  function G$2() {
    if (!K$2 && (K$2 = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !K$2)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    return K$2(W$2);
  }
  const H$2 = [];
  for (let e = 0; e < 256; ++e) H$2.push((e + 256).toString(16).slice(1));
  var J$2 = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
  };
  function q$2(e, t, r) {
    if (J$2.randomUUID && !t && !e) return J$2.randomUUID();
    const n = (e = e || {}).random || (e.rng || G$2)();
    if (n[6] = 15 & n[6] | 64, n[8] = 63 & n[8] | 128, t) ;
    return function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      return H$2[e[t + 0]] + H$2[e[t + 1]] + H$2[e[t + 2]] + H$2[e[t + 3]] + "-" + H$2[e[t + 4]] + H$2[e[t + 5]] + "-" + H$2[e[t + 6]] + H$2[e[t + 7]] + "-" + H$2[e[t + 8]] + H$2[e[t + 9]] + "-" + H$2[e[t + 10]] + H$2[e[t + 11]] + H$2[e[t + 12]] + H$2[e[t + 13]] + H$2[e[t + 14]] + H$2[e[t + 15]];
    }(n);
  }
  const B$2 = 0,
    Q$1 = 0,
    Z$2 = 0,
    ee$2 = "",
    te$2 = () => ({}),
    re$1 = 1,
    ne$1 = 1,
    ae$1 = 1,
    oe$1 = () => [],
    ie$1 = 0,
    se$1 = null,
    ce$1 = !1,
    ue$1 = () => [],
    de$1 = !1,
    le$1 = null,
    pe$1 = -1,
    fe$1 = 0,
    ye$1 = 100,
    me$1 = () => [],
    he$1 = 0,
    _e$1 = "center",
    be$1 = null,
    ve$1 = "source-over",
    ge$1 = !1,
    we$1 = 1,
    xe$1 = !1,
    ke$1 = "system.text",
    Oe$1 = "system.image",
    Se$1 = "system.shape",
    Pe$1 = "system.group",
    Te$1 = "system.video",
    Ee$1 = e => ({
      packageId: e,
      version: "1.0.0"
    }),
    De$1 = 1e6,
    ze$1 = function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ce$1,
        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : te$2();
      return {
        value: "number" == typeof e ? Math.floor(e * De$1) / De$1 : e,
        locked: t,
        meta: r
      };
    },
    Ie$1 = e => {
      let {
        name: t,
        meta: r = te$2(),
        uuid: n = q$2(),
        locked: a = ce$1,
        renderer: o = Ee$1(Pe$1),
        fallbackLayer: i,
        mediaType: s,
        props: {
          width: c,
          height: u,
          x: d = B$2,
          y: l = Q$1,
          scaleY: p = ae$1,
          hidden: f = de$1,
          scaleX: y = ne$1,
          opacity: m = re$1,
          rotation: h = ie$1,
          children: _ = ue$1(),
          duration: b = pe$1,
          startTime: v = fe$1,
          animations: g = me$1(),
          blendMode: w = ve$1
        }
      } = e;
      return {
        uuid: n,
        name: t,
        meta: r,
        locked: a,
        type: "group",
        renderer: o,
        fallbackLayer: i,
        mediaType: s,
        props: {
          x: ze$1(d),
          y: ze$1(l),
          width: ze$1(c),
          height: ze$1(u),
          scaleY: ze$1(p),
          scaleX: ze$1(y),
          hidden: ze$1(f),
          opacity: ze$1(m),
          rotation: ze$1(h),
          children: ze$1(_),
          duration: ze$1(b),
          startTime: ze$1(v),
          blendMode: ze$1(w),
          animations: ze$1(g)
        }
      };
    },
    Me$1 = e => {
      let {
        name: t,
        meta: r = te$2(),
        uuid: n = q$2(),
        locked: a = ce$1,
        renderer: o = Ee$1(Se$1),
        fallbackLayer: i,
        mediaType: s,
        props: {
          shape: c,
          width: u,
          height: d,
          x: l = B$2,
          y: p = Q$1,
          paths: f = oe$1(),
          scaleY: y = ae$1,
          stroke: m = se$1,
          scaleX: h = ne$1,
          hidden: _ = de$1,
          opacity: b = re$1,
          shadow: v = le$1,
          rotation: g = ie$1,
          duration: w = pe$1,
          startTime: x = fe$1,
          blendMode: k = ve$1,
          animations: O = me$1()
        }
      } = e;
      return {
        uuid: n,
        name: t,
        meta: r,
        locked: a,
        type: "shape",
        renderer: o,
        fallbackLayer: i,
        mediaType: s,
        props: {
          x: ze$1(l),
          y: ze$1(p),
          width: ze$1(u),
          shape: ze$1(c),
          paths: ze$1(f),
          stroke: ze$1(m),
          scaleY: ze$1(y),
          height: ze$1(d),
          scaleX: ze$1(h),
          hidden: ze$1(_),
          shadow: ze$1(v),
          opacity: ze$1(b),
          rotation: ze$1(g),
          duration: ze$1(w),
          startTime: ze$1(x),
          blendMode: ze$1(k),
          animations: ze$1(O)
        }
      };
    },
    Ne$1 = e => {
      let {
        name: t,
        meta: r = te$2(),
        uuid: n = q$2(),
        locked: a = ce$1,
        renderer: o = Ee$1(ke$1),
        fallbackLayer: i,
        mediaType: s,
        props: {
          font: c,
          width: u,
          ranges: d,
          y: l = Q$1,
          x: p = B$2,
          bend: f = Z$2,
          path: y = ee$2,
          stroke: m = se$1,
          scaleY: h = ae$1,
          scaleX: _ = ne$1,
          hidden: b = de$1,
          opacity: v = re$1,
          shadow: g = le$1,
          rotation: w = ie$1,
          duration: x = pe$1,
          startTime: k = fe$1,
          alignment: O = _e$1,
          blendMode: S = ve$1,
          lineHeight: P = ye$1,
          letterSpacing: T = he$1,
          animations: j = me$1(),
          perspectivePoints: E = be$1
        }
      } = e;
      return {
        uuid: n,
        name: t,
        meta: r,
        locked: a,
        type: "text",
        renderer: o,
        fallbackLayer: i,
        mediaType: s,
        props: {
          x: ze$1(p),
          y: ze$1(l),
          font: ze$1(c),
          bend: ze$1(f),
          path: ze$1(y),
          width: ze$1(u),
          stroke: ze$1(m),
          scaleY: ze$1(h),
          ranges: ze$1(d),
          scaleX: ze$1(_),
          hidden: ze$1(b),
          shadow: ze$1(g),
          opacity: ze$1(v),
          rotation: ze$1(w),
          duration: ze$1(x),
          startTime: ze$1(k),
          alignment: ze$1(O),
          blendMode: ze$1(S),
          lineHeight: ze$1(P),
          letterSpacing: ze$1(T),
          perspectivePoints: ze$1(E),
          animations: ze$1(j)
        }
      };
    },
    Fe$1 = e => {
      let {
        name: t,
        meta: r = te$2(),
        uuid: n = q$2(),
        locked: a = ce$1,
        renderer: o = Ee$1(Oe$1),
        fallbackLayer: i,
        mediaType: s,
        props: {
          image: c,
          y: u = Q$1,
          x: d = B$2,
          stroke: l = se$1,
          scaleY: p = ae$1,
          hidden: f = de$1,
          scaleX: y = ne$1,
          opacity: m = re$1,
          shadow: h = le$1,
          rotation: _ = ie$1,
          duration: b = pe$1,
          startTime: v = fe$1,
          blendMode: g = ve$1,
          animations: w = me$1()
        }
      } = e;
      return {
        uuid: n,
        name: t,
        meta: r,
        locked: a,
        type: "image",
        renderer: o,
        fallbackLayer: i,
        mediaType: s,
        props: {
          x: ze$1(d),
          y: ze$1(u),
          stroke: ze$1(l),
          image: ze$1(c),
          scaleY: ze$1(p),
          scaleX: ze$1(y),
          hidden: ze$1(f),
          shadow: ze$1(h),
          opacity: ze$1(m),
          rotation: ze$1(_),
          duration: ze$1(b),
          startTime: ze$1(v),
          blendMode: ze$1(g),
          animations: ze$1(w)
        }
      };
    },
    Ae$1 = e => {
      let {
        name: t,
        uuid: r = q$2(),
        meta: n = te$2(),
        locked: a = ce$1,
        renderer: o = Ee$1(Te$1),
        fallbackLayer: i,
        mediaType: s,
        props: {
          video: c,
          volume: u,
          trimEnd: d,
          trimStart: l,
          repeat: p = ge$1,
          speed: f = we$1,
          muted: y = xe$1,
          y: m = Q$1,
          x: h = B$2,
          hidden: _ = de$1,
          scaleY: b = ae$1,
          scaleX: v = ne$1,
          opacity: g = re$1,
          rotation: w = ie$1,
          duration: x = pe$1,
          startTime: k = fe$1,
          animations: O = me$1(),
          blendMode: S = ve$1
        }
      } = e;
      return {
        uuid: r,
        name: t,
        meta: n,
        locked: a,
        type: "video",
        renderer: o,
        fallbackLayer: i,
        mediaType: s,
        props: {
          x: ze$1(h),
          y: ze$1(m),
          video: ze$1(c),
          scaleY: ze$1(b),
          scaleX: ze$1(v),
          hidden: ze$1(_),
          opacity: ze$1(g),
          volume: ze$1(u),
          trimEnd: ze$1(d),
          rotation: ze$1(w),
          duration: ze$1(x),
          trimStart: ze$1(l),
          startTime: ze$1(k),
          blendMode: ze$1(S),
          repeat: ze$1(p),
          speed: ze$1(f),
          muted: ze$1(y),
          animations: ze$1(O)
        }
      };
    },
    Ue$1 = e => "text" === e.type,
    Ye$1 = e => "video" === e.type,
    Ce$1 = e => "audio" === e.type,
    Re$1 = e => "shape" === e.type,
    Ve$1 = e => "group" === e.type,
    $e$1 = e => "image" === e.type,
    We$1 = e => "PROJECT_ROOT" === e.mediaType,
    et$1 = (e, t) => Object.values(e.context.layers).find(e => Ve$1(e) && e.props.children.value.includes(t)),
    tt$1 = (e, t) => {
      const r = e.context.layers[t];
      if (!Ve$1(r)) throw new Error("Layer is not a group");
      return r.props.children.value.map(t => e.context.layers[t]);
    },
    rt$1 = (e, t) => V$2(e, e => {
      const r = e.context.layers[t];
      if (!Ve$1(r)) return;
      r.props.children.value.map(t => e.context.layers[t]).forEach(e => {
        Ce$1(e) || (e.props.scaleX.value *= r.props.scaleX.value, e.props.scaleY.value *= r.props.scaleY.value, e.props.rotation.value += r.props.rotation.value, e.props.x.value += r.props.x.value + r.props.width.value * e.props.x.value, e.props.y.value += r.props.y.value + r.props.height.value * e.props.y.value);
      });
      const n = et$1(e, t);
      if (!n) return;
      const a = n.props.children.value.indexOf(t);
      n.props.children.value.splice(a, 1, ...r.props.children.value);
    }),
    nt$1 = function (e, t) {
      let {
        removeEmptyParent: r = !0
      } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      return V$2(e, e => {
        delete e.context.layers[t];
        const n = et$1(e, t);
        n && (n.props.children.value.splice(n.props.children.value.findIndex(e => e === t), 1), r && 0 === n.props.children.value.length && !We$1(n) && (rt$1(e, n.uuid), nt$1(e, n.uuid)));
      });
    };
  $$2(!1);

  const parseBlendMode$1 = blendMode => {
    return blendMode === 'normal' ? 'source-over' : blendMode.replaceAll('_', '-');
  };

  const parsePattern$1 = pattern => {
    const {
      texture,
      gradient,
      solid
    } = pattern;
    const v3Texture = texture ? {
      location: texture,
      type: 'photo',
      id: generateId()
    } : undefined;
    const v3Gradient = gradient && {
      type: 'linear',
      colors: gradient.colors.map((value, index, array) => {
        const step = 100 / Math.max(array.length - 1, 1);
        return {
          value,
          percentage: index * step
        };
      }),
      angle: gradient.angle
    };
    const type = gradient ? 'gradient' : solid ? 'color' : 'image';
    return {
      type,
      color: solid,
      gradient: v3Gradient,
      texture: v3Texture
    };
  };

  const parseStroke$1 = stroke => {
    return {
      ...stroke,
      dasharray: null,
      pattern: parsePattern$1(stroke.pattern)
    };
  };

  const parseShadow$1 = shadow => {
    const {
      offset_y,
      offset_x
    } = shadow;
    return {
      ...shadow,
      offset: {
        x: offset_x,
        y: offset_y
      }
    };
  };

  var LayerMediaType = /*#__PURE__*/function (LayerMediaType) {
    LayerMediaType["photo"] = "PHOTO";
    LayerMediaType["video"] = "VIDEO";
    LayerMediaType["text"] = "TEXT";
    LayerMediaType["sticker"] = "STICKER";
    LayerMediaType["shape"] = "SHAPE";
    LayerMediaType["backgroundImage"] = "BACKGROUND_IMAGE";
    LayerMediaType["backgroundColor"] = "BACKGROUND_COLOR";
    LayerMediaType["svgSticker"] = "SVG_STICKER";
    LayerMediaType["crop"] = "CROP";
    LayerMediaType["overlay"] = "OVERLAY";
    LayerMediaType["highlight"] = "HIGHLIGHT";
    LayerMediaType["mask"] = "MASK";
    LayerMediaType["collageCellImage"] = "COLLAGE_CELL_IMAGE";
    LayerMediaType["collageCellVideo"] = "COLLAGE_CELL_VIDEO";
    LayerMediaType["collageCell"] = "COLLAGE_CELL";
    LayerMediaType["aoEffect"] = "AO_EFFECT";
    LayerMediaType["isiTextBackground"] = "ISI_TEXT_BACKGROUND";
    LayerMediaType["isiTextCell"] = "ISI_TEXT_CELL";
    LayerMediaType["isiTextPaddingTop"] = "ISI_TEXT_PADDING_TOP";
    LayerMediaType["isiTextPaddingBottom"] = "ISI_TEXT_PADDING_BOTTOM";
    LayerMediaType["projectRoot"] = "PROJECT_ROOT";
    LayerMediaType["canvasGroup"] = "CANVAS_GROUP";
    LayerMediaType["group"] = "GROUP";
    LayerMediaType["textHighlightGroup"] = "TEXT_HIGHLIGHT_GROUP";
    LayerMediaType["overlayGroup"] = "OVERLAY_GROUP";
    LayerMediaType["maskGroup"] = "MASK_GROUP";
    LayerMediaType["cropGroup"] = "CROP_GROUP";
    LayerMediaType["collageGroup"] = "COLLAGE_GROUP";
    LayerMediaType["collageCellGroup"] = "COLLAGE_CELL_GROUP";
    return LayerMediaType;
  }(LayerMediaType || {});

  // This file is autogenerated. It's used to publish ESM to npm.
  function _typeof(obj) {
    "@babel/helpers - typeof";

    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
      return typeof obj;
    } : function (obj) {
      return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
  }

  // https://github.com/bgrins/TinyColor
  // Brian Grinstead, MIT License

  var trimLeft = /^\s+/;
  var trimRight = /\s+$/;
  function tinycolor(color, opts) {
    color = color ? color : "";
    opts = opts || {};

    // If input is already a tinycolor, return itself
    if (color instanceof tinycolor) {
      return color;
    }
    // If we are called as a function, call using new instead
    if (!(this instanceof tinycolor)) {
      return new tinycolor(color, opts);
    }
    var rgb = inputToRGB(color);
    this._originalInput = color, this._r = rgb.r, this._g = rgb.g, this._b = rgb.b, this._a = rgb.a, this._roundA = Math.round(100 * this._a) / 100, this._format = opts.format || rgb.format;
    this._gradientType = opts.gradientType;

    // Don't let the range of [0,255] come back in [0,1].
    // Potentially lose a little bit of precision here, but will fix issues where
    // .5 gets interpreted as half of the total, instead of half of 1
    // If it was supposed to be 128, this was already taken care of by `inputToRgb`
    if (this._r < 1) this._r = Math.round(this._r);
    if (this._g < 1) this._g = Math.round(this._g);
    if (this._b < 1) this._b = Math.round(this._b);
    this._ok = rgb.ok;
  }
  tinycolor.prototype = {
    isDark: function isDark() {
      return this.getBrightness() < 128;
    },
    isLight: function isLight() {
      return !this.isDark();
    },
    isValid: function isValid() {
      return this._ok;
    },
    getOriginalInput: function getOriginalInput() {
      return this._originalInput;
    },
    getFormat: function getFormat() {
      return this._format;
    },
    getAlpha: function getAlpha() {
      return this._a;
    },
    getBrightness: function getBrightness() {
      //http://www.w3.org/TR/AERT#color-contrast
      var rgb = this.toRgb();
      return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    },
    getLuminance: function getLuminance() {
      //http://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
      var rgb = this.toRgb();
      var RsRGB, GsRGB, BsRGB, R, G, B;
      RsRGB = rgb.r / 255;
      GsRGB = rgb.g / 255;
      BsRGB = rgb.b / 255;
      if (RsRGB <= 0.03928) R = RsRGB / 12.92;else R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
      if (GsRGB <= 0.03928) G = GsRGB / 12.92;else G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
      if (BsRGB <= 0.03928) B = BsRGB / 12.92;else B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
      return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    },
    setAlpha: function setAlpha(value) {
      this._a = boundAlpha(value);
      this._roundA = Math.round(100 * this._a) / 100;
      return this;
    },
    toHsv: function toHsv() {
      var hsv = rgbToHsv(this._r, this._g, this._b);
      return {
        h: hsv.h * 360,
        s: hsv.s,
        v: hsv.v,
        a: this._a
      };
    },
    toHsvString: function toHsvString() {
      var hsv = rgbToHsv(this._r, this._g, this._b);
      var h = Math.round(hsv.h * 360),
        s = Math.round(hsv.s * 100),
        v = Math.round(hsv.v * 100);
      return this._a == 1 ? "hsv(" + h + ", " + s + "%, " + v + "%)" : "hsva(" + h + ", " + s + "%, " + v + "%, " + this._roundA + ")";
    },
    toHsl: function toHsl() {
      var hsl = rgbToHsl(this._r, this._g, this._b);
      return {
        h: hsl.h * 360,
        s: hsl.s,
        l: hsl.l,
        a: this._a
      };
    },
    toHslString: function toHslString() {
      var hsl = rgbToHsl(this._r, this._g, this._b);
      var h = Math.round(hsl.h * 360),
        s = Math.round(hsl.s * 100),
        l = Math.round(hsl.l * 100);
      return this._a == 1 ? "hsl(" + h + ", " + s + "%, " + l + "%)" : "hsla(" + h + ", " + s + "%, " + l + "%, " + this._roundA + ")";
    },
    toHex: function toHex(allow3Char) {
      return rgbToHex(this._r, this._g, this._b, allow3Char);
    },
    toHexString: function toHexString(allow3Char) {
      return "#" + this.toHex(allow3Char);
    },
    toHex8: function toHex8(allow4Char) {
      return rgbaToHex(this._r, this._g, this._b, this._a, allow4Char);
    },
    toHex8String: function toHex8String(allow4Char) {
      return "#" + this.toHex8(allow4Char);
    },
    toRgb: function toRgb() {
      return {
        r: Math.round(this._r),
        g: Math.round(this._g),
        b: Math.round(this._b),
        a: this._a
      };
    },
    toRgbString: function toRgbString() {
      return this._a == 1 ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")";
    },
    toPercentageRgb: function toPercentageRgb() {
      return {
        r: Math.round(bound01(this._r, 255) * 100) + "%",
        g: Math.round(bound01(this._g, 255) * 100) + "%",
        b: Math.round(bound01(this._b, 255) * 100) + "%",
        a: this._a
      };
    },
    toPercentageRgbString: function toPercentageRgbString() {
      return this._a == 1 ? "rgb(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%)" : "rgba(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%, " + this._roundA + ")";
    },
    toName: function toName() {
      if (this._a === 0) {
        return "transparent";
      }
      if (this._a < 1) {
        return false;
      }
      return hexNames[rgbToHex(this._r, this._g, this._b, true)] || false;
    },
    toFilter: function toFilter(secondColor) {
      var hex8String = "#" + rgbaToArgbHex(this._r, this._g, this._b, this._a);
      var secondHex8String = hex8String;
      var gradientType = this._gradientType ? "GradientType = 1, " : "";
      if (secondColor) {
        var s = tinycolor(secondColor);
        secondHex8String = "#" + rgbaToArgbHex(s._r, s._g, s._b, s._a);
      }
      return "progid:DXImageTransform.Microsoft.gradient(" + gradientType + "startColorstr=" + hex8String + ",endColorstr=" + secondHex8String + ")";
    },
    toString: function toString(format) {
      var formatSet = !!format;
      format = format || this._format;
      var formattedString = false;
      var hasAlpha = this._a < 1 && this._a >= 0;
      var needsAlphaFormat = !formatSet && hasAlpha && (format === "hex" || format === "hex6" || format === "hex3" || format === "hex4" || format === "hex8" || format === "name");
      if (needsAlphaFormat) {
        // Special case for "transparent", all other non-alpha formats
        // will return rgba when there is transparency.
        if (format === "name" && this._a === 0) {
          return this.toName();
        }
        return this.toRgbString();
      }
      if (format === "rgb") {
        formattedString = this.toRgbString();
      }
      if (format === "prgb") {
        formattedString = this.toPercentageRgbString();
      }
      if (format === "hex" || format === "hex6") {
        formattedString = this.toHexString();
      }
      if (format === "hex3") {
        formattedString = this.toHexString(true);
      }
      if (format === "hex4") {
        formattedString = this.toHex8String(true);
      }
      if (format === "hex8") {
        formattedString = this.toHex8String();
      }
      if (format === "name") {
        formattedString = this.toName();
      }
      if (format === "hsl") {
        formattedString = this.toHslString();
      }
      if (format === "hsv") {
        formattedString = this.toHsvString();
      }
      return formattedString || this.toHexString();
    },
    clone: function clone() {
      return tinycolor(this.toString());
    },
    _applyModification: function _applyModification(fn, args) {
      var color = fn.apply(null, [this].concat([].slice.call(args)));
      this._r = color._r;
      this._g = color._g;
      this._b = color._b;
      this.setAlpha(color._a);
      return this;
    },
    lighten: function lighten() {
      return this._applyModification(_lighten, arguments);
    },
    brighten: function brighten() {
      return this._applyModification(_brighten, arguments);
    },
    darken: function darken() {
      return this._applyModification(_darken, arguments);
    },
    desaturate: function desaturate() {
      return this._applyModification(_desaturate, arguments);
    },
    saturate: function saturate() {
      return this._applyModification(_saturate, arguments);
    },
    greyscale: function greyscale() {
      return this._applyModification(_greyscale, arguments);
    },
    spin: function spin() {
      return this._applyModification(_spin, arguments);
    },
    _applyCombination: function _applyCombination(fn, args) {
      return fn.apply(null, [this].concat([].slice.call(args)));
    },
    analogous: function analogous() {
      return this._applyCombination(_analogous, arguments);
    },
    complement: function complement() {
      return this._applyCombination(_complement, arguments);
    },
    monochromatic: function monochromatic() {
      return this._applyCombination(_monochromatic, arguments);
    },
    splitcomplement: function splitcomplement() {
      return this._applyCombination(_splitcomplement, arguments);
    },
    // Disabled until https://github.com/bgrins/TinyColor/issues/254
    // polyad: function (number) {
    //   return this._applyCombination(polyad, [number]);
    // },
    triad: function triad() {
      return this._applyCombination(polyad, [3]);
    },
    tetrad: function tetrad() {
      return this._applyCombination(polyad, [4]);
    }
  };

  // If input is an object, force 1 into "1.0" to handle ratios properly
  // String input requires "1.0" as input, so 1 will be treated as 1
  tinycolor.fromRatio = function (color, opts) {
    if (_typeof(color) == "object") {
      var newColor = {};
      for (var i in color) {
        if (color.hasOwnProperty(i)) {
          if (i === "a") {
            newColor[i] = color[i];
          } else {
            newColor[i] = convertToPercentage(color[i]);
          }
        }
      }
      color = newColor;
    }
    return tinycolor(color, opts);
  };

  // Given a string or object, convert that input to RGB
  // Possible string inputs:
  //
  //     "red"
  //     "#f00" or "f00"
  //     "#ff0000" or "ff0000"
  //     "#ff000000" or "ff000000"
  //     "rgb 255 0 0" or "rgb (255, 0, 0)"
  //     "rgb 1.0 0 0" or "rgb (1, 0, 0)"
  //     "rgba (255, 0, 0, 1)" or "rgba 255, 0, 0, 1"
  //     "rgba (1.0, 0, 0, 1)" or "rgba 1.0, 0, 0, 1"
  //     "hsl(0, 100%, 50%)" or "hsl 0 100% 50%"
  //     "hsla(0, 100%, 50%, 1)" or "hsla 0 100% 50%, 1"
  //     "hsv(0, 100%, 100%)" or "hsv 0 100% 100%"
  //
  function inputToRGB(color) {
    var rgb = {
      r: 0,
      g: 0,
      b: 0
    };
    var a = 1;
    var s = null;
    var v = null;
    var l = null;
    var ok = false;
    var format = false;
    if (typeof color == "string") {
      color = stringInputToObject(color);
    }
    if (_typeof(color) == "object") {
      if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
        rgb = rgbToRgb(color.r, color.g, color.b);
        ok = true;
        format = String(color.r).substr(-1) === "%" ? "prgb" : "rgb";
      } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
        s = convertToPercentage(color.s);
        v = convertToPercentage(color.v);
        rgb = hsvToRgb(color.h, s, v);
        ok = true;
        format = "hsv";
      } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
        s = convertToPercentage(color.s);
        l = convertToPercentage(color.l);
        rgb = hslToRgb(color.h, s, l);
        ok = true;
        format = "hsl";
      }
      if (color.hasOwnProperty("a")) {
        a = color.a;
      }
    }
    a = boundAlpha(a);
    return {
      ok: ok,
      format: color.format || format,
      r: Math.min(255, Math.max(rgb.r, 0)),
      g: Math.min(255, Math.max(rgb.g, 0)),
      b: Math.min(255, Math.max(rgb.b, 0)),
      a: a
    };
  }

  // Conversion Functions
  // --------------------

  // `rgbToHsl`, `rgbToHsv`, `hslToRgb`, `hsvToRgb` modified from:
  // <http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript>

  // `rgbToRgb`
  // Handle bounds / percentage checking to conform to CSS color spec
  // <http://www.w3.org/TR/css3-color/>
  // *Assumes:* r, g, b in [0, 255] or [0, 1]
  // *Returns:* { r, g, b } in [0, 255]
  function rgbToRgb(r, g, b) {
    return {
      r: bound01(r, 255) * 255,
      g: bound01(g, 255) * 255,
      b: bound01(b, 255) * 255
    };
  }

  // `rgbToHsl`
  // Converts an RGB color value to HSL.
  // *Assumes:* r, g, and b are contained in [0, 255] or [0, 1]
  // *Returns:* { h, s, l } in [0,1]
  function rgbToHsl(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    var max = Math.max(r, g, b),
      min = Math.min(r, g, b);
    var h,
      s,
      l = (max + min) / 2;
    if (max == min) {
      h = s = 0; // achromatic
    } else {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r:
          h = (g - b) / d + (g < b ? 6 : 0);
          break;
        case g:
          h = (b - r) / d + 2;
          break;
        case b:
          h = (r - g) / d + 4;
          break;
      }
      h /= 6;
    }
    return {
      h: h,
      s: s,
      l: l
    };
  }

  // `hslToRgb`
  // Converts an HSL color value to RGB.
  // *Assumes:* h is contained in [0, 1] or [0, 360] and s and l are contained [0, 1] or [0, 100]
  // *Returns:* { r, g, b } in the set [0, 255]
  function hslToRgb(h, s, l) {
    var r, g, b;
    h = bound01(h, 360);
    s = bound01(s, 100);
    l = bound01(l, 100);
    function hue2rgb(p, q, t) {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    }
    if (s === 0) {
      r = g = b = l; // achromatic
    } else {
      var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      var p = 2 * l - q;
      r = hue2rgb(p, q, h + 1 / 3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1 / 3);
    }
    return {
      r: r * 255,
      g: g * 255,
      b: b * 255
    };
  }

  // `rgbToHsv`
  // Converts an RGB color value to HSV
  // *Assumes:* r, g, and b are contained in the set [0, 255] or [0, 1]
  // *Returns:* { h, s, v } in [0,1]
  function rgbToHsv(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    var max = Math.max(r, g, b),
      min = Math.min(r, g, b);
    var h,
      s,
      v = max;
    var d = max - min;
    s = max === 0 ? 0 : d / max;
    if (max == min) {
      h = 0; // achromatic
    } else {
      switch (max) {
        case r:
          h = (g - b) / d + (g < b ? 6 : 0);
          break;
        case g:
          h = (b - r) / d + 2;
          break;
        case b:
          h = (r - g) / d + 4;
          break;
      }
      h /= 6;
    }
    return {
      h: h,
      s: s,
      v: v
    };
  }

  // `hsvToRgb`
  // Converts an HSV color value to RGB.
  // *Assumes:* h is contained in [0, 1] or [0, 360] and s and v are contained in [0, 1] or [0, 100]
  // *Returns:* { r, g, b } in the set [0, 255]
  function hsvToRgb(h, s, v) {
    h = bound01(h, 360) * 6;
    s = bound01(s, 100);
    v = bound01(v, 100);
    var i = Math.floor(h),
      f = h - i,
      p = v * (1 - s),
      q = v * (1 - f * s),
      t = v * (1 - (1 - f) * s),
      mod = i % 6,
      r = [v, q, p, p, t, v][mod],
      g = [t, v, v, q, p, p][mod],
      b = [p, p, t, v, v, q][mod];
    return {
      r: r * 255,
      g: g * 255,
      b: b * 255
    };
  }

  // `rgbToHex`
  // Converts an RGB color to hex
  // Assumes r, g, and b are contained in the set [0, 255]
  // Returns a 3 or 6 character hex
  function rgbToHex(r, g, b, allow3Char) {
    var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];

    // Return a 3 character hex if possible
    if (allow3Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1)) {
      return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
    }
    return hex.join("");
  }

  // `rgbaToHex`
  // Converts an RGBA color plus alpha transparency to hex
  // Assumes r, g, b are contained in the set [0, 255] and
  // a in [0, 1]. Returns a 4 or 8 character rgba hex
  function rgbaToHex(r, g, b, a, allow4Char) {
    var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16)), pad2(convertDecimalToHex(a))];

    // Return a 4 character hex if possible
    if (allow4Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1) && hex[3].charAt(0) == hex[3].charAt(1)) {
      return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
    }
    return hex.join("");
  }

  // `rgbaToArgbHex`
  // Converts an RGBA color to an ARGB Hex8 string
  // Rarely used, but required for "toFilter()"
  function rgbaToArgbHex(r, g, b, a) {
    var hex = [pad2(convertDecimalToHex(a)), pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];
    return hex.join("");
  }

  // `equals`
  // Can be called with any tinycolor input
  tinycolor.equals = function (color1, color2) {
    if (!color1 || !color2) return false;
    return tinycolor(color1).toRgbString() == tinycolor(color2).toRgbString();
  };
  tinycolor.random = function () {
    return tinycolor.fromRatio({
      r: Math.random(),
      g: Math.random(),
      b: Math.random()
    });
  };

  // Modification Functions
  // ----------------------
  // Thanks to less.js for some of the basics here
  // <https://github.com/cloudhead/less.js/blob/master/lib/less/functions.js>

  function _desaturate(color, amount) {
    amount = amount === 0 ? 0 : amount || 10;
    var hsl = tinycolor(color).toHsl();
    hsl.s -= amount / 100;
    hsl.s = clamp01(hsl.s);
    return tinycolor(hsl);
  }
  function _saturate(color, amount) {
    amount = amount === 0 ? 0 : amount || 10;
    var hsl = tinycolor(color).toHsl();
    hsl.s += amount / 100;
    hsl.s = clamp01(hsl.s);
    return tinycolor(hsl);
  }
  function _greyscale(color) {
    return tinycolor(color).desaturate(100);
  }
  function _lighten(color, amount) {
    amount = amount === 0 ? 0 : amount || 10;
    var hsl = tinycolor(color).toHsl();
    hsl.l += amount / 100;
    hsl.l = clamp01(hsl.l);
    return tinycolor(hsl);
  }
  function _brighten(color, amount) {
    amount = amount === 0 ? 0 : amount || 10;
    var rgb = tinycolor(color).toRgb();
    rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
    rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
    rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
    return tinycolor(rgb);
  }
  function _darken(color, amount) {
    amount = amount === 0 ? 0 : amount || 10;
    var hsl = tinycolor(color).toHsl();
    hsl.l -= amount / 100;
    hsl.l = clamp01(hsl.l);
    return tinycolor(hsl);
  }

  // Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
  // Values outside of this range will be wrapped into this range.
  function _spin(color, amount) {
    var hsl = tinycolor(color).toHsl();
    var hue = (hsl.h + amount) % 360;
    hsl.h = hue < 0 ? 360 + hue : hue;
    return tinycolor(hsl);
  }

  // Combination Functions
  // ---------------------
  // Thanks to jQuery xColor for some of the ideas behind these
  // <https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js>

  function _complement(color) {
    var hsl = tinycolor(color).toHsl();
    hsl.h = (hsl.h + 180) % 360;
    return tinycolor(hsl);
  }
  function polyad(color, number) {
    if (isNaN(number) || number <= 0) {
      throw new Error("Argument to polyad must be a positive number");
    }
    var hsl = tinycolor(color).toHsl();
    var result = [tinycolor(color)];
    var step = 360 / number;
    for (var i = 1; i < number; i++) {
      result.push(tinycolor({
        h: (hsl.h + i * step) % 360,
        s: hsl.s,
        l: hsl.l
      }));
    }
    return result;
  }
  function _splitcomplement(color) {
    var hsl = tinycolor(color).toHsl();
    var h = hsl.h;
    return [tinycolor(color), tinycolor({
      h: (h + 72) % 360,
      s: hsl.s,
      l: hsl.l
    }), tinycolor({
      h: (h + 216) % 360,
      s: hsl.s,
      l: hsl.l
    })];
  }
  function _analogous(color, results, slices) {
    results = results || 6;
    slices = slices || 30;
    var hsl = tinycolor(color).toHsl();
    var part = 360 / slices;
    var ret = [tinycolor(color)];
    for (hsl.h = (hsl.h - (part * results >> 1) + 720) % 360; --results;) {
      hsl.h = (hsl.h + part) % 360;
      ret.push(tinycolor(hsl));
    }
    return ret;
  }
  function _monochromatic(color, results) {
    results = results || 6;
    var hsv = tinycolor(color).toHsv();
    var h = hsv.h,
      s = hsv.s,
      v = hsv.v;
    var ret = [];
    var modification = 1 / results;
    while (results--) {
      ret.push(tinycolor({
        h: h,
        s: s,
        v: v
      }));
      v = (v + modification) % 1;
    }
    return ret;
  }

  // Utility Functions
  // ---------------------

  tinycolor.mix = function (color1, color2, amount) {
    amount = amount === 0 ? 0 : amount || 50;
    var rgb1 = tinycolor(color1).toRgb();
    var rgb2 = tinycolor(color2).toRgb();
    var p = amount / 100;
    var rgba = {
      r: (rgb2.r - rgb1.r) * p + rgb1.r,
      g: (rgb2.g - rgb1.g) * p + rgb1.g,
      b: (rgb2.b - rgb1.b) * p + rgb1.b,
      a: (rgb2.a - rgb1.a) * p + rgb1.a
    };
    return tinycolor(rgba);
  };

  // Readability Functions
  // ---------------------
  // <http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef (WCAG Version 2)

  // `contrast`
  // Analyze the 2 colors and returns the color contrast defined by (WCAG Version 2)
  tinycolor.readability = function (color1, color2) {
    var c1 = tinycolor(color1);
    var c2 = tinycolor(color2);
    return (Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) / (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05);
  };

  // `isReadable`
  // Ensure that foreground and background color combinations meet WCAG2 guidelines.
  // The third argument is an optional Object.
  //      the 'level' property states 'AA' or 'AAA' - if missing or invalid, it defaults to 'AA';
  //      the 'size' property states 'large' or 'small' - if missing or invalid, it defaults to 'small'.
  // If the entire object is absent, isReadable defaults to {level:"AA",size:"small"}.

  // *Example*
  //    tinycolor.isReadable("#000", "#111") => false
  //    tinycolor.isReadable("#000", "#111",{level:"AA",size:"large"}) => false
  tinycolor.isReadable = function (color1, color2, wcag2) {
    var readability = tinycolor.readability(color1, color2);
    var wcag2Parms, out;
    out = false;
    wcag2Parms = validateWCAG2Parms(wcag2);
    switch (wcag2Parms.level + wcag2Parms.size) {
      case "AAsmall":
      case "AAAlarge":
        out = readability >= 4.5;
        break;
      case "AAlarge":
        out = readability >= 3;
        break;
      case "AAAsmall":
        out = readability >= 7;
        break;
    }
    return out;
  };

  // `mostReadable`
  // Given a base color and a list of possible foreground or background
  // colors for that base, returns the most readable color.
  // Optionally returns Black or White if the most readable color is unreadable.
  // *Example*
  //    tinycolor.mostReadable(tinycolor.mostReadable("#123", ["#124", "#125"],{includeFallbackColors:false}).toHexString(); // "#112255"
  //    tinycolor.mostReadable(tinycolor.mostReadable("#123", ["#124", "#125"],{includeFallbackColors:true}).toHexString();  // "#ffffff"
  //    tinycolor.mostReadable("#a8015a", ["#faf3f3"],{includeFallbackColors:true,level:"AAA",size:"large"}).toHexString(); // "#faf3f3"
  //    tinycolor.mostReadable("#a8015a", ["#faf3f3"],{includeFallbackColors:true,level:"AAA",size:"small"}).toHexString(); // "#ffffff"
  tinycolor.mostReadable = function (baseColor, colorList, args) {
    var bestColor = null;
    var bestScore = 0;
    var readability;
    var includeFallbackColors, level, size;
    args = args || {};
    includeFallbackColors = args.includeFallbackColors;
    level = args.level;
    size = args.size;
    for (var i = 0; i < colorList.length; i++) {
      readability = tinycolor.readability(baseColor, colorList[i]);
      if (readability > bestScore) {
        bestScore = readability;
        bestColor = tinycolor(colorList[i]);
      }
    }
    if (tinycolor.isReadable(baseColor, bestColor, {
      level: level,
      size: size
    }) || !includeFallbackColors) {
      return bestColor;
    } else {
      args.includeFallbackColors = false;
      return tinycolor.mostReadable(baseColor, ["#fff", "#000"], args);
    }
  };

  // Big List of Colors
  // ------------------
  // <https://www.w3.org/TR/css-color-4/#named-colors>
  var names = tinycolor.names = {
    aliceblue: "f0f8ff",
    antiquewhite: "faebd7",
    aqua: "0ff",
    aquamarine: "7fffd4",
    azure: "f0ffff",
    beige: "f5f5dc",
    bisque: "ffe4c4",
    black: "000",
    blanchedalmond: "ffebcd",
    blue: "00f",
    blueviolet: "8a2be2",
    brown: "a52a2a",
    burlywood: "deb887",
    burntsienna: "ea7e5d",
    cadetblue: "5f9ea0",
    chartreuse: "7fff00",
    chocolate: "d2691e",
    coral: "ff7f50",
    cornflowerblue: "6495ed",
    cornsilk: "fff8dc",
    crimson: "dc143c",
    cyan: "0ff",
    darkblue: "00008b",
    darkcyan: "008b8b",
    darkgoldenrod: "b8860b",
    darkgray: "a9a9a9",
    darkgreen: "006400",
    darkgrey: "a9a9a9",
    darkkhaki: "bdb76b",
    darkmagenta: "8b008b",
    darkolivegreen: "556b2f",
    darkorange: "ff8c00",
    darkorchid: "9932cc",
    darkred: "8b0000",
    darksalmon: "e9967a",
    darkseagreen: "8fbc8f",
    darkslateblue: "483d8b",
    darkslategray: "2f4f4f",
    darkslategrey: "2f4f4f",
    darkturquoise: "00ced1",
    darkviolet: "9400d3",
    deeppink: "ff1493",
    deepskyblue: "00bfff",
    dimgray: "696969",
    dimgrey: "696969",
    dodgerblue: "1e90ff",
    firebrick: "b22222",
    floralwhite: "fffaf0",
    forestgreen: "228b22",
    fuchsia: "f0f",
    gainsboro: "dcdcdc",
    ghostwhite: "f8f8ff",
    gold: "ffd700",
    goldenrod: "daa520",
    gray: "808080",
    green: "008000",
    greenyellow: "adff2f",
    grey: "808080",
    honeydew: "f0fff0",
    hotpink: "ff69b4",
    indianred: "cd5c5c",
    indigo: "4b0082",
    ivory: "fffff0",
    khaki: "f0e68c",
    lavender: "e6e6fa",
    lavenderblush: "fff0f5",
    lawngreen: "7cfc00",
    lemonchiffon: "fffacd",
    lightblue: "add8e6",
    lightcoral: "f08080",
    lightcyan: "e0ffff",
    lightgoldenrodyellow: "fafad2",
    lightgray: "d3d3d3",
    lightgreen: "90ee90",
    lightgrey: "d3d3d3",
    lightpink: "ffb6c1",
    lightsalmon: "ffa07a",
    lightseagreen: "20b2aa",
    lightskyblue: "87cefa",
    lightslategray: "789",
    lightslategrey: "789",
    lightsteelblue: "b0c4de",
    lightyellow: "ffffe0",
    lime: "0f0",
    limegreen: "32cd32",
    linen: "faf0e6",
    magenta: "f0f",
    maroon: "800000",
    mediumaquamarine: "66cdaa",
    mediumblue: "0000cd",
    mediumorchid: "ba55d3",
    mediumpurple: "9370db",
    mediumseagreen: "3cb371",
    mediumslateblue: "7b68ee",
    mediumspringgreen: "00fa9a",
    mediumturquoise: "48d1cc",
    mediumvioletred: "c71585",
    midnightblue: "191970",
    mintcream: "f5fffa",
    mistyrose: "ffe4e1",
    moccasin: "ffe4b5",
    navajowhite: "ffdead",
    navy: "000080",
    oldlace: "fdf5e6",
    olive: "808000",
    olivedrab: "6b8e23",
    orange: "ffa500",
    orangered: "ff4500",
    orchid: "da70d6",
    palegoldenrod: "eee8aa",
    palegreen: "98fb98",
    paleturquoise: "afeeee",
    palevioletred: "db7093",
    papayawhip: "ffefd5",
    peachpuff: "ffdab9",
    peru: "cd853f",
    pink: "ffc0cb",
    plum: "dda0dd",
    powderblue: "b0e0e6",
    purple: "800080",
    rebeccapurple: "663399",
    red: "f00",
    rosybrown: "bc8f8f",
    royalblue: "4169e1",
    saddlebrown: "8b4513",
    salmon: "fa8072",
    sandybrown: "f4a460",
    seagreen: "2e8b57",
    seashell: "fff5ee",
    sienna: "a0522d",
    silver: "c0c0c0",
    skyblue: "87ceeb",
    slateblue: "6a5acd",
    slategray: "708090",
    slategrey: "708090",
    snow: "fffafa",
    springgreen: "00ff7f",
    steelblue: "4682b4",
    tan: "d2b48c",
    teal: "008080",
    thistle: "d8bfd8",
    tomato: "ff6347",
    turquoise: "40e0d0",
    violet: "ee82ee",
    wheat: "f5deb3",
    white: "fff",
    whitesmoke: "f5f5f5",
    yellow: "ff0",
    yellowgreen: "9acd32"
  };

  // Make it easy to access colors via `hexNames[hex]`
  var hexNames = tinycolor.hexNames = flip(names);

  // Utilities
  // ---------

  // `{ 'name1': 'val1' }` becomes `{ 'val1': 'name1' }`
  function flip(o) {
    var flipped = {};
    for (var i in o) {
      if (o.hasOwnProperty(i)) {
        flipped[o[i]] = i;
      }
    }
    return flipped;
  }

  // Return a valid alpha value [0,1] with all invalid values being set to 1
  function boundAlpha(a) {
    a = parseFloat(a);
    if (isNaN(a) || a < 0 || a > 1) {
      a = 1;
    }
    return a;
  }

  // Take input from [0, n] and return it as [0, 1]
  function bound01(n, max) {
    if (isOnePointZero(n)) n = "100%";
    var processPercent = isPercentage(n);
    n = Math.min(max, Math.max(0, parseFloat(n)));

    // Automatically convert percentage into number
    if (processPercent) {
      n = parseInt(n * max, 10) / 100;
    }

    // Handle floating point rounding errors
    if (Math.abs(n - max) < 0.000001) {
      return 1;
    }

    // Convert into [0, 1] range if it isn't already
    return n % max / parseFloat(max);
  }

  // Force a number between 0 and 1
  function clamp01(val) {
    return Math.min(1, Math.max(0, val));
  }

  // Parse a base-16 hex value into a base-10 integer
  function parseIntFromHex(val) {
    return parseInt(val, 16);
  }

  // Need to handle 1.0 as 100%, since once it is a number, there is no difference between it and 1
  // <http://stackoverflow.com/questions/7422072/javascript-how-to-detect-number-as-a-decimal-including-1-0>
  function isOnePointZero(n) {
    return typeof n == "string" && n.indexOf(".") != -1 && parseFloat(n) === 1;
  }

  // Check to see if string passed in is a percentage
  function isPercentage(n) {
    return typeof n === "string" && n.indexOf("%") != -1;
  }

  // Force a hex value to have 2 characters
  function pad2(c) {
    return c.length == 1 ? "0" + c : "" + c;
  }

  // Replace a decimal with it's percentage value
  function convertToPercentage(n) {
    if (n <= 1) {
      n = n * 100 + "%";
    }
    return n;
  }

  // Converts a decimal to a hex value
  function convertDecimalToHex(d) {
    return Math.round(parseFloat(d) * 255).toString(16);
  }
  // Converts a hex value to a decimal
  function convertHexToDecimal(h) {
    return parseIntFromHex(h) / 255;
  }
  var matchers = function () {
    // <http://www.w3.org/TR/css3-values/#integers>
    var CSS_INTEGER = "[-\\+]?\\d+%?";

    // <http://www.w3.org/TR/css3-values/#number-value>
    var CSS_NUMBER = "[-\\+]?\\d*\\.\\d+%?";

    // Allow positive/negative integer/number.  Don't capture the either/or, just the entire outcome.
    var CSS_UNIT = "(?:" + CSS_NUMBER + ")|(?:" + CSS_INTEGER + ")";

    // Actual matching.
    // Parentheses and commas are optional, but not required.
    // Whitespace can take the place of commas or opening paren
    var PERMISSIVE_MATCH3 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
    var PERMISSIVE_MATCH4 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
    return {
      CSS_UNIT: new RegExp(CSS_UNIT),
      rgb: new RegExp("rgb" + PERMISSIVE_MATCH3),
      rgba: new RegExp("rgba" + PERMISSIVE_MATCH4),
      hsl: new RegExp("hsl" + PERMISSIVE_MATCH3),
      hsla: new RegExp("hsla" + PERMISSIVE_MATCH4),
      hsv: new RegExp("hsv" + PERMISSIVE_MATCH3),
      hsva: new RegExp("hsva" + PERMISSIVE_MATCH4),
      hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
      hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
      hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
      hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
    };
  }();

  // `isValidCSSUnit`
  // Take in a single string / number and check to see if it looks like a CSS unit
  // (see `matchers` above for definition).
  function isValidCSSUnit(color) {
    return !!matchers.CSS_UNIT.exec(color);
  }

  // `stringInputToObject`
  // Permissive string parsing.  Take in a number of formats, and output an object
  // based on detected format.  Returns `{ r, g, b }` or `{ h, s, l }` or `{ h, s, v}`
  function stringInputToObject(color) {
    color = color.replace(trimLeft, "").replace(trimRight, "").toLowerCase();
    var named = false;
    if (names[color]) {
      color = names[color];
      named = true;
    } else if (color == "transparent") {
      return {
        r: 0,
        g: 0,
        b: 0,
        a: 0,
        format: "name"
      };
    }

    // Try to match string input using regular expressions.
    // Keep most of the number bounding out of this function - don't worry about [0,1] or [0,100] or [0,360]
    // Just return an object and let the conversion functions handle that.
    // This way the result will be the same whether the tinycolor is initialized with string or object.
    var match;
    if (match = matchers.rgb.exec(color)) {
      return {
        r: match[1],
        g: match[2],
        b: match[3]
      };
    }
    if (match = matchers.rgba.exec(color)) {
      return {
        r: match[1],
        g: match[2],
        b: match[3],
        a: match[4]
      };
    }
    if (match = matchers.hsl.exec(color)) {
      return {
        h: match[1],
        s: match[2],
        l: match[3]
      };
    }
    if (match = matchers.hsla.exec(color)) {
      return {
        h: match[1],
        s: match[2],
        l: match[3],
        a: match[4]
      };
    }
    if (match = matchers.hsv.exec(color)) {
      return {
        h: match[1],
        s: match[2],
        v: match[3]
      };
    }
    if (match = matchers.hsva.exec(color)) {
      return {
        h: match[1],
        s: match[2],
        v: match[3],
        a: match[4]
      };
    }
    if (match = matchers.hex8.exec(color)) {
      return {
        r: parseIntFromHex(match[1]),
        g: parseIntFromHex(match[2]),
        b: parseIntFromHex(match[3]),
        a: convertHexToDecimal(match[4]),
        format: named ? "name" : "hex8"
      };
    }
    if (match = matchers.hex6.exec(color)) {
      return {
        r: parseIntFromHex(match[1]),
        g: parseIntFromHex(match[2]),
        b: parseIntFromHex(match[3]),
        format: named ? "name" : "hex"
      };
    }
    if (match = matchers.hex4.exec(color)) {
      return {
        r: parseIntFromHex(match[1] + "" + match[1]),
        g: parseIntFromHex(match[2] + "" + match[2]),
        b: parseIntFromHex(match[3] + "" + match[3]),
        a: convertHexToDecimal(match[4] + "" + match[4]),
        format: named ? "name" : "hex8"
      };
    }
    if (match = matchers.hex3.exec(color)) {
      return {
        r: parseIntFromHex(match[1] + "" + match[1]),
        g: parseIntFromHex(match[2] + "" + match[2]),
        b: parseIntFromHex(match[3] + "" + match[3]),
        format: named ? "name" : "hex"
      };
    }
    return false;
  }
  function validateWCAG2Parms(parms) {
    // return valid WCAG2 parms for isReadable.
    // If input parms are invalid, return {"level":"AA", "size":"small"}
    var level, size;
    parms = parms || {
      level: "AA",
      size: "small"
    };
    level = (parms.level || "AA").toUpperCase();
    size = (parms.size || "small").toLowerCase();
    if (level !== "AA" && level !== "AAA") {
      level = "AA";
    }
    if (size !== "small" && size !== "large") {
      size = "small";
    }
    return {
      level: level,
      size: size
    };
  }

  const DEFAULT_BLACK = '#000000';
  const TRANSPARENT_RGBA = 'rgba(255, 255, 255, 0)';
  const getPathAttr = (path, attr) => {
    const value = path.getAttribute(attr);
    if (value) {
      return value;
    }
    if (!path.parentElement) {
      return;
    }
    return getPathAttr(path.parentElement, attr);
  };
  const getPathFill = path => {
    var _path$style;
    let val = getPathAttr(path, 'fill');
    if (val === 'none') {
      return {
        type: 'color',
        color: TRANSPARENT_RGBA
      };
    }
    if (!val && (_path$style = path.style) !== null && _path$style !== void 0 && _path$style.fill && path.style.fill.includes('rgb')) {
      val = tinycolor(path.style.fill).toHex8String();
    }
    return {
      type: 'color',
      color: val || DEFAULT_BLACK
    };
  };
  const getAttributesFromSVG = path => {
    var _getPathAttr;
    return {
      path: path.getAttribute('d') || '',
      stroke: getPathAttr(path, 'stroke'),
      opacity: Number((_getPathAttr = getPathAttr(path, 'fill-opacity')) !== null && _getPathAttr !== void 0 ? _getPathAttr : 1),
      strokeWidth: Number(getPathAttr(path, 'stroke-width')) || 0,
      lineCap: getPathAttr(path, 'stroke-linecap'),
      lineJoin: getPathAttr(path, 'stroke-linejoin'),
      fill: getPathFill(path),
      id: generateId()
    };
  };
  async function loadSvgForLayer(url) {
    const response = await fetch(url);
    const blobSvg = await response.blob();
    const data = await new Promise(resolve => {
      const object = document.createElement('object');
      object.type = 'image/svg+xml';
      object.title = 'fake';
      object.addEventListener('load', () => {
        const doc = object.contentDocument;
        const paths = Array.from((doc === null || doc === void 0 ? void 0 : doc.querySelectorAll('path')) || []);
        document.body.removeChild(object);
        resolve({
          paths: paths.map(getAttributesFromSVG)
        });
      }, false);
      object.data = URL.createObjectURL(blobSvg);
      object.classList.add('visually-hidden');
      document.body.append(object);
    });
    return data;
  }
  const parseFill = fill => {
    if (!fill) {
      return {
        type: 'color',
        color: DEFAULT_BLACK
      };
    }
    if (fill.type === 'color') {
      return {
        type: 'color',
        color: fill.color
      };
    } else if (['linear', 'conic', 'radial'].includes(fill.type)) {
      return {
        type: 'gradient',
        gradient: {
          ...fill,
          colors: fill.colors.map(stop => ({
            percentage: stop.percentage,
            value: stop.color
          }))
        }
      };
    } else if (fill.type === 'texture') {
      return {
        location: fill.resource_url,
        type: 'photo',
        id: fill.resource_id
      };
    }
    return {
      type: 'color',
      color: DEFAULT_BLACK
    };
  };

  const parseOpacity = opacity => {
    if (opacity >= 0 && opacity <= 1) return opacity;
    return opacity / 100;
  };

  const parseShape = async (shape, resources, existingData) => {
    if (!existingData.replay.context.layers[shape.uuid]) {
      existingData.replay.context.layers[shape.uuid] = Me$1({
        name: 'shape',
        mediaType: LayerMediaType.shape,
        uuid: shape.uuid,
        props: {
          width: 1,
          height: 1,
          shape: {
            id: resources[shape.settings.shape].id,
            location: resources[shape.settings.shape].location,
            type: 'svg'
          }
        }
      });
      existingData.replay.context.layers[existingData.selectedCanvasId].props.children.value.push(shape.uuid);
    }
    const replayLayer = existingData.replay.context.layers[shape.uuid];
    const props = replayLayer.props;
    const settings = shape.settings;
    props.opacity.value = ze$1(parseOpacity(settings.opacity)).value;
    props.blendMode.value = parseBlendMode$1(settings.blendmode);
    if (settings.stroke) {
      props.stroke.value = parseStroke$1(settings.stroke);
    }
    if (settings.shadow) {
      props.shadow.value = parseShadow$1(settings.shadow);
    }
    if (settings.adjust.length) {
      props.paths.value = settings.adjust.map(adjust => ({
        ...adjust,
        d: adjust.path,
        stroke: adjust.stroke ? parseStroke$1(adjust.stroke) : null,
        fill: parsePattern$1(adjust.fill)
      }));
    } else if (resources[settings.shape].location) {
      const pathData = (await loadSvgForLayer(resources[settings.shape].location)).paths;
      props.paths.value = pathData.map(path => ({
        d: path.path,
        stroke: null,
        id: generateId(),
        fill: parseFill(path.fill)
      }));
    }
    if (settings.rect.w) {
      props.width.value = ze$1(settings.rect.w / existingData.replay.context.layout.width).value;
    }
    if (settings.rect.h) {
      props.height.value = ze$1(settings.rect.h / existingData.replay.context.layout.height).value;
    }
    props.shape.value = {
      id: resources[settings.shape].id,
      location: resources[settings.shape].location,
      type: 'svg'
    };
  };

  const loadImage = async url => new Promise((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.onload = () => {
      image.onload = null;
      resolve(image);
    };
    image.onerror = reject;
    image.src = url;
  });
  var loadImage$1 = withScheduler(loadImage);

  const hasProtocol = url => url.includes(':');

  const isAndroidProtocol = () => platformQuery === 'android';
  const isIOSProtocol = () => platformQuery === 'ios';
  const findMediaTypeUntilCanvasGroup = (replay, replayLayer, mediaType) => {
    const parentReplayLayer = et$1(replay, replayLayer.uuid);
    if (parentReplayLayer) {
      if (parentReplayLayer.mediaType === LayerMediaType.canvasGroup) {
        return null;
      }
      if (parentReplayLayer.mediaType === mediaType) {
        return parentReplayLayer;
      }
      return findMediaTypeUntilCanvasGroup(replay, parentReplayLayer, mediaType);
    }
    return null;
  };
  const parseImage = async (photo, resources, existingData) => {
    var _settings$mask;
    const imageSize = isIOSProtocol() || isAndroidProtocol() ? 0 : 1;
    if (!existingData.replay.context.layers[photo.uuid]) {
      var _existingData$selecte;
      const location = resources[photo.settings.photo].location;
      const newReplayLayer = Fe$1({
        name: 'image',
        mediaType: LayerMediaType.photo,
        uuid: photo.uuid,
        meta: photo.meta,
        props: {
          image: {
            id: resources[photo.settings.photo].id,
            location,
            type: 'photo',
            width: imageSize,
            height: imageSize
          }
        }
      });

      // selecting the newly created layer here
      (_existingData$selecte = existingData.selectedLayerIds) === null || _existingData$selecte === void 0 || _existingData$selecte.push(photo.uuid);

      // location of the image with localhost if needed
      const sanitizedLocation = hasProtocol(location) ? location : getImageUrl(location);
      const {
        width,
        height
      } = await loadImage$1(sanitizedLocation);
      if (width && height) {
        const scale = Math.min(existingData.replay.context.layout.width / width, existingData.replay.context.layout.height / height) * 0.9;
        newReplayLayer.props.scaleX.value = scale;
        newReplayLayer.props.scaleY.value = scale;
      }
      existingData.replay.context.layers[photo.uuid] = newReplayLayer;
      existingData.replay.context.layers[existingData.selectedCanvasId].props.children.value.push(photo.uuid);
    }
    const replayLayer = existingData.replay.context.layers[photo.uuid];
    const props = replayLayer.props;
    const settings = photo.settings;
    const imageLocation = resources[settings.photo].location;
    if (props.image.value.location !== imageLocation) {
      const renderedWidth = props.image.value.width * props.scaleX.value;
      const renderedHeight = props.image.value.height * props.scaleY.value;
      const {
        width,
        height
      } = await loadImage$1(imageLocation);
      props.scaleX.value = renderedWidth / width;
      props.scaleY.value = renderedHeight / height;
      props.image.value = {
        ...props.image.value,
        location: imageLocation,
        width: width,
        height: height,
        type: 'photo'
      };
      props.image.meta.originalUrl = imageLocation;
    }
    props.opacity.value = ze$1(parseOpacity(settings.opacity)).value;
    props.blendMode.value = parseBlendMode$1(settings.blendmode);
    if (settings.stroke) {
      props.stroke.value = parseStroke$1(settings.stroke);
    }
    if (settings.shadow) {
      props.shadow.value = parseShadow$1(settings.shadow);
    }
    if ((_settings$mask = settings.mask) !== null && _settings$mask !== void 0 && _settings$mask.mask) {
      if (!findMediaTypeUntilCanvasGroup(existingData.replay, replayLayer, LayerMediaType.maskGroup)) {
        const parentLayer = et$1(existingData.replay, replayLayer.uuid);
        const maskGroup = Ie$1({
          name: 'mask',
          mediaType: LayerMediaType.maskGroup,
          props: {
            width: props.image.value.width * props.scaleX.value / existingData.replay.context.layout.width,
            height: props.image.value.height * props.scaleY.value / existingData.replay.context.layout.height
          }
        });
        const uuid = generateId();
        const maskImageLayer = Fe$1({
          name: 'mask-image',
          mediaType: LayerMediaType.mask,
          uuid,
          props: {
            blendMode: 'xor',
            image: {
              id: uuid,
              type: 'photo',
              location: '',
              width: imageSize,
              height: imageSize
            }
          }
        });
        maskGroup.props.children.value.push(maskImageLayer.uuid, replayLayer.uuid);
        parentLayer.props.children.value = parentLayer.props.children.value.map(childUuid => childUuid === replayLayer.uuid ? maskGroup.uuid : childUuid);
      }
      const maskGroupReplayLayer = findMediaTypeUntilCanvasGroup(existingData.replay, replayLayer, LayerMediaType.maskGroup);
      const layers = tt$1(existingData.replay, maskGroupReplayLayer.uuid);
      const maskLayer = layers.find(layer => layer.mediaType === LayerMediaType.mask);
      if (maskLayer) {
        maskLayer.props.image.value = {
          ...maskLayer.props.image.value,
          location: resources[settings.mask.mask].location
        };
      }
    } else {
      const maskGroupReplayLayer = findMediaTypeUntilCanvasGroup(existingData.replay, replayLayer, LayerMediaType.maskGroup);
      if (maskGroupReplayLayer) {
        const maskLayerId = maskGroupReplayLayer.props.children.value.find(id => existingData.replay.context.layers[id].mediaType === LayerMediaType.mask);
        if (maskLayerId) {
          existingData.replay = nt$1(existingData.replay, maskLayerId);
        }
        existingData.replay = rt$1(existingData.replay, maskGroupReplayLayer.uuid);
        existingData.replay = nt$1(existingData.replay, maskGroupReplayLayer.uuid);
      }
    }
  };

  const blackListedLayers = [LayerMediaType.backgroundColor, LayerMediaType.collageCellGroup, LayerMediaType.canvasGroup, LayerMediaType.collageGroup, LayerMediaType.collageCell, LayerMediaType.cropGroup, LayerMediaType.crop, LayerMediaType.overlay, LayerMediaType.overlayGroup];
  const isBlackListedLayer = layer => blackListedLayers.includes(layer.mediaType);
  const isSimpleLayer = layer => Re$1(layer) || Ye$1(layer) || Ue$1(layer) || $e$1(layer);

  const DEFAULT_FONT_SIZE = 64;
  const hasLayersChange = context => {
    return typeof context.images !== 'undefined' || typeof context.stickers !== 'undefined' || typeof context.shapes !== 'undefined' || typeof context.videos !== 'undefined' || typeof context.texts !== 'undefined' || typeof context.resources !== 'undefined';
  };
  const toReplayV3FromV2 = async options => {
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const existingData = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$3.bootstrapPayload
    }) || {};
    if (isConfirmAction(options.data) && existingData.replay) {
      const layersChanged = hasLayersChange(options.data.payload);
      const asyncFunctions = [];
      existingData.selectedLayerIds = existingData.selectedLayerIds || [];
      const resources = options.data.payload.resources || {};
      if (layersChanged) {
        var _options$data$payload, _options$data$payload2, _options$data$payload3, _options$data$payload4, _options$data$payload5;
        const allLayersIds = [];
        (_options$data$payload = options.data.payload.videos) === null || _options$data$payload === void 0 || _options$data$payload.forEach(video => {
          allLayersIds.push(video.uuid);
          if (!existingData.replay.context.layers[video.uuid]) {
            var _existingData$selecte;
            existingData.replay.context.layers[video.uuid] = Ae$1({
              uuid: video.uuid,
              name: 'video',
              mediaType: LayerMediaType.video,
              props: {
                muted: false,
                repeat: false,
                speed: 1,
                volume: 1,
                trimEnd: 1,
                trimStart: 0,
                video: {},
                blendMode: parseBlendMode$1(video.settings.blendmode)
              }
            });
            existingData.replay.context.layers[existingData.selectedCanvasId].props.children.value.push(video.uuid);
            (_existingData$selecte = existingData.selectedLayerIds) === null || _existingData$selecte === void 0 || _existingData$selecte.push(video.uuid);
          }
          const replayLayer = existingData.replay.context.layers[video.uuid];
          const props = replayLayer.props;
          const settings = video.settings;
          props.duration.value = ze$1(video.settings.duration).value;
          props.startTime.value = ze$1(settings.start_time).value;
          props.trimStart.value = ze$1(settings.trim_start).value;
          props.trimEnd.value = ze$1(settings.trim_end).value;
          props.volume.value = ze$1(settings.volume).value;
          props.video.value = {
            ...props.video.value,
            location: resources[settings.video].location,
            type: 'video'
          };
          props.blendMode.value = parseBlendMode$1(settings.blendmode);
        });
        (_options$data$payload2 = options.data.payload.images) === null || _options$data$payload2 === void 0 || _options$data$payload2.forEach(photo => {
          allLayersIds.push(photo.uuid);
          asyncFunctions.push(parseImage(photo, resources, existingData));
        });
        (_options$data$payload3 = options.data.payload.stickers) === null || _options$data$payload3 === void 0 || _options$data$payload3.forEach(sticker => {
          allLayersIds.push(sticker.uuid);
          const resource = resources[sticker.settings.sticker];
          if (resource.type === 'photo') {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            asyncFunctions.push(parseImage({
              ...sticker,
              settings: {
                ...sticker.settings,
                photo: sticker.settings.sticker
              }
            }, resources, existingData));
          } else {
            asyncFunctions.push(parseShape({
              ...sticker,
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              settings: {
                ...sticker.settings,
                shape: sticker.settings.sticker
              }
            }, resources, existingData));
          }
        });
        (_options$data$payload4 = options.data.payload.texts) === null || _options$data$payload4 === void 0 || _options$data$payload4.forEach(text => {
          var _props$ranges$value$;
          allLayersIds.push(text.uuid);
          if (!existingData.replay.context.layers[text.uuid]) {
            var _existingData$selecte2;
            existingData.replay.context.layers[text.uuid] = Ne$1({
              uuid: text.uuid,
              name: 'text',
              mediaType: LayerMediaType.text,
              props: {
                ranges: [],
                width: 1,
                font: {}
              }
            });
            existingData.replay.context.layers[existingData.selectedCanvasId].props.children.value.push(text.uuid);
            (_existingData$selecte2 = existingData.selectedLayerIds) === null || _existingData$selecte2 === void 0 || _existingData$selecte2.push(text.uuid);
          }
          const replayLayer = existingData.replay.context.layers[text.uuid];
          const props = replayLayer.props;
          const settings = text.settings;
          props.alignment.value = settings.alignment === 'justify' ? 'center' : settings.alignment;
          props.letterSpacing.value = ze$1(settings.letter_spacing).value;
          props.lineHeight.value = ze$1(settings.line_spacing).value;
          props.bend.value = ze$1(settings.bend).value;
          if (settings.stroke) {
            props.stroke.value = parseStroke$1(settings.stroke);
          }
          if (settings.shadow) {
            props.shadow.value = parseShadow$1(settings.shadow);
          }
          props.opacity.value = ze$1(parseOpacity(settings.opacity)).value;
          props.blendMode.value = parseBlendMode$1(settings.blendmode);
          props.ranges.value = [{
            ...props.ranges.value[0],
            text: settings.text,
            fill: parsePattern$1(settings.fill),
            format: settings.format,
            fontSize: ((_props$ranges$value$ = props.ranges.value[0]) === null || _props$ranges$value$ === void 0 ? void 0 : _props$ranges$value$.fontSize) || DEFAULT_FONT_SIZE
          }];
          if (settings.font) {
            props.font.value = {
              ...resources[settings.font],
              id: text.meta.fontFamily || resources[settings.font].id,
              type: 'font'
            };
          }
          //   highlight?: V6TextHighlight;
        });
        (_options$data$payload5 = options.data.payload.shapes) === null || _options$data$payload5 === void 0 || _options$data$payload5.forEach(shape => {
          allLayersIds.push(shape.uuid);
          asyncFunctions.push(parseShape(shape, resources, existingData));
        });
        Object.values(existingData.replay.context.layers).forEach(layer => {
          if (!isBlackListedLayer(layer) && isSimpleLayer(layer) && !allLayersIds.includes(layer.uuid) && layer.mediaType !== LayerMediaType.mask) {
            existingData.replay = nt$1(existingData.replay, layer.uuid);
          }
        });
      }
      if (options.data.payload.artboard) {
        existingData.replay.context.layout.width = options.data.payload.artboard.width;
        existingData.replay.context.layout.height = options.data.payload.artboard.height;
      }
      await Promise.all(asyncFunctions);
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...options.data.payload,
            replay: layersChanged ? existingData.replay : undefined,
            selectedCanvasId: existingData.selectedCanvasId
          }
        }
      };
    }
    return options;
  };

  const jsonToStringJson = json => Object.entries(json).reduce((acc, _ref) => {
    let [key, value] = _ref;
    acc[key] = JSON.stringify(value);
    return acc;
  }, {});
  const parseBlendMode = blendMode => {
    return blendMode === 'source-over' ? 'normal' : blendMode.replaceAll('-', '_');
  };

  // const blackListedLayers = [
  //   LayerMediaType.backgroundColor,
  //   LayerMediaType.collageCellGroup,
  //   LayerMediaType.canvasGroup,
  //   LayerMediaType.backgroundImage,
  //   LayerMediaType.collageGroup,
  // ];

  const parseTransform = layer => {
    if (Ce$1(layer)) return defaultTransform;
    return {
      ...defaultTransform,
      position: {
        x: layer.props.x.value,
        y: layer.props.y.value
      },
      scale: layer.props.scaleX.value,
      rotation: layer.props.rotation.value,
      aspect_scale: layer.props.scaleX.value / layer.props.scaleY.value,
      flipped: {
        horizontal: layer.props.scaleX.value < 0,
        vertical: layer.props.scaleY.value < 0
      }
    };
  };
  const parseStroke = stroke => {
    if (!stroke) return;
    return {
      pattern: parsePattern(stroke.pattern),
      width: stroke.width,
      linecap: stroke.linecap,
      linejoin: stroke.linejoin
    };
  };
  const parseShadow = shadow => {
    if (!shadow) return;
    const {
      color,
      offset,
      blur
    } = shadow;
    return {
      color,
      offset_x: offset.x,
      offset_y: offset.y,
      blur
    };
  };
  const parsePattern = pattern => {
    var _pattern$gradient, _pattern$texture;
    const gradient = (_pattern$gradient = pattern.gradient) !== null && _pattern$gradient !== void 0 && _pattern$gradient.colors ? pattern.gradient : undefined;
    const v6Gradient = gradient && {
      colors: gradient.colors.map(_ref2 => {
        let {
          value
        } = _ref2;
        return value;
      }),
      angle: gradient.angle
    };
    return {
      solid: pattern.color,
      gradient: v6Gradient,
      texture: (_pattern$texture = pattern.texture) === null || _pattern$texture === void 0 ? void 0 : _pattern$texture.location,
      opacity: 1
    };
  };
  function fromReplayV3toV2(options) {
    if (!isConfirmAction(options.data) && !isBootstrapAction(options.data)) return options;
    const replay = options.data.payload.replay;
    const replayLayers = replay === null || replay === void 0 ? void 0 : replay.context.layers;
    const resources = {};
    const v2Layers = replayLayers && Object.values(replayLayers).reduce((acc, layer) => {
      if (isBlackListedLayer(layer)) return acc;
      if (Ye$1(layer)) {
        const resourceId = layer.props.video.value.id;
        resources[resourceId] = {
          ...layer.props.video.value,
          source: 'picsart'
        };
        const v2Layer = {
          settings: {
            video: resourceId,
            visible: true,
            start_time: layer.props.startTime.value,
            duration: layer.props.duration.value,
            trim_start: layer.props.trimStart.value,
            trim_end: layer.props.trimEnd.value,
            transform: parseTransform(layer),
            volume: layer.props.volume.value,
            blendmode: parseBlendMode(layer.props.blendMode.value)
          },
          meta: jsonToStringJson(layer.meta),
          type: 'video',
          uuid: layer.uuid
        };
        acc.videos.push(v2Layer);
      } else if ($e$1(layer) && layer.mediaType !== LayerMediaType.mask) {
        const isSticker = layer.mediaType === 'STICKER';
        const resourceId = layer.props.image.value.id;
        resources[resourceId] = {
          ...layer.props.image.value,
          source: 'picsart'
        };
        const parentReplayLayer = et$1(replay, layer.uuid);
        const isInCropGroup = parentReplayLayer.mediaType === 'CROP_GROUP';
        const possibleMaskGroup = isInCropGroup ? et$1(replay, parentReplayLayer.uuid) : parentReplayLayer;
        const isInMaskGroup = possibleMaskGroup.mediaType === LayerMediaType.maskGroup;
        const maskLayerId = isInMaskGroup && possibleMaskGroup.props.children.value.find(childId => replay.context.layers[childId].mediaType === 'MASK');
        const maskLayer = !!maskLayerId && replayLayers[maskLayerId];
        const maskResourceId = maskLayer ? maskLayer.props.image.value.id || maskLayer.uuid : '';
        if (maskLayer) {
          resources[maskResourceId] = {
            ...maskLayer.props.image.value,
            source: 'picsart'
          };
        }
        const props = {
          transform: parseTransform(layer),
          opacity: layer.props.opacity.value,
          blendmode: parseBlendMode(layer.props.blendMode.value),
          mask: {
            ...defaultMask,
            mask: maskResourceId
          },
          stroke: parseStroke(layer.props.stroke.value),
          shadow: parseShadow(layer.props.shadow.value)
        };
        if (isSticker) {
          const v2Layer = {
            settings: {
              sticker: resourceId,
              ...props
            },
            meta: jsonToStringJson(layer.meta),
            type: 'sticker',
            uuid: layer.uuid
          };
          acc.stickers.push(v2Layer);
          return acc;
        }
        const v2Layer = {
          settings: {
            photo: resourceId,
            ...props
          },
          meta: jsonToStringJson(layer.meta),
          type: isSticker ? 'sticker' : 'photo',
          uuid: layer.uuid
        };
        acc.images.push(v2Layer);
      } else if (Ue$1(layer)) {
        const resourceId = layer.props.font.value.id;
        resources[resourceId] = {
          ...layer.props.font.value,
          source: 'picsart'
        };
        const v2Layer = {
          settings: {
            text: layer.props.ranges.value.map(_ref3 => {
              let {
                text
              } = _ref3;
              return text;
            }).join(''),
            lines: [],
            font: resourceId,
            alignment: layer.props.alignment.value,
            letter_spacing: layer.props.letterSpacing.value,
            line_spacing: layer.props.lineHeight.value,
            bend: layer.props.bend.value,
            stroke: parseStroke(layer.props.stroke.value),
            shadow: parseShadow(layer.props.shadow.value),
            fill: parsePattern(layer.props.ranges.value[0].fill),
            opacity: layer.props.opacity.value,
            transform: parseTransform(layer),
            blendmode: parseBlendMode(layer.props.blendMode.value),
            format: layer.props.ranges.value[0].format,
            perspective_points: []
          },
          meta: jsonToStringJson(layer.meta),
          type: 'text',
          uuid: layer.uuid
        };
        acc.texts.push(v2Layer);
      } else if (Re$1(layer)) {
        const resourceId = layer.props.shape.value.id;
        resources[resourceId] = {
          ...layer.props.shape.value,
          source: 'picsart'
        };
        const v2Layer = {
          settings: {
            shape: resourceId,
            transform: parseTransform(layer),
            opacity: layer.props.opacity.value,
            blendmode: parseBlendMode(layer.props.blendMode.value),
            drawing_mode: 'fill_inside',
            stroke: parseStroke(layer.props.stroke.value),
            shadow: parseShadow(layer.props.shadow.value),
            adjust: layer.props.paths.value.map(adjust => ({
              ...adjust,
              path: adjust.d,
              fill: parsePattern(adjust.fill),
              stroke: parseStroke(adjust.stroke)
            })),
            rect: {
              w: layer.props.width.value * (replay === null || replay === void 0 ? void 0 : replay.context.layout.width),
              h: layer.props.height.value * (replay === null || replay === void 0 ? void 0 : replay.context.layout.height),
              x: 0,
              y: 0
            }
          },
          meta: jsonToStringJson(layer.meta),
          type: 'shape',
          uuid: layer.uuid
        };
        acc.shapes.push(v2Layer);
      }
      return acc;
    }, {
      videos: [],
      images: [],
      stickers: [],
      texts: [],
      shapes: []
    });
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          ...options.data.payload,
          ...v2Layers,
          resources,
          ...(replay && {
            artboard: {
              width: replay.context.layout.width,
              height: replay.context.layout.height
            }
          })
        }
      }
    };
  }

  const sendDialogMessageResolver = options => {
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const dialogResolveIds = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: 'v8DialogResolveIds'
    }) || [];
    if (!dialogResolveIds.length) return options;
    if (!dialogResolveIds.includes(options.data.payload.resolveId)) return options;
    const payload = options.data.payload;
    const {
      result
    } = payload.result;
    const isDismissed = result === 'dismissed';
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          ...payload,
          result: {
            reason: isDismissed ? 'dismiss' : 'success',
            buttonIndex: isDismissed ? -1 : result === 'primary' ? 0 : 1
          }
        }
      }
    };
  };

  function sendNotifierMessage(options) {
    if (!isShowNotifierMessageAction(options.data)) return options;
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          type: options.data.payload.type,
          params: options.data.payload.options
        }
      }
    };
  }

  function openFileChooserResponse(options) {
    if (!isOpenFileChooserResponseAction(options.data)) return options;
    const photoResources = options.data.payload.resources.filter(resource => resource.type === 'photo');
    const videoResources = options.data.payload.resources.filter(resource => resource.type === 'video');
    return {
      ...options,
      data: {
        ...options.data,
        payload: {
          images: photoResources.map(resource => ({
            settings: {
              ...defaultImageLayerParams,
              photo: resource.id
            },
            uuid: generateId(),
            type: 'photo',
            meta: {}
          })),
          videos: videoResources.map(resource => ({
            settings: {
              ...defaultVideoLayerParams,
              video: resource.id
            },
            uuid: generateId(),
            type: 'video',
            meta: {}
          })),
          texts: [],
          resources: options.data.payload.resources.reduce((acc, resource) => {
            acc[resource.id] = {
              location: hasProtocol(resource.location) ? resource.location : getImageUrl(resource.location),
              type: resource.type,
              id: resource.id,
              source: 'user_generated'
            };
            return acc;
          }, {})
        }
      }
    };
  }

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV7ToV8Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v7',
      migrateTo: 'v8'
    }, [exportFiles, sendDialogMessage, sendNotifierMessage, toReplayV3FromV2]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV8ToV7Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v8',
      migrateTo: 'v7'
    }, [receiveMessages$5, sendDialogMessageResolver, generateResultImageResponse, fromReplayV3toV2, openFileChooserResponse]);
  }

  var e$1 = Symbol.for("immer-nothing"),
    t$1 = Symbol.for("immer-draftable"),
    r$1 = Symbol.for("immer-state");
  function o$1(e) {
    throw new Error("[Immer] minified error nr: ".concat(e, ". Full error at: https://bit.ly/3cXEKWf"));
  }
  var a = Object.getPrototypeOf;
  function i$1(e) {
    return !!e && !!e[r$1];
  }
  function c$1(e) {
    var _e$constructor;
    return !!e && (u$1(e) || Array.isArray(e) || !!e[t$1] || !!((_e$constructor = e.constructor) !== null && _e$constructor !== void 0 && _e$constructor[t$1]) || y$1(e) || h$1(e));
  }
  var s$1 = Object.prototype.constructor.toString();
  function u$1(e) {
    if (!e || "object" != typeof e) return !1;
    const t = a(e);
    if (null === t) return !0;
    const r = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
    return r === Object || "function" == typeof r && Function.toString.call(r) === s$1;
  }
  function l$1(e, t) {
    0 === p$1(e) ? Object.entries(e).forEach(_ref => {
      let [r, n] = _ref;
      t(r, n, e);
    }) : e.forEach((r, n) => t(n, r, e));
  }
  function p$1(e) {
    const t = e[r$1];
    return t ? t.type_ : Array.isArray(e) ? 1 : y$1(e) ? 2 : h$1(e) ? 3 : 0;
  }
  function f$1(e, t) {
    return 2 === p$1(e) ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t);
  }
  function d$1(e, t, r) {
    const n = p$1(e);
    2 === n ? e.set(t, r) : 3 === n ? e.add(r) : e[t] = r;
  }
  function y$1(e) {
    return e instanceof Map;
  }
  function h$1(e) {
    return e instanceof Set;
  }
  function v$1(e) {
    return e.copy_ || e.base_;
  }
  function _$1(e, t) {
    if (y$1(e)) return new Map(e);
    if (h$1(e)) return new Set(e);
    if (Array.isArray(e)) return Array.prototype.slice.call(e);
    if (!t && u$1(e)) {
      if (!a(e)) {
        const t = Object.create(null);
        return Object.assign(t, e);
      }
      return {
        ...e
      };
    }
    const n = Object.getOwnPropertyDescriptors(e);
    delete n[r$1];
    let o = Reflect.ownKeys(n);
    for (let t = 0; t < o.length; t++) {
      const r = o[t],
        a = n[r];
      !1 === a.writable && (a.writable = !0, a.configurable = !0), (a.get || a.set) && (n[r] = {
        configurable: !0,
        writable: !0,
        enumerable: a.enumerable,
        value: e[r]
      });
    }
    return Object.create(a(e), n);
  }
  function b$1(e) {
    let t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    return g$1(e) || i$1(e) || !c$1(e) || (p$1(e) > 1 && (e.set = e.add = e.clear = e.delete = m$1), Object.freeze(e), t && l$1(e, (e, t) => b$1(t, !0))), e;
  }
  function m$1() {
    o$1(2);
  }
  function g$1(e) {
    return Object.isFrozen(e);
  }
  var j$1,
    O$1 = {};
  function w$1(e) {
    const t = O$1[e];
    return t || o$1(0), t;
  }
  function A$1() {
    return j$1;
  }
  function S$1(e, t) {
    t && (w$1("Patches"), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
  }
  function x$1(e) {
    z$1(e), e.drafts_.forEach(E$1), e.drafts_ = null;
  }
  function z$1(e) {
    e === j$1 && (j$1 = e.parent_);
  }
  function P$1(e) {
    return j$1 = {
      drafts_: [],
      parent_: j$1,
      immer_: e,
      canAutoFreeze_: !0,
      unfinalizedDrafts_: 0
    };
  }
  function E$1(e) {
    const t = e[r$1];
    0 === t.type_ || 1 === t.type_ ? t.revoke_() : t.revoked_ = !0;
  }
  function k$1(t, n) {
    n.unfinalizedDrafts_ = n.drafts_.length;
    const a = n.drafts_[0];
    return void 0 !== t && t !== a ? (a[r$1].modified_ && (x$1(n), o$1(4)), c$1(t) && (t = I$1(n, t), n.parent_ || F$1(n, t)), n.patches_ && w$1("Patches").generateReplacementPatches_(a[r$1].base_, t, n.patches_, n.inversePatches_)) : t = I$1(n, a, []), x$1(n), n.patches_ && n.patchListener_(n.patches_, n.inversePatches_), t !== e$1 ? t : void 0;
  }
  function I$1(e, t, n) {
    if (g$1(t)) return t;
    const o = t[r$1];
    if (!o) return l$1(t, (r, a) => D$1(e, o, t, r, a, n)), t;
    if (o.scope_ !== e) return t;
    if (!o.modified_) return F$1(e, o.base_, !0), o.base_;
    if (!o.finalized_) {
      o.finalized_ = !0, o.scope_.unfinalizedDrafts_--;
      const t = o.copy_;
      let r = t,
        a = !1;
      3 === o.type_ && (r = new Set(t), t.clear(), a = !0), l$1(r, (r, i) => D$1(e, o, t, r, i, n, a)), F$1(e, t, !1), n && e.patches_ && w$1("Patches").generatePatches_(o, n, e.patches_, e.inversePatches_);
    }
    return o.copy_;
  }
  function D$1(e, t, r, n, a, s, u) {
    if (i$1(a)) {
      const o = I$1(e, a, s && t && 3 !== t.type_ && !f$1(t.assigned_, n) ? s.concat(n) : void 0);
      if (d$1(r, n, o), !i$1(o)) return;
      e.canAutoFreeze_ = !1;
    } else u && r.add(a);
    if (c$1(a) && !g$1(a)) {
      if (!e.immer_.autoFreeze_ && e.unfinalizedDrafts_ < 1) return;
      I$1(e, a), t && t.scope_.parent_ || F$1(e, a);
    }
  }
  function F$1(e, t) {
    let r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
    !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && b$1(t, r);
  }
  var N$1 = {
      get(e, t) {
        if (t === r$1) return e;
        const n = v$1(e);
        if (!f$1(n, t)) return function (e, t, r, _n$get) {
          const n = M$1(t, r);
          return n ? "value" in n ? n.value : (_n$get = n.get) === null || _n$get === void 0 ? void 0 : _n$get.call(e.draft_) : void 0;
        }(e, n, t);
        const o = n[t];
        return e.finalized_ || !c$1(o) ? o : o === T$1(e.base_, t) ? (C$1(e), e.copy_[t] = L$1(o, e)) : o;
      },
      has: (e, t) => t in v$1(e),
      ownKeys: e => Reflect.ownKeys(v$1(e)),
      set(e, t, n) {
        const o = M$1(v$1(e), t);
        if (o !== null && o !== void 0 && o.set) return o.set.call(e.draft_, n), !0;
        if (!e.modified_) {
          const o = T$1(v$1(e), t),
            c = o === null || o === void 0 ? void 0 : o[r$1];
          if (c && c.base_ === n) return e.copy_[t] = n, e.assigned_[t] = !1, !0;
          if (((a = n) === (i = o) ? 0 !== a || 1 / a == 1 / i : a != a && i != i) && (void 0 !== n || f$1(e.base_, t))) return !0;
          C$1(e), U$1(e);
        }
        var a, i;
        return e.copy_[t] === n && (void 0 !== n || t in e.copy_) || Number.isNaN(n) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = n, e.assigned_[t] = !0), !0;
      },
      deleteProperty: (e, t) => (void 0 !== T$1(e.base_, t) || t in e.base_ ? (e.assigned_[t] = !1, C$1(e), U$1(e)) : delete e.assigned_[t], e.copy_ && delete e.copy_[t], !0),
      getOwnPropertyDescriptor(e, t) {
        const r = v$1(e),
          n = Reflect.getOwnPropertyDescriptor(r, t);
        return n ? {
          writable: !0,
          configurable: 1 !== e.type_ || "length" !== t,
          enumerable: n.enumerable,
          value: r[t]
        } : n;
      },
      defineProperty() {
        o$1(11);
      },
      getPrototypeOf: e => a(e.base_),
      setPrototypeOf() {
        o$1(12);
      }
    },
    R$1 = {};
  function T$1(e, t) {
    const n = e[r$1];
    return (n ? v$1(n) : e)[t];
  }
  function M$1(e, t) {
    if (!(t in e)) return;
    let r = a(e);
    for (; r;) {
      const e = Object.getOwnPropertyDescriptor(r, t);
      if (e) return e;
      r = a(r);
    }
  }
  function U$1(e) {
    e.modified_ || (e.modified_ = !0, e.parent_ && U$1(e.parent_));
  }
  function C$1(e) {
    e.copy_ || (e.copy_ = _$1(e.base_, e.scope_.immer_.useStrictShallowCopy_));
  }
  l$1(N$1, (e, t) => {
    R$1[e] = function () {
      return arguments[0] = arguments[0][0], t.apply(this, arguments);
    };
  }), R$1.deleteProperty = function (e, t) {
    return R$1.set.call(this, e, t, void 0);
  }, R$1.set = function (e, t, r) {
    return N$1.set.call(this, e[0], t, r, e[0]);
  };
  function L$1(e, t) {
    const r = y$1(e) ? w$1("MapSet").proxyMap_(e, t) : h$1(e) ? w$1("MapSet").proxySet_(e, t) : function (e, t) {
      const r = Array.isArray(e),
        n = {
          type_: r ? 1 : 0,
          scope_: t ? t.scope_ : A$1(),
          modified_: !1,
          finalized_: !1,
          assigned_: {},
          parent_: t,
          base_: e,
          draft_: null,
          copy_: null,
          revoke_: null,
          isManual_: !1
        };
      let o = n,
        a = N$1;
      r && (o = [n], a = R$1);
      const {
        revoke: i,
        proxy: c
      } = Proxy.revocable(o, a);
      return n.draft_ = c, n.revoke_ = i, c;
    }(e, t);
    return (t ? t.scope_ : A$1()).drafts_.push(r), r;
  }
  function $$1(e) {
    return i$1(e) || o$1(10), V$1(e);
  }
  function V$1(e) {
    if (!c$1(e) || g$1(e)) return e;
    const t = e[r$1];
    let n;
    if (t) {
      if (!t.modified_) return t.base_;
      t.finalized_ = !0, n = _$1(e, t.scope_.immer_.useStrictShallowCopy_);
    } else n = _$1(e, !0);
    return l$1(n, (e, t) => {
      d$1(n, e, V$1(t));
    }), t && (t.finalized_ = !1), n;
  }
  var B$1 = new class {
      constructor(t) {
        var _this = this;
        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.produce = (t, r, n) => {
          if ("function" == typeof t && "function" != typeof r) {
            const e = r;
            r = t;
            const n = this;
            return function () {
              let t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : e;
              for (var _len2 = arguments.length, o = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
                o[_key2 - 1] = arguments[_key2];
              }
              return n.produce(t, e => r.call(this, e, ...o));
            };
          }
          let a;
          if ("function" != typeof r && o$1(6), void 0 !== n && "function" != typeof n && o$1(7), c$1(t)) {
            const e = P$1(this),
              o = L$1(t, void 0);
            let i = !0;
            try {
              a = r(o), i = !1;
            } finally {
              i ? x$1(e) : z$1(e);
            }
            return S$1(e, n), k$1(a, e);
          }
          if (!t || "object" != typeof t) {
            if (a = r(t), void 0 === a && (a = t), a === e$1 && (a = void 0), this.autoFreeze_ && b$1(a, !0), n) {
              const e = [],
                r = [];
              w$1("Patches").generateReplacementPatches_(t, a, e, r), n(e, r);
            }
            return a;
          }
          o$1(1);
        }, this.produceWithPatches = (e, t) => {
          if ("function" == typeof e) return function (t) {
            for (var _len3 = arguments.length, r = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
              r[_key3 - 1] = arguments[_key3];
            }
            return _this.produceWithPatches(t, t => e(t, ...r));
          };
          let r, n;
          return [this.produce(e, t, (e, t) => {
            r = e, n = t;
          }), r, n];
        }, "boolean" == typeof (t === null || t === void 0 ? void 0 : t.autoFreeze) && this.setAutoFreeze(t.autoFreeze), "boolean" == typeof (t === null || t === void 0 ? void 0 : t.useStrictShallowCopy) && this.setUseStrictShallowCopy(t.useStrictShallowCopy);
      }
      createDraft(e) {
        c$1(e) || o$1(8), i$1(e) && (e = $$1(e));
        const t = P$1(this),
          n = L$1(e, void 0);
        return n[r$1].isManual_ = !0, z$1(t), n;
      }
      finishDraft(e, t) {
        const n = e && e[r$1];
        n && n.isManual_ || o$1(9);
        const {
          scope_: a
        } = n;
        return S$1(a, t), k$1(void 0, a);
      }
      setAutoFreeze(e) {
        this.autoFreeze_ = e;
      }
      setUseStrictShallowCopy(e) {
        this.useStrictShallowCopy_ = e;
      }
      applyPatches(e, t) {
        let r;
        for (r = t.length - 1; r >= 0; r--) {
          const n = t[r];
          if (0 === n.path.length && "replace" === n.op) {
            e = n.value;
            break;
          }
        }
        r > -1 && (t = t.slice(r + 1));
        const n = w$1("Patches").applyPatches_;
        return i$1(e) ? n(e, t) : this.produce(e, e => n(e, t));
      }
    }(),
    G$1 = B$1.produce;
  B$1.produceWithPatches.bind(B$1);
  var W$1 = B$1.setAutoFreeze.bind(B$1);
  let J$1;
  B$1.setUseStrictShallowCopy.bind(B$1), B$1.applyPatches.bind(B$1), B$1.createDraft.bind(B$1), B$1.finishDraft.bind(B$1);
  const K$1 = new Uint8Array(16);
  function q$1() {
    if (!J$1 && (J$1 = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !J$1)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    return J$1(K$1);
  }
  const X$1 = [];
  for (let e = 0; e < 256; ++e) X$1.push((e + 256).toString(16).slice(1));
  var Y$1 = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
  };
  function H$1(e, t, r) {
    if (Y$1.randomUUID && !t && !e) return Y$1.randomUUID();
    const n = (e = e || {}).random || (e.rng || q$1)();
    if (n[6] = 15 & n[6] | 64, n[8] = 63 & n[8] | 128, t) ;
    return function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      return X$1[e[t + 0]] + X$1[e[t + 1]] + X$1[e[t + 2]] + X$1[e[t + 3]] + "-" + X$1[e[t + 4]] + X$1[e[t + 5]] + "-" + X$1[e[t + 6]] + X$1[e[t + 7]] + "-" + X$1[e[t + 8]] + X$1[e[t + 9]] + "-" + X$1[e[t + 10]] + X$1[e[t + 11]] + X$1[e[t + 12]] + X$1[e[t + 13]] + X$1[e[t + 14]] + X$1[e[t + 15]];
    }(n);
  }
  const Z$1 = "root";
  var ee$1 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  function te$1(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
  }
  var re = function () {
    this.__data__ = [], this.size = 0;
  };
  var ne = function (e, t) {
      return e === t || e != e && t != t;
    },
    oe = ne;
  var ae = function (e, t) {
      for (var r = e.length; r--;) if (oe(e[r][0], t)) return r;
      return -1;
    },
    ie = ae,
    ce = Array.prototype.splice;
  var se = ae;
  var ue = ae;
  var le = ae;
  var pe = re,
    fe = function (e) {
      var t = this.__data__,
        r = ie(t, e);
      return !(r < 0) && (r == t.length - 1 ? t.pop() : ce.call(t, r, 1), --this.size, !0);
    },
    de = function (e) {
      var t = this.__data__,
        r = se(t, e);
      return r < 0 ? void 0 : t[r][1];
    },
    ye = function (e) {
      return ue(this.__data__, e) > -1;
    },
    he = function (e, t) {
      var r = this.__data__,
        n = le(r, e);
      return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this;
    };
  function ve(e) {
    var t = -1,
      r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
      var n = e[t];
      this.set(n[0], n[1]);
    }
  }
  ve.prototype.clear = pe, ve.prototype.delete = fe, ve.prototype.get = de, ve.prototype.has = ye, ve.prototype.set = he;
  var _e = ve,
    be = _e;
  var me = function () {
    this.__data__ = new be(), this.size = 0;
  };
  var ge = function (e) {
    var t = this.__data__,
      r = t.delete(e);
    return this.size = t.size, r;
  };
  var je = function (e) {
    return this.__data__.get(e);
  };
  var Oe = function (e) {
      return this.__data__.has(e);
    },
    we = "object" == typeof ee$1 && ee$1 && ee$1.Object === Object && ee$1,
    Ae = we,
    Se = "object" == typeof self && self && self.Object === Object && self,
    xe = Ae || Se || Function("return this")(),
    ze = xe.Symbol,
    Pe = ze,
    Ee = Object.prototype,
    ke = Ee.hasOwnProperty,
    Ie = Ee.toString,
    De = Pe ? Pe.toStringTag : void 0;
  var Fe = function (e) {
      var t = ke.call(e, De),
        r = e[De];
      try {
        e[De] = void 0;
        var n = !0;
      } catch (e) {}
      var o = Ie.call(e);
      return n && (t ? e[De] = r : delete e[De]), o;
    },
    Ne = Object.prototype.toString;
  var Re = Fe,
    Te = function (e) {
      return Ne.call(e);
    },
    Me = ze ? ze.toStringTag : void 0;
  var Ue = function (e) {
    return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : Me && Me in Object(e) ? Re(e) : Te(e);
  };
  var Ce = function (e) {
      var t = typeof e;
      return null != e && ("object" == t || "function" == t);
    },
    Le = Ue,
    $e = Ce;
  var Ve,
    Be = function (e) {
      if (!$e(e)) return !1;
      var t = Le(e);
      return "[object Function]" == t || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t;
    },
    Ge = xe["__core-js_shared__"],
    We = (Ve = /[^.]+$/.exec(Ge && Ge.keys && Ge.keys.IE_PROTO || "")) ? "Symbol(src)_1." + Ve : "";
  var Je = function (e) {
      return !!We && We in e;
    },
    Ke = Function.prototype.toString;
  var qe = function (e) {
      if (null != e) {
        try {
          return Ke.call(e);
        } catch (e) {}
        try {
          return e + "";
        } catch (e) {}
      }
      return "";
    },
    Xe = Be,
    Ye = Je,
    He = Ce,
    Qe = qe,
    Ze = /^\[object .+?Constructor\]$/,
    et = Function.prototype,
    tt = Object.prototype,
    rt = et.toString,
    nt = tt.hasOwnProperty,
    ot = RegExp("^" + rt.call(nt).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  var at = function (e) {
      return !(!He(e) || Ye(e)) && (Xe(e) ? ot : Ze).test(Qe(e));
    },
    it = function (e, t) {
      return null == e ? void 0 : e[t];
    };
  var ct = function (e, t) {
      var r = it(e, t);
      return at(r) ? r : void 0;
    },
    st = ct(xe, "Map"),
    ut = ct(Object, "create"),
    lt = ut;
  var pt = function () {
    this.__data__ = lt ? lt(null) : {}, this.size = 0;
  };
  var ft = function (e) {
      var t = this.has(e) && delete this.__data__[e];
      return this.size -= t ? 1 : 0, t;
    },
    dt = ut,
    yt = Object.prototype.hasOwnProperty;
  var ht = function (e) {
      var t = this.__data__;
      if (dt) {
        var r = t[e];
        return "__lodash_hash_undefined__" === r ? void 0 : r;
      }
      return yt.call(t, e) ? t[e] : void 0;
    },
    vt = ut,
    _t = Object.prototype.hasOwnProperty;
  var bt = ut;
  var mt = pt,
    gt = ft,
    jt = ht,
    Ot = function (e) {
      var t = this.__data__;
      return vt ? void 0 !== t[e] : _t.call(t, e);
    },
    wt = function (e, t) {
      var r = this.__data__;
      return this.size += this.has(e) ? 0 : 1, r[e] = bt && void 0 === t ? "__lodash_hash_undefined__" : t, this;
    };
  function At(e) {
    var t = -1,
      r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
      var n = e[t];
      this.set(n[0], n[1]);
    }
  }
  At.prototype.clear = mt, At.prototype.delete = gt, At.prototype.get = jt, At.prototype.has = Ot, At.prototype.set = wt;
  var St = At,
    xt = _e,
    zt = st;
  var Pt = function (e) {
    var t = typeof e;
    return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e;
  };
  var Et = function (e, t) {
      var r = e.__data__;
      return Pt(t) ? r["string" == typeof t ? "string" : "hash"] : r.map;
    },
    kt = Et;
  var It = Et;
  var Dt = Et;
  var Ft = Et;
  var Nt = function () {
      this.size = 0, this.__data__ = {
        hash: new St(),
        map: new (zt || xt)(),
        string: new St()
      };
    },
    Rt = function (e) {
      var t = kt(this, e).delete(e);
      return this.size -= t ? 1 : 0, t;
    },
    Tt = function (e) {
      return It(this, e).get(e);
    },
    Mt = function (e) {
      return Dt(this, e).has(e);
    },
    Ut = function (e, t) {
      var r = Ft(this, e),
        n = r.size;
      return r.set(e, t), this.size += r.size == n ? 0 : 1, this;
    };
  function Ct(e) {
    var t = -1,
      r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
      var n = e[t];
      this.set(n[0], n[1]);
    }
  }
  Ct.prototype.clear = Nt, Ct.prototype.delete = Rt, Ct.prototype.get = Tt, Ct.prototype.has = Mt, Ct.prototype.set = Ut;
  var Lt = Ct,
    $t = _e,
    Vt = st,
    Bt = Lt;
  var Gt = _e,
    Wt = me,
    Jt = ge,
    Kt = je,
    qt = Oe,
    Xt = function (e, t) {
      var r = this.__data__;
      if (r instanceof $t) {
        var n = r.__data__;
        if (!Vt || n.length < 199) return n.push([e, t]), this.size = ++r.size, this;
        r = this.__data__ = new Bt(n);
      }
      return r.set(e, t), this.size = r.size, this;
    };
  function Yt(e) {
    var t = this.__data__ = new Gt(e);
    this.size = t.size;
  }
  Yt.prototype.clear = Wt, Yt.prototype.delete = Jt, Yt.prototype.get = Kt, Yt.prototype.has = qt, Yt.prototype.set = Xt;
  var Ht = Yt;
  var Qt = Lt,
    Zt = function (e) {
      return this.__data__.set(e, "__lodash_hash_undefined__"), this;
    },
    er = function (e) {
      return this.__data__.has(e);
    };
  function tr(e) {
    var t = -1,
      r = null == e ? 0 : e.length;
    for (this.__data__ = new Qt(); ++t < r;) this.add(e[t]);
  }
  tr.prototype.add = tr.prototype.push = Zt, tr.prototype.has = er;
  var rr = tr,
    nr = function (e, t) {
      for (var r = -1, n = null == e ? 0 : e.length; ++r < n;) if (t(e[r], r, e)) return !0;
      return !1;
    },
    or = function (e, t) {
      return e.has(t);
    };
  var ar = function (e, t, r, n, o, a) {
    var i = 1 & r,
      c = e.length,
      s = t.length;
    if (c != s && !(i && s > c)) return !1;
    var u = a.get(e),
      l = a.get(t);
    if (u && l) return u == t && l == e;
    var p = -1,
      f = !0,
      d = 2 & r ? new rr() : void 0;
    for (a.set(e, t), a.set(t, e); ++p < c;) {
      var y = e[p],
        h = t[p];
      if (n) var v = i ? n(h, y, p, t, e, a) : n(y, h, p, e, t, a);
      if (void 0 !== v) {
        if (v) continue;
        f = !1;
        break;
      }
      if (d) {
        if (!nr(t, function (e, t) {
          if (!or(d, t) && (y === e || o(y, e, r, n, a))) return d.push(t);
        })) {
          f = !1;
          break;
        }
      } else if (y !== h && !o(y, h, r, n, a)) {
        f = !1;
        break;
      }
    }
    return a.delete(e), a.delete(t), f;
  };
  var ir = function (e) {
      var t = -1,
        r = Array(e.size);
      return e.forEach(function (e) {
        r[++t] = e;
      }), r;
    },
    cr = xe.Uint8Array,
    sr = ne,
    ur = ar,
    lr = function (e) {
      var t = -1,
        r = Array(e.size);
      return e.forEach(function (e, n) {
        r[++t] = [n, e];
      }), r;
    },
    pr = ir,
    fr = ze ? ze.prototype : void 0,
    dr = fr ? fr.valueOf : void 0;
  var yr = function (e, t, r, n, o, a, i) {
    switch (r) {
      case "[object DataView]":
        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
        e = e.buffer, t = t.buffer;
      case "[object ArrayBuffer]":
        return !(e.byteLength != t.byteLength || !a(new cr(e), new cr(t)));
      case "[object Boolean]":
      case "[object Date]":
      case "[object Number]":
        return sr(+e, +t);
      case "[object Error]":
        return e.name == t.name && e.message == t.message;
      case "[object RegExp]":
      case "[object String]":
        return e == t + "";
      case "[object Map]":
        var c = lr;
      case "[object Set]":
        var s = 1 & n;
        if (c || (c = pr), e.size != t.size && !s) return !1;
        var u = i.get(e);
        if (u) return u == t;
        n |= 2, i.set(e, t);
        var l = ur(c(e), c(t), n, o, a, i);
        return i.delete(e), l;
      case "[object Symbol]":
        if (dr) return dr.call(e) == dr.call(t);
    }
    return !1;
  };
  var hr = function (e, t) {
      for (var r = -1, n = t.length, o = e.length; ++r < n;) e[o + r] = t[r];
      return e;
    },
    vr = Array.isArray,
    _r = hr,
    br = vr;
  var mr = function (e, t, r) {
    var n = t(e);
    return br(e) ? n : _r(n, r(e));
  };
  var gr = function (e, t) {
      for (var r = -1, n = null == e ? 0 : e.length, o = 0, a = []; ++r < n;) {
        var i = e[r];
        t(i, r, e) && (a[o++] = i);
      }
      return a;
    },
    jr = function () {
      return [];
    },
    Or = Object.prototype.propertyIsEnumerable,
    wr = Object.getOwnPropertySymbols,
    Ar = wr ? function (e) {
      return null == e ? [] : (e = Object(e), gr(wr(e), function (t) {
        return Or.call(e, t);
      }));
    } : jr;
  var Sr = function (e, t) {
    for (var r = -1, n = Array(e); ++r < e;) n[r] = t(r);
    return n;
  };
  var xr = function (e) {
      return null != e && "object" == typeof e;
    },
    zr = Ue,
    Pr = xr;
  var Er = function (e) {
      return Pr(e) && "[object Arguments]" == zr(e);
    },
    kr = xr,
    Ir = Object.prototype,
    Dr = Ir.hasOwnProperty,
    Fr = Ir.propertyIsEnumerable,
    Nr = Er(function () {
      return arguments;
    }()) ? Er : function (e) {
      return kr(e) && Dr.call(e, "callee") && !Fr.call(e, "callee");
    },
    Rr = {
      exports: {}
    };
  var Tr = function () {
    return !1;
  };
  !function (e, t) {
    var r = xe,
      n = Tr,
      o = t && !t.nodeType && t,
      a = o && e && !e.nodeType && e,
      i = a && a.exports === o ? r.Buffer : void 0,
      c = (i ? i.isBuffer : void 0) || n;
    e.exports = c;
  }(Rr, Rr.exports);
  var Mr = Rr.exports,
    Ur = /^(?:0|[1-9]\d*)$/;
  var Cr = function (e, t) {
    var r = typeof e;
    return !!(t = null == t ? 9007199254740991 : t) && ("number" == r || "symbol" != r && Ur.test(e)) && e > -1 && e % 1 == 0 && e < t;
  };
  var Lr = function (e) {
      return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991;
    },
    $r = Ue,
    Vr = Lr,
    Br = xr,
    Gr = {};
  Gr["[object Float32Array]"] = Gr["[object Float64Array]"] = Gr["[object Int8Array]"] = Gr["[object Int16Array]"] = Gr["[object Int32Array]"] = Gr["[object Uint8Array]"] = Gr["[object Uint8ClampedArray]"] = Gr["[object Uint16Array]"] = Gr["[object Uint32Array]"] = !0, Gr["[object Arguments]"] = Gr["[object Array]"] = Gr["[object ArrayBuffer]"] = Gr["[object Boolean]"] = Gr["[object DataView]"] = Gr["[object Date]"] = Gr["[object Error]"] = Gr["[object Function]"] = Gr["[object Map]"] = Gr["[object Number]"] = Gr["[object Object]"] = Gr["[object RegExp]"] = Gr["[object Set]"] = Gr["[object String]"] = Gr["[object WeakMap]"] = !1;
  var Wr = function (e) {
    return Br(e) && Vr(e.length) && !!Gr[$r(e)];
  };
  var Jr = function (e) {
      return function (t) {
        return e(t);
      };
    },
    Kr = {
      exports: {}
    };
  !function (e, t) {
    var r = we,
      n = t && !t.nodeType && t,
      o = n && e && !e.nodeType && e,
      a = o && o.exports === n && r.process,
      i = function () {
        try {
          var e = o && o.require && o.require("util").types;
          return e || a && a.binding && a.binding("util");
        } catch (e) {}
      }();
    e.exports = i;
  }(Kr, Kr.exports);
  var qr = Kr.exports,
    Xr = Wr,
    Yr = Jr,
    Hr = qr && qr.isTypedArray,
    Qr = Hr ? Yr(Hr) : Xr,
    Zr = Sr,
    en = Nr,
    tn = vr,
    rn = Mr,
    nn = Cr,
    on = Qr,
    an = Object.prototype.hasOwnProperty;
  var cn = function (e, t) {
      var r = tn(e),
        n = !r && en(e),
        o = !r && !n && rn(e),
        a = !r && !n && !o && on(e),
        i = r || n || o || a,
        c = i ? Zr(e.length, String) : [],
        s = c.length;
      for (var u in e) !t && !an.call(e, u) || i && ("length" == u || o && ("offset" == u || "parent" == u) || a && ("buffer" == u || "byteLength" == u || "byteOffset" == u) || nn(u, s)) || c.push(u);
      return c;
    },
    sn = Object.prototype;
  var un = function (e) {
    var t = e && e.constructor;
    return e === ("function" == typeof t && t.prototype || sn);
  };
  var ln = function (e, t) {
      return function (r) {
        return e(t(r));
      };
    }(Object.keys, Object),
    pn = un,
    fn = ln,
    dn = Object.prototype.hasOwnProperty;
  var yn = Be,
    hn = Lr;
  var vn = cn,
    _n = function (e) {
      if (!pn(e)) return fn(e);
      var t = [];
      for (var r in Object(e)) dn.call(e, r) && "constructor" != r && t.push(r);
      return t;
    },
    bn = function (e) {
      return null != e && hn(e.length) && !yn(e);
    };
  var mn = mr,
    gn = Ar,
    jn = function (e) {
      return bn(e) ? vn(e) : _n(e);
    };
  var On = function (e) {
      return mn(e, jn, gn);
    },
    wn = Object.prototype.hasOwnProperty;
  var An = function (e, t, r, n, o, a) {
      var i = 1 & r,
        c = On(e),
        s = c.length;
      if (s != On(t).length && !i) return !1;
      for (var u = s; u--;) {
        var l = c[u];
        if (!(i ? l in t : wn.call(t, l))) return !1;
      }
      var p = a.get(e),
        f = a.get(t);
      if (p && f) return p == t && f == e;
      var d = !0;
      a.set(e, t), a.set(t, e);
      for (var y = i; ++u < s;) {
        var h = e[l = c[u]],
          v = t[l];
        if (n) var _ = i ? n(v, h, l, t, e, a) : n(h, v, l, e, t, a);
        if (!(void 0 === _ ? h === v || o(h, v, r, n, a) : _)) {
          d = !1;
          break;
        }
        y || (y = "constructor" == l);
      }
      if (d && !y) {
        var b = e.constructor,
          m = t.constructor;
        b == m || !("constructor" in e) || !("constructor" in t) || "function" == typeof b && b instanceof b && "function" == typeof m && m instanceof m || (d = !1);
      }
      return a.delete(e), a.delete(t), d;
    },
    Sn = ct(xe, "DataView"),
    xn = st,
    zn = ct(xe, "Promise"),
    Pn = ct(xe, "Set"),
    En = ct(xe, "WeakMap"),
    kn = Ue,
    In = qe,
    Dn = "[object Map]",
    Fn = "[object Promise]",
    Nn = "[object Set]",
    Rn = "[object WeakMap]",
    Tn = "[object DataView]",
    Mn = In(Sn),
    Un = In(xn),
    Cn = In(zn),
    Ln = In(Pn),
    $n = In(En),
    Vn = kn;
  (Sn && Vn(new Sn(new ArrayBuffer(1))) != Tn || xn && Vn(new xn()) != Dn || zn && Vn(zn.resolve()) != Fn || Pn && Vn(new Pn()) != Nn || En && Vn(new En()) != Rn) && (Vn = function (e) {
    var t = kn(e),
      r = "[object Object]" == t ? e.constructor : void 0,
      n = r ? In(r) : "";
    if (n) switch (n) {
      case Mn:
        return Tn;
      case Un:
        return Dn;
      case Cn:
        return Fn;
      case Ln:
        return Nn;
      case $n:
        return Rn;
    }
    return t;
  });
  var Bn = Ht,
    Gn = ar,
    Wn = yr,
    Jn = An,
    Kn = Vn,
    qn = vr,
    Xn = Mr,
    Yn = Qr,
    Hn = "[object Arguments]",
    Qn = "[object Array]",
    Zn = "[object Object]",
    eo = Object.prototype.hasOwnProperty;
  var to = function (e, t, r, n, o, a) {
      var i = qn(e),
        c = qn(t),
        s = i ? Qn : Kn(e),
        u = c ? Qn : Kn(t),
        l = (s = s == Hn ? Zn : s) == Zn,
        p = (u = u == Hn ? Zn : u) == Zn,
        f = s == u;
      if (f && Xn(e)) {
        if (!Xn(t)) return !1;
        i = !0, l = !1;
      }
      if (f && !l) return a || (a = new Bn()), i || Yn(e) ? Gn(e, t, r, n, o, a) : Wn(e, t, s, r, n, o, a);
      if (!(1 & r)) {
        var d = l && eo.call(e, "__wrapped__"),
          y = p && eo.call(t, "__wrapped__");
        if (d || y) {
          var h = d ? e.value() : e,
            v = y ? t.value() : t;
          return a || (a = new Bn()), o(h, v, r, n, a);
        }
      }
      return !!f && (a || (a = new Bn()), Jn(e, t, r, n, o, a));
    },
    ro = xr;
  var no = function e(t, r, n, o, a) {
      return t === r || (null == t || null == r || !ro(t) && !ro(r) ? t != t && r != r : to(t, r, n, o, e, a));
    },
    oo = no;
  var ao = te$1(function (e, t) {
    return oo(e, t);
  });
  const io = e => "group" === e.type,
    co = (e, t) => Object.values(e.context.layers).find(e => io(e) && e.props.children.value.includes(t)),
    so = function (e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
      return r.push(t.uuid), t.props.children.value.forEach(t => {
        const n = e.layers[t];
        io(n) ? so(e, n, r) : r.push(t);
      }), r;
    },
    uo = ["name", "locked", "mediaType"],
    lo = e => {
      const t = {};
      return Object.keys(e).forEach(r => {
        void 0 !== e[r] && (t[r] = e[r]);
      }), t;
    },
    po = (e, t) => {
      const r = {};
      return Object.keys(t).forEach(n => {
        if ("props" === n) {
          const n = e.props,
            o = t.props;
          Object.entries(o).forEach(e => {
            let [t, o] = e;
            const a = n[t],
              i = {};
            a.locked !== o.locked && (i.locked = o.locked), ao(a.meta, o.meta) || (i.meta = o.meta), ao(a.value, o.value) || (i.value = o.value), Object.keys(i).length && (r.props = r.props || {}, r.props[t] = i);
          });
        }
        if ("meta" === n) {
          const n = lo(e.meta),
            o = lo(t.meta);
          ((e, t) => {
            const {
                hidden: r,
                locked: n,
                type: o,
                ...a
              } = e,
              {
                hidden: i,
                locked: c,
                type: s,
                ...u
              } = t;
            return !!n == !!c && !!r == !!i && ao(a, u);
          })(n, o) || (r.meta = o);
        }
        "fallbackLayer" === n && (ao(e.fallbackLayer, t.fallbackLayer) || (r.fallbackLayer = t.fallbackLayer)), uo.includes(n) && e[n] !== t[n] && (r[n] = t[n]);
      }), r;
    },
    fo = (e, t) => {
      const r = {};
      return so(t, t.layers[t.projectGroupId]).forEach(n => {
        const o = t.layers[n];
        if (e.layers[n]) {
          const t = e.layers[n],
            i = po(t, o);
          var a;
          if (Object.keys(i).length) r.edit || (r.edit = {
            layers: []
          }), null === (a = r.edit.layers) || void 0 === a || a.push({
            ...i,
            uuid: n
          });
        } else {
          r.add || (r.add = {
            layers: []
          });
          if (n === t.projectGroupId) {
            var i;
            null === (i = r.add.layers) || void 0 === i || i.push({
              node: t.layers[n],
              parentId: Z$1
            });
          } else {
            var c;
            const e = co({
                context: t
              }, n),
              o = e.props.children.value.findIndex(e => e === n);
            null === (c = r.add.layers) || void 0 === c || c.push({
              index: o,
              parentId: e.uuid,
              node: t.layers[n]
            });
          }
        }
      }), Object.keys(e.layers).forEach(e => {
        var n;
        t.layers[e] || (r.remove || (r.remove = {
          layerIds: []
        }), null === (n = r.remove.layerIds) || void 0 === n || n.push(e));
      }), e.layout.height === t.layout.height && e.layout.width === t.layout.width || (r.edit = r.edit || {}, r.edit.layout = t.layout), r;
    };
  W$1(!1), W$1(!1);
  const Fo = (e, t) => {
      var r, n, o, a;
      e.context = e.context || {}, e.context.layers = e.context.layers || {};
      const i = [];
      null === (r = t.update.remove) || void 0 === r || null === (r = r.layerIds) || void 0 === r || r.forEach(t => {
        delete e.context.layers[t], i.push(t);
        const r = co(e, t);
        r && (r.props.children.value = r.props.children.value.filter(e => e !== t));
      }), null === (n = t.update.add) || void 0 === n || null === (n = n.layers) || void 0 === n || n.forEach(t => {
        let {
          parentId: r,
          index: n,
          node: o
        } = t;
        if (e.context.layers[o.uuid] = JSON.parse(JSON.stringify(o)), i.push(o.uuid), Z$1 === r) return void (e.context.projectGroupId = o.uuid);
        const a = e.context.layers[r];
        if (io(a)) {
          if (a.props.children.value.includes(o.uuid)) return;
          io(o) && o.props.children.value.forEach(t => {
            const r = co(e, t);
            r && r.uuid !== o.uuid && (r.props.children.value = r.props.children.value.filter(e => e !== t));
          }), void 0 === n ? a.props.children.value.push(o.uuid) : a.props.children.value.splice(n, 0, o.uuid);
        }
      }), null === (o = t.update.edit) || void 0 === o || null === (o = o.layers) || void 0 === o || o.forEach(t => {
        if (e.context.layers[t.uuid]) {
          const r = JSON.parse(JSON.stringify(t));
          e.context.layers[t.uuid] = ((e, t, r) => (Object.keys(t).forEach(n => {
            if ("props" === n) {
              const n = {};
              Object.keys(t.props).forEach(o => {
                n[o] = {
                  ...e.props[o],
                  ...t.props[o]
                };
              }), e.props = {
                ...e.props,
                ...n
              };
            } else e[n] = t[n];
          }), e))(e.context.layers[t.uuid], r);
        }
      }), null !== (a = t.update.edit) && void 0 !== a && a.layout && (e.context.layout = t.update.edit.layout);
    },
    No = e => G$1(e, t => {
      t.context = {
        layers: {}
      }, e.actions.forEach(e => {
        Fo(t, e);
      });
    }),
    Ro = e => ({
      id: H$1(),
      timestamp: Date.now(),
      ...e
    }),
    To = (e, t) => {
      var r;
      if (null !== (r = e.actions) && void 0 !== r && r.some(e => e.id === t.id)) return e;
      return G$1(e, e => {
        e.actions = e.actions || [];
        const r = Ro(t);
        e.actions.push(r), Fo(e, r);
      });
    },
    Mo = e => G$1(e, e => {
      e.actions.length && (e.actions.length -= 1, e.context = No($$1(e)).context);
    }),
    Lo = e => Object.keys(e).some(t => !!Object.keys(e[t] || {}).length),
    $o = (e, t) => {
      if (e.actions.length < t) throw new Error("Step is out of bounds");
      return e.actions.length === t + 1 ? e : $o(Mo(e), t);
    },
    Vo = (e, t) => {
      if (!t.previousActionId) return e;
      const r = e.actions.findIndex(e => {
        let {
          id: r
        } = e;
        return r === t.previousActionId;
      });
      if (-1 === r) return e;
      const n = e.actions.filter((e, t) => t > r);
      n.push(t);
      const o = n.sort((e, t) => e.timestamp === t.timestamp ? (console.warn("Two replay actions have the same timestamp, using id to sort them deterministically"), e.id.localeCompare(t.id)) : e.timestamp - t.timestamp),
        a = $o(e, r),
        {
          currentReplay: i
        } = o.reduce((e, r) => {
          if (r.id === t.id && (e.isExternalActionApplied = !0), e.isExternalActionApplied) {
            const t = To(e.currentReplay, r),
              n = e.currentReplay.context,
              o = fo(n, t.context);
            Lo(o) && (e.currentReplay = To(e.currentReplay, {
              id: r.id,
              timestamp: r.timestamp,
              previousActionId: e.currentReplay.actions[e.currentReplay.actions.length - 1].id,
              meta: r.meta,
              params: r.params,
              update: o
            }));
          } else e.currentReplay = To(e.currentReplay, r);
          return e;
        }, {
          currentReplay: a,
          isExternalActionApplied: !1
        });
      return i;
    };

  const storeKeys$2 = {
    lastSyncedReplay: 'v9LastSyncedReplay',
    miniappData: 'v9miniappData'
  };

  function receiveMessages$4(options) {
    if (isBootstrapAction(options.data)) {
      // NOTE: this needed only for v4, should be removed with v5-v4 migrations
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v9',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v9-v8'
      };
    }
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    if (isBootstrapAction(options.data)) {
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: options.data.payload.miniapp,
        key: storeKeys$2.miniappData
      });
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: options.data.payload.replay,
        key: storeKeys$2.lastSyncedReplay
      });
    }
    const lastSyncedReplay = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$2.lastSyncedReplay
    });
    if (lastSyncedReplay && isConfirmAction(options.data) && options.data.payload.action) {
      const updatedReplay = To(lastSyncedReplay, options.data.payload.action);
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: updatedReplay,
        key: storeKeys$2.lastSyncedReplay
      });
      options.data.payload.replay = updatedReplay;
    }
    return options;
  }

  const generateAction = options => {
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const lastSyncedReplay = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$2.lastSyncedReplay
    });
    const replay = options.data.payload.replay;
    if (replay && lastSyncedReplay) {
      const update = fo(lastSyncedReplay.context, options.data.payload.replay.context);
      const miniapp = options.getPayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        key: storeKeys$2.miniappData
      });
      if (miniapp && Lo(update)) {
        options.data.payload.action = Ro({
          previousActionId: lastSyncedReplay.actions[lastSyncedReplay.actions.length - 1].id,
          meta: {
            packageId: miniapp.packageId,
            source: 'miniapp',
            version: miniapp.appVersion
          },
          params: options.data.payload.replayActionParams || {},
          update
        });
        if (options.data.payload.action) {
          const updatedReplay = To(lastSyncedReplay, options.data.payload.action);
          options.storePayloadPerMiniapp({
            packageId: miniappPackageId,
            version: miniappVersion,
            payload: updatedReplay,
            key: storeKeys$2.lastSyncedReplay
          });
        }
      }
    }
    return options;
  };

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV8ToV9Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v8',
      migrateTo: 'v9'
    }, [generateAction]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV9ToV8Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v9',
      migrateTo: 'v8'
    }, [receiveMessages$4]);
  }

  const resolveIdReceiverMap = new Map();

  function receiveMessages$3(options) {
    const {
      data
    } = options;
    if (!isResolveMessageAction(data)) {
      return options;
    }
    const {
      resolveId
    } = data.payload;
    const receiver = resolveIdReceiverMap.get(resolveId);
    if (receiver) {
      resolveIdReceiverMap.delete(resolveId);
      return receiver(options);
    }
    return options;
  }

  const receiverRemoteSettings = payload => options => {
    const {
      data
    } = options;
    const {
      result,
      success
    } = data.payload;
    options.contextOptions.processMessage(data);
    const settings = success ? (result === null || result === void 0 ? void 0 : result.settings) || '{}' : '{}';
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.remoteSettingsResponse,
        payload: {
          ...payload,
          settings
        }
      }
    };
  };
  const registerRemoteSettings = options => {
    const {
      data
    } = options;
    if (isGetRemoteSettingsAction(data)) {
      const receiver = receiverRemoteSettings(data.payload);
      resolveIdReceiverMap.set(data.resolveId, receiver);
    }
    return options;
  };

  const receiverRefreshToken = options => {
    const {
      data
    } = options;
    const {
      result,
      success
    } = data.payload;
    if (!success || !result) {
      return {
        ...options,
        data: {
          ...options.data,
          action: V5ReceiveMessages.refreshTokenResponse,
          payload: {
            headers: {},
            error: true
          }
        }
      };
    }
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.refreshTokenResponse,
        payload: {
          headers: result.headers,
          error: false
        }
      }
    };
  };
  const registerRefreshToken = options => {
    const {
      data
    } = options;
    if (isRefreshTokenAction(data)) {
      resolveIdReceiverMap.set(data.resolveId, receiverRefreshToken);
    }
    return options;
  };

  const receiverFetchAlbums = sid => options => {
    const {
      data
    } = options;
    const {
      result,
      success,
      errorMessage
    } = data.payload;
    if (!success || !result || errorMessage) {
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...data.payload,
            result: undefined,
            success: false,
            errorMessage: errorMessage !== null && errorMessage !== void 0 ? errorMessage : 'unknown error'
          }
        }
      };
    }
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.fetchAlbumsResponse,
        payload: {
          sid,
          albums: result.albums
        }
      }
    };
  };
  const registerFetchAlbums = options => {
    const {
      data
    } = options;
    if (isFetchAlbumsAction(data)) {
      const receiver = receiverFetchAlbums(data.payload.sid);
      resolveIdReceiverMap.set(data.resolveId, receiver);
    }
    return options;
  };

  const receiverFetchMediaAssets = sid => options => {
    const {
      data
    } = options;
    const {
      result,
      success,
      errorMessage
    } = data.payload;
    if (!success || !result || errorMessage) {
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...data.payload,
            result: undefined,
            success: false,
            errorMessage: errorMessage !== null && errorMessage !== void 0 ? errorMessage : 'unknown error'
          }
        }
      };
    }
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.fetchMediaAssetsResponse,
        payload: {
          sid,
          assets: result.assets
        }
      }
    };
  };
  const registerFetchMediaAssets = options => {
    const {
      data
    } = options;
    if (isFetchMediaAssetsAction(data)) {
      const receiver = receiverFetchMediaAssets(data.payload.sid);
      resolveIdReceiverMap.set(data.resolveId, receiver);
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...data.payload.params
          }
        }
      };
    }
    return options;
  };

  const receiverRequestPermission = sid => options => {
    const {
      data
    } = options;
    const {
      success,
      errorMessage
    } = data.payload;
    if (!success || errorMessage) {
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...data.payload,
            success: false,
            errorMessage: errorMessage !== null && errorMessage !== void 0 ? errorMessage : 'rejected'
          }
        }
      };
    }
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.requestPermissionResponse,
        payload: {
          sid,
          result: 'granted'
        }
      }
    };
  };
  const registerRequestPermission = options => {
    const {
      data
    } = options;
    if (isRequestPermissionAction(data)) {
      const receiver = receiverRequestPermission(data.payload.sid);
      resolveIdReceiverMap.set(data.resolveId, receiver);
    }
    return options;
  };

  const receiverGenerateResultImage = sid => options => {
    const {
      data
    } = options;
    const {
      result,
      success,
      errorMessage
    } = data.payload;
    if (!success || !result || errorMessage) {
      return {
        ...options,
        data: {
          ...options.data,
          payload: {
            ...data.payload,
            result: undefined,
            success: false,
            errorMessage: errorMessage !== null && errorMessage !== void 0 ? errorMessage : 'unknown error'
          }
        }
      };
    }
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.generateResultImageResponse,
        payload: {
          sid,
          resource: result.resource
        }
      }
    };
  };
  const registerGenerateResultImage = options => {
    const {
      data
    } = options;
    if (isGenerateResultImageAction(data)) {
      const receiver = receiverGenerateResultImage(data.payload.sid);
      resolveIdReceiverMap.set(data.resolveId, receiver);
    }
    return options;
  };

  const receiverOpenFileChooser = options => {
    const {
      data
    } = options;
    const {
      result
    } = data.payload;
    options.contextOptions.processMessage(data);
    return {
      ...options,
      data: {
        ...options.data,
        action: V5ReceiveMessages.openFileChooserResponse,
        payload: {
          resources: (result === null || result === void 0 ? void 0 : result.resources) || []
        }
      }
    };
  };
  const registerOpenFileChooser = options => {
    const {
      data
    } = options;
    if (isOpenFileChooserAction(data)) {
      resolveIdReceiverMap.set(data.resolveId, receiverOpenFileChooser);
    }
    return options;
  };

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  function runV9ToV10Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v9',
      migrateTo: 'v10'
    }, [registerRemoteSettings, registerRefreshToken, registerFetchAlbums, registerFetchMediaAssets, registerRequestPermission, registerGenerateResultImage, registerOpenFileChooser]);
  }

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  function runV10ToV9Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v10',
      migrateTo: 'v9'
    }, [receiveMessages$3]);
  }

  function receiveMessages$2(options) {
    if (isBootstrapAction(options.data)) {
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v11',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v11-v10'
      };
    }
    return options;
  }

  const iconNameMap = new Map([['Icon16x9', 'Icon16x9Text'], ['Icon1x1', 'Icon1x1Text'], ['Icon2x1', 'Icon2x1Text'], ['Icon3x2', 'Icon3x2Text'], ['Icon3x4', 'Icon3x4Text'], ['IconAddPhoto', 'IconAddPhotoOutline'], ['IconAdmin', 'IconAdminFilled'], ['IconAdminFilled', 'IconAdminOutline'], ['IconAI', 'IconAi'], ['IconAIAvatar', 'IconAiAvatar'], ['IconAIGen', 'IconAiGen'], ['IconAIMusic', 'IconAiMusic'], ['IconAITools', 'IconAiTools'], ['IconAmazonLogo', 'IconAmazonSquare'], ['IconAmazonMonochrome', 'IconAmazon'], ['IconArrowCircleDownFilled', 'IconArrowDown'], ['IconArrowCircleLeftFilled', 'IconArrowLeft'], ['IconArrowCircleRightFilled', 'IconArrowRight'], ['IconArrowCircleUpFilled', 'IconArrowUp'], ['IconArrowDownLarge', 'IconArrowDown'], ['IconArrowDownLeftLarge', 'IconArrowDownLeft'], ['IconArrowDownOutline', 'IconArrowDown'], ['IconArrowDownRightLarge', 'IconArrowDownRight'], ['IconArrowDownSmall', 'IconArrowDown'], ['IconArrowLeftLarge', 'IconArrowLeft'], ['IconArrowLeftOutline', 'IconArrowLeft'], ['IconArrowLeftRight', 'IconArrowLeftRightFilled'], ['IconArrowLeftSmall', 'IconArrowLeft'], ['IconArrowRightLarge', 'IconArrowRight'], ['IconArrowRightOutline', 'IconArrowRight'], ['IconArrowRightSmall', 'IconArrowRight'], ['IconArrowShare', 'IconShareOutline'], ['IconArrowShareFilled', 'IconShareFilled'], ['IconArrowUpLarge', 'IconArrowUp'], ['IconArrowUpLeftLarge', 'IconArrowUpLeft'], ['IconArrowUpOutline', 'IconArrowUp'], ['IconArrowUpRightLarge', 'IconArrowUpRight'], ['IconArrowUpSmall', 'IconArrowUp'], ['IconBlog', 'IconBlogBanner'], ['IconBookmark', 'IconBookOpen'], ['IconBrilliant', 'IconDiamond'], ['IconBurger', 'IconMenu'], ['IconChevronCircleDownFilled', 'IconChevronDown'], ['IconChevronCircleLeftFilled', 'IconChevronLeft'], ['IconChevronCircleRightFilled', 'IconChevronRight'], ['IconChevronCircleUpFilled', 'IconChevronUp'], ['IconChevronDownLarge', 'IconChevronDown'], ['IconChevronDownOutline', 'IconChevronDown'], ['IconChevronDownSmall', 'IconChevronDown'], ['IconChevronLeftLarge', 'IconChevronLeft'], ['IconChevronLeftOutline', 'IconChevronLeft'], ['IconChevronLeftSmall', 'IconChevronLeft'], ['IconChevronRightLarge', 'IconChevronRight'], ['IconChevronRightOutline', 'IconChevronRight'], ['IconChevronRightSmall', 'IconChevronRight'], ['IconChevronUpLarge', 'IconChevronUp'], ['IconChevronUpOutline', 'IconChevronUp'], ['IconChevronUpSmall', 'IconChevronUp'], ['IconColorChooser', 'IconColorChooserColored'], ['IconCrop16x9', 'Icon16x9Landscape'], ['IconCrop3x2', 'Icon3x2Landscape'], ['IconCrop3x4', 'Icon3x4Portrait'], ['IconCrossCircleFilled', 'IconCross'], ['IconCrossCircleOutline', 'IconCross'], ['IconCrossLarge', 'IconCross'], ['IconCrossSmall', 'IconCross'], ['IconCrownCircleFilled', 'IconCrownFilled'], ['IconDepopLogo', 'IconDepopSquare'], ['IconDepopMonochrome', 'IconDepop'], ['IconDislike', 'IconDislikeOutline'], ['IconEbayMonochrome', 'IconEbaySquare'], ['IconEdit', 'IconEditOutline'], ['IconEditCircleFilled', 'IconEditFilled'], ['IconEffectsCircleOutline', 'IconEffects'], ['IconEmojiDislike', 'IconEmojiDislikeOutline'], ['IconEmojiLike', 'IconEmojiLikeOutline'], ['IconEmojiLove', 'IconEmojiLikeOutline'], ['IconEmojiLoveFilled', 'IconEmojiLikeFilled'], ['IconEtsy', 'IconEtsySquare'], ['IconEtsyMonochrome', 'IconEtsy'], ['IconExtractAudio', 'IconAudioExtract'], ['IconFBMarketplaceMonochrome', 'IconFBMarketplaceSquare'], ['IconFire', 'IconFireOutline'], ['IconFolder', 'IconFolderOutline'], ['IconFollowHashtagCircleFilled', 'IconFollowHashtagFilled'], ['IconFollowingHashtagCircleFilled', 'IconFollowingHashtagFilled'], ['IconFollowingUserCircleFilled', 'IconFollowingUserFilled'], ['IconFollowUserCircleFilled', 'IconProfileAddFilled'], ['IconGIFCircleFilled', 'IconGif'], ['IconGIF', 'IconGif'], ['IconHDPortrait', 'IconHdPortrait'], ['IconHeartAdd', 'IconHeartOutline'], ['IconImage', 'IconImageOutline'], ['IconImageBackground', 'IconMountain'], ['IconImageCircleFilled', 'IconImageFilled'], ['IconImageCircleOutline', 'IconImageOutline'], ['IconInfluencer', 'IconInfluencerOutline'], ['IconInfoCircleOutline', 'IconInfoOutline'], ['IconLazadaMonochrome', 'IconLazada'], ['IconLeftRightCircleOutline', 'IconArrowLeftRightOutline'], ['IconLike', 'IconLikeOutline'], ['IconLockCircleFilled', 'IconLockFilled'], ['IconLocked', 'IconLockOutline'], ['IconLockLarge', 'IconLockOutline'], ['IconLockLargeFilled', 'IconLockFilled'], ['IconLockSmall', 'IconLockOutline'], ['IconMeme', 'IconEmojiLikeOutline'], ['IconMercadoLibreMonochrome', 'IconMercadoLibre'], ['IconMercariMonochrome', 'IconMercari'], ['IconMessanger', 'IconMessenger'], ['IconMessangerColored', 'IconMessengerColored'], ['IconMinusCircleFilled', 'IconMinus'], ['IconMinusCircleOutline', 'IconMinus'], ['IconMinusLarge', 'IconMinus'], ['IconMinusSmall', 'IconMinus'], ['IconNotification', 'IconNotificationOutline'], ['IconPaginationLeftLarge', 'IconPaginationLeft'], ['IconPaginationRightLarge', 'IconPaginationRight'], ['IconPauseCircleFilled', 'IconPause'], ['IconPauseCircleOutline', 'IconPause'], ['IconPin', 'IconPinOutline'], ['IconPlayCircleFilled', 'IconPlay'], ['IconPlayCircleOutline', 'IconPlay'], ['IconPlusCircleFilled', 'IconPlus'], ['IconPlusCircleOutline', 'IconPlus'], ['IconPlusLarge', 'IconPlus'], ['IconPlusSmall', 'IconPlus'], ['IconPoshmarKMonochrome', 'IconPoshmarkSquare'], ['IconProfileAdd', 'IconProfileAddOutline'], ['IconProfileBlackList', 'IconProfileBlackListOutline'], ['IconProfileReport', 'IconProfileReportOutline'], ['IconQRShare', 'IconQRCode'], ['IconQuestion', 'IconQuestionOutline'], ['IconQuestionCircle', 'IconQuestionFilled'], ['IconQuestionCircleOutline', 'IconQuestionOutline'], ['IconResizeCircleFilled', 'IconResizeDiagonal'], ['IconResolutionX1', 'IconResolutionX1Outline'], ['IconResolutionX2', 'IconResolutionX2Outline'], ['IconResolutionX3', 'IconResolutionX3Outline'], ['IconResolutionX4', 'IconResolutionX4Outline'], ['IconRotateCircleFilled', 'IconRetain'], ['IconSend', 'IconSendOutline'], ['IconSendCircleFilled', 'IconSendFilled'], ['IconShare', 'IconShareOutline'], ['IconShopeeLogo', 'IconShopeeSquare'], ['IconAIBackground', 'IconAiBackground'], ['IconAIExpand', 'IconAiExpand'], ['IconAIBetaMiniapp', 'IconBetaMiniapp'], ['IconShopeeMonochrome', 'IconShopify'], ['IconShopifyLandscapeLogo', 'IconShopifyLandscape'], ['IconShopifyMonochrome', 'IconShopify'], ['IconShopifyPortraitLogo', 'IconShopifyPortrait'], ['IconShopifySquareLogo', 'IconShopifySquare'], ['IconSticker', 'IconStickerOutline'], ['IconStopCircleFilled', 'IconStop'], ['IconTextAI', 'IconAi'], ['IconTshirt', 'IconTShirt'], ['IconDetatch', 'IconUnlink'], ['IconAIReplace', 'IconAiReplace'], ['IconTextBrush', 'IconTextBend'], ['IconAIGenerator', 'IconAiGenerator'], ['IconAIVideoFilters', 'IconAiVideoFilters'], ['IconAIVideoGenerator', 'IconAiVideoGenerator'], ['IconAIVideoMotionStudio', 'IconAiVideoMotionStudio'], ['IconAIVideoStickerGenerator', 'IconAiVideoStickerGenerator'], ['IconTextSize100', 'IconTextSize100Percent'], ['IconTextSize25', 'IconTextSize25Percent'], ['IconTextSize30', 'IconTextSize30Percent'], ['IconTextSize50', 'IconTextSize50Percent'], ['IconTickLarge', 'IconTick'], ['IconTickLargeUnderline', 'IconTick'], ['IconTickSmall', 'IconTick'], ['IconUnlockCircleFilled', 'IconUnlockFilled'], ['IconUnlocked', 'IconUnlink'], ['IconUnlockLarge', 'IconUnlockOutline'], ['IconUnlockLargeFilled', 'IconUnlockFilled'], ['IconUnlinkFilled', 'IconUnlockFilled'], ['IconUnlockSmall', 'IconUnlock'], ['IconVintedMonochrome', 'IconVinted'], ['IconLensFlare', 'IconLensFlare']]);
  const migrateIconNames = options => {
    var _data$payload;
    const {
      data
    } = options;
    if (isShowNotifierMessageAction(data) && (_data$payload = data.payload) !== null && _data$payload !== void 0 && (_data$payload = _data$payload.options) !== null && _data$payload !== void 0 && _data$payload.icon) {
      const oldIconName = data.payload.options.icon;
      const newIconName = iconNameMap.get(oldIconName);
      if (newIconName) {
        data.payload.options.icon = newIconName;
      }
    }
    return options;
  };

  function runV10ToV11Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v10',
      migrateTo: 'v11'
    }, [migrateIconNames]);
  }
  function runV11ToV10Migrations(options) {
    return migrate(options, {
      migrateFrom: 'v11',
      migrateTo: 'v10'
    }, [receiveMessages$2]);
  }

  function e() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return e => t.reduce((e, t) => t(e), e);
  }
  function t(t, r) {
    let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
    return t.currentVersion === t.targetVersion || t.currentVersion !== r.migrateFrom ? t : e(...n, (o = r.migrateTo, e => ({
      ...e,
      data: {
        ...e.data,
        meta: {
          ...e.data.meta,
          replayVersion: o
        }
      }
    })))(t);
    var o;
  }
  var r = Symbol.for("immer-nothing"),
    n = Symbol.for("immer-draftable"),
    o = Symbol.for("immer-state");
  function i(e) {
    throw new Error("[Immer] minified error nr: ".concat(e, ". Full error at: https://bit.ly/3cXEKWf"));
  }
  var c = Object.getPrototypeOf;
  function s(e) {
    return !!e && !!e[o];
  }
  function u(e) {
    var _e$constructor;
    return !!e && (l(e) || Array.isArray(e) || !!e[n] || !!((_e$constructor = e.constructor) !== null && _e$constructor !== void 0 && _e$constructor[n]) || h(e) || m(e));
  }
  var f = Object.prototype.constructor.toString();
  function l(e) {
    if (!e || "object" != typeof e) return !1;
    const t = c(e);
    if (null === t) return !0;
    const r = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
    return r === Object || "function" == typeof r && Function.toString.call(r) === f;
  }
  function p(e, t) {
    0 === d(e) ? Object.entries(e).forEach(_ref => {
      let [r, n] = _ref;
      t(r, n, e);
    }) : e.forEach((r, n) => t(n, r, e));
  }
  function d(e) {
    const t = e[o];
    return t ? t.type_ : Array.isArray(e) ? 1 : h(e) ? 2 : m(e) ? 3 : 0;
  }
  function _(e, t) {
    return 2 === d(e) ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t);
  }
  function y(e, t, r) {
    const n = d(e);
    2 === n ? e.set(t, r) : 3 === n ? e.add(r) : e[t] = r;
  }
  function h(e) {
    return e instanceof Map;
  }
  function m(e) {
    return e instanceof Set;
  }
  function b(e) {
    return e.copy_ || e.base_;
  }
  function g(e, t) {
    if (h(e)) return new Map(e);
    if (m(e)) return new Set(e);
    if (Array.isArray(e)) return Array.prototype.slice.call(e);
    if (!t && l(e)) {
      if (!c(e)) {
        const t = Object.create(null);
        return Object.assign(t, e);
      }
      return {
        ...e
      };
    }
    const r = Object.getOwnPropertyDescriptors(e);
    delete r[o];
    let n = Reflect.ownKeys(r);
    for (let t = 0; t < n.length; t++) {
      const o = n[t],
        a = r[o];
      !1 === a.writable && (a.writable = !0, a.configurable = !0), (a.get || a.set) && (r[o] = {
        configurable: !0,
        writable: !0,
        enumerable: a.enumerable,
        value: e[o]
      });
    }
    return Object.create(c(e), r);
  }
  function v(e) {
    let t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    return P(e) || s(e) || !u(e) || (d(e) > 1 && (e.set = e.add = e.clear = e.delete = w), Object.freeze(e), t && p(e, (e, t) => v(t, !0))), e;
  }
  function w() {
    i(2);
  }
  function P(e) {
    return Object.isFrozen(e);
  }
  var O,
    S = {};
  function z(e) {
    const t = S[e];
    return t || i(0), t;
  }
  function j() {
    return O;
  }
  function F(e, t) {
    t && (z("Patches"), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t);
  }
  function D(e) {
    E(e), e.drafts_.forEach(A), e.drafts_ = null;
  }
  function E(e) {
    e === O && (O = e.parent_);
  }
  function N(e) {
    return O = {
      drafts_: [],
      parent_: O,
      immer_: e,
      canAutoFreeze_: !0,
      unfinalizedDrafts_: 0
    };
  }
  function A(e) {
    const t = e[o];
    0 === t.type_ || 1 === t.type_ ? t.revoke_() : t.revoked_ = !0;
  }
  function k(e, t) {
    t.unfinalizedDrafts_ = t.drafts_.length;
    const n = t.drafts_[0];
    return void 0 !== e && e !== n ? (n[o].modified_ && (D(t), i(4)), u(e) && (e = I(t, e), t.parent_ || M(t, e)), t.patches_ && z("Patches").generateReplacementPatches_(n[o].base_, e, t.patches_, t.inversePatches_)) : e = I(t, n, []), D(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e !== r ? e : void 0;
  }
  function I(e, t, r) {
    if (P(t)) return t;
    const n = t[o];
    if (!n) return p(t, (o, a) => V(e, n, t, o, a, r)), t;
    if (n.scope_ !== e) return t;
    if (!n.modified_) return M(e, n.base_, !0), n.base_;
    if (!n.finalized_) {
      n.finalized_ = !0, n.scope_.unfinalizedDrafts_--;
      const t = n.copy_;
      let o = t,
        a = !1;
      3 === n.type_ && (o = new Set(t), t.clear(), a = !0), p(o, (o, i) => V(e, n, t, o, i, r, a)), M(e, t, !1), r && e.patches_ && z("Patches").generatePatches_(n, r, e.patches_, e.inversePatches_);
    }
    return n.copy_;
  }
  function V(e, t, r, n, o, a, c) {
    if (s(o)) {
      const i = I(e, o, a && t && 3 !== t.type_ && !_(t.assigned_, n) ? a.concat(n) : void 0);
      if (y(r, n, i), !s(i)) return;
      e.canAutoFreeze_ = !1;
    } else c && r.add(o);
    if (u(o) && !P(o)) {
      if (!e.immer_.autoFreeze_ && e.unfinalizedDrafts_ < 1) return;
      I(e, o), t && t.scope_.parent_ || M(e, o);
    }
  }
  function M(e, t) {
    let r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
    !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && v(t, r);
  }
  var C = {
      get(e, t) {
        if (t === o) return e;
        const r = b(e);
        if (!_(r, t)) return function (e, t, r, _n$get) {
          const n = $(t, r);
          return n ? "value" in n ? n.value : (_n$get = n.get) === null || _n$get === void 0 ? void 0 : _n$get.call(e.draft_) : void 0;
        }(e, r, t);
        const n = r[t];
        return e.finalized_ || !u(n) ? n : n === x(e.base_, t) ? (R(e), e.copy_[t] = K(n, e)) : n;
      },
      has: (e, t) => t in b(e),
      ownKeys: e => Reflect.ownKeys(b(e)),
      set(e, t, r) {
        const n = $(b(e), t);
        if (n !== null && n !== void 0 && n.set) return n.set.call(e.draft_, r), !0;
        if (!e.modified_) {
          const n = x(b(e), t),
            c = n === null || n === void 0 ? void 0 : n[o];
          if (c && c.base_ === r) return e.copy_[t] = r, e.assigned_[t] = !1, !0;
          if (((a = r) === (i = n) ? 0 !== a || 1 / a == 1 / i : a != a && i != i) && (void 0 !== r || _(e.base_, t))) return !0;
          R(e), L(e);
        }
        var a, i;
        return e.copy_[t] === r && (void 0 !== r || t in e.copy_) || Number.isNaN(r) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = r, e.assigned_[t] = !0), !0;
      },
      deleteProperty: (e, t) => (void 0 !== x(e.base_, t) || t in e.base_ ? (e.assigned_[t] = !1, R(e), L(e)) : delete e.assigned_[t], e.copy_ && delete e.copy_[t], !0),
      getOwnPropertyDescriptor(e, t) {
        const r = b(e),
          n = Reflect.getOwnPropertyDescriptor(r, t);
        return n ? {
          writable: !0,
          configurable: 1 !== e.type_ || "length" !== t,
          enumerable: n.enumerable,
          value: r[t]
        } : n;
      },
      defineProperty() {
        i(11);
      },
      getPrototypeOf: e => c(e.base_),
      setPrototypeOf() {
        i(12);
      }
    },
    T = {};
  function x(e, t) {
    const r = e[o];
    return (r ? b(r) : e)[t];
  }
  function $(e, t) {
    if (!(t in e)) return;
    let r = c(e);
    for (; r;) {
      const e = Object.getOwnPropertyDescriptor(r, t);
      if (e) return e;
      r = c(r);
    }
  }
  function L(e) {
    e.modified_ || (e.modified_ = !0, e.parent_ && L(e.parent_));
  }
  function R(e) {
    e.copy_ || (e.copy_ = g(e.base_, e.scope_.immer_.useStrictShallowCopy_));
  }
  p(C, (e, t) => {
    T[e] = function () {
      return arguments[0] = arguments[0][0], t.apply(this, arguments);
    };
  }), T.deleteProperty = function (e, t) {
    return T.set.call(this, e, t, void 0);
  }, T.set = function (e, t, r) {
    return C.set.call(this, e[0], t, r, e[0]);
  };
  function K(e, t) {
    const r = h(e) ? z("MapSet").proxyMap_(e, t) : m(e) ? z("MapSet").proxySet_(e, t) : function (e, t) {
      const r = Array.isArray(e),
        n = {
          type_: r ? 1 : 0,
          scope_: t ? t.scope_ : j(),
          modified_: !1,
          finalized_: !1,
          assigned_: {},
          parent_: t,
          base_: e,
          draft_: null,
          copy_: null,
          revoke_: null,
          isManual_: !1
        };
      let o = n,
        a = C;
      r && (o = [n], a = T);
      const {
        revoke: i,
        proxy: c
      } = Proxy.revocable(o, a);
      return n.draft_ = c, n.revoke_ = i, c;
    }(e, t);
    return (t ? t.scope_ : j()).drafts_.push(r), r;
  }
  function W(e) {
    if (!u(e) || P(e)) return e;
    const t = e[o];
    let r;
    if (t) {
      if (!t.modified_) return t.base_;
      t.finalized_ = !0, r = g(e, t.scope_.immer_.useStrictShallowCopy_);
    } else r = g(e, !0);
    return p(r, (e, t) => {
      y(r, e, W(t));
    }), t && (t.finalized_ = !1), r;
  }
  var U = new class {
      constructor(e) {
        var _this = this;
        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.produce = (e, t, n) => {
          if ("function" == typeof e && "function" != typeof t) {
            const r = t;
            t = e;
            const n = this;
            return function () {
              let e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : r;
              for (var _len2 = arguments.length, o = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
                o[_key2 - 1] = arguments[_key2];
              }
              return n.produce(e, e => t.call(this, e, ...o));
            };
          }
          let o;
          if ("function" != typeof t && i(6), void 0 !== n && "function" != typeof n && i(7), u(e)) {
            const r = N(this),
              a = K(e, void 0);
            let i = !0;
            try {
              o = t(a), i = !1;
            } finally {
              i ? D(r) : E(r);
            }
            return F(r, n), k(o, r);
          }
          if (!e || "object" != typeof e) {
            if (o = t(e), void 0 === o && (o = e), o === r && (o = void 0), this.autoFreeze_ && v(o, !0), n) {
              const t = [],
                r = [];
              z("Patches").generateReplacementPatches_(e, o, t, r), n(t, r);
            }
            return o;
          }
          i(1);
        }, this.produceWithPatches = (e, t) => {
          if ("function" == typeof e) return function (t) {
            for (var _len3 = arguments.length, r = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
              r[_key3 - 1] = arguments[_key3];
            }
            return _this.produceWithPatches(t, t => e(t, ...r));
          };
          let r, n;
          return [this.produce(e, t, (e, t) => {
            r = e, n = t;
          }), r, n];
        }, "boolean" == typeof (e === null || e === void 0 ? void 0 : e.autoFreeze) && this.setAutoFreeze(e.autoFreeze), "boolean" == typeof (e === null || e === void 0 ? void 0 : e.useStrictShallowCopy) && this.setUseStrictShallowCopy(e.useStrictShallowCopy);
      }
      createDraft(e) {
        u(e) || i(8), s(e) && (e = function (e) {
          s(e) || i(10);
          return W(e);
        }(e));
        const t = N(this),
          r = K(e, void 0);
        return r[o].isManual_ = !0, E(t), r;
      }
      finishDraft(e, t) {
        const r = e && e[o];
        r && r.isManual_ || i(9);
        const {
          scope_: n
        } = r;
        return F(n, t), k(void 0, n);
      }
      setAutoFreeze(e) {
        this.autoFreeze_ = e;
      }
      setUseStrictShallowCopy(e) {
        this.useStrictShallowCopy_ = e;
      }
      applyPatches(e, t) {
        let r;
        for (r = t.length - 1; r >= 0; r--) {
          const n = t[r];
          if (0 === n.path.length && "replace" === n.op) {
            e = n.value;
            break;
          }
        }
        r > -1 && (t = t.slice(r + 1));
        const n = z("Patches").applyPatches_;
        return s(e) ? n(e, t) : this.produce(e, e => n(e, t));
      }
    }(),
    G = U.produce;
  U.produceWithPatches.bind(U), U.setAutoFreeze.bind(U), U.setUseStrictShallowCopy.bind(U), U.applyPatches.bind(U), U.createDraft.bind(U), U.finishDraft.bind(U);
  const X = 1e6,
    q = function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      return {
        value: "number" == typeof e ? Math.floor(e * X) / X : e,
        locked: t,
        meta: r
      };
    };
  function B(e) {
    const t = G(e.data, e => {
      const t = e => {
        if (function (e) {
          return "audio" === e.type || "video" === e.type;
        }(e)) {
          e.props.muted = q(!1);
        }
        e.fallbackLayer && "object" == typeof e.fallbackLayer && "type" in e.fallbackLayer && t(e.fallbackLayer);
      };
      Object.values(e.context.layers).forEach(t), e.actions.forEach(e => {
        var r;
        null === (r = e.update.add) || void 0 === r || null === (r = r.layers) || void 0 === r || r.forEach(e => {
          let {
            node: r
          } = e;
          return t(r);
        });
      });
    });
    return {
      ...e,
      data: t
    };
  }
  const H = 1e3;
  function J(e) {
    const t = Date.now() - e.data.actions.length * H;
    return G(e, e => {
      e.data.actions.forEach((r, n) => {
        const o = r;
        o.timestamp = t + n * H, o.previousActionId = n > 0 ? e.data.actions[n - 1].id : null;
      });
    });
  }
  const Q = new Map([["3.0.0", 300], ["3.1.0", 310], ["3.2.0", 320]]),
    Y = e => Q.get(e),
    Z = e(function (e) {
      return t(e, {
        migrateFrom: "3.0.0",
        migrateTo: "3.1.0"
      }, [B]);
    }, function (e) {
      return t(e, {
        migrateFrom: "3.1.0",
        migrateTo: "3.2.0"
      }, [J]);
    }),
    ee = e(function (e) {
      return t(e, {
        migrateFrom: "3.2.0",
        migrateTo: "3.1.0"
      }, []);
    }, function (e) {
      return t(e, {
        migrateFrom: "3.1.0",
        migrateTo: "3.0.0"
      }, []);
    }),
    te = (e, t) => {
      const r = e.meta.replayVersion;
      if (r === t) return e;
      const n = Y(r),
        o = Y(t);
      if (!n || !o) return console.error("Invalid version: ".concat(n ? t : r)), e;
      return (n < o ? Z : ee)({
        data: e,
        currentVersion: r,
        targetVersion: t
      }).data;
    };

  async function downgradeBootstrap(options) {
    if (isBootstrapAction(options.data)) {
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v12',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v12-v11'
      };
      const payload = options.data.payload;
      if (payload.replay) {
        const migratedReplay = await te(payload.replay, '3.0.0');
        payload.replay = migratedReplay;
      }
    }
    return options;
  }

  const createDummyReplayV3 = () => {
    return {
      actions: [],
      context: {
        layers: {},
        layout: {
          width: 0,
          height: 0
        },
        projectGroupId: ''
      },
      meta: {
        id: 'id',
        replayVersion: '3.0.0'
      },
      settings: {}
    };
  };

  const downgradeSyncContext = async options => {
    if (!isSyncContextAction(options.data)) {
      return options;
    }
    const payload = options.data.payload;
    if (payload.action) {
      const dummyReplay = createDummyReplayV3();
      const {
        withoutHistory,
        ...originalAction
      } = payload.action;
      dummyReplay.actions.push(originalAction);
      const migratedReplay = await te(dummyReplay, '3.0.0');
      const migratedAction = migratedReplay.actions.find(action => action.id === originalAction.id);
      if (migratedAction) {
        options.data.payload.action = {
          ...migratedAction,
          withoutHistory
        };
      }
    }
    return options;
  };
  const upgradeSyncContext = async options => {
    if (!isSyncContextAction(options.data)) {
      return options;
    }
    const payload = options.data.payload;
    if (payload.action) {
      const dummyReplay = createDummyReplayV3();
      const {
        withoutHistory,
        ...originalAction
      } = payload.action;
      dummyReplay.actions.push(originalAction);
      const migratedReplay = await te(dummyReplay, '3.1.0');
      const migratedAction = migratedReplay.actions.find(action => action.id === originalAction.id);
      if (migratedAction) {
        options.data.payload.action = {
          ...migratedAction,
          withoutHistory
        };
      }
    }
    return options;
  };

  const createDefaultReplay = () => {
    return {
      actions: [],
      context: {
        layers: {},
        layout: {
          width: 0,
          height: 0
        },
        projectGroupId: ''
      },
      meta: {},
      settings: {}
    };
  };

  const downgradeDownloadFile = async options => {
    if (!isDownloadFileAction(options.data)) {
      return options;
    }
    const layers = options.data.payload.layers;
    if (layers.length > 0) {
      const dummyReplay = createDefaultReplay();
      dummyReplay.context.layers = layers.reduce((acc, layer) => {
        acc[layer.uuid] = layer;
        return acc;
      }, {});
      const migratedReplay = await te(dummyReplay, '3.0.0');
      options.data.payload.layers = Object.values(migratedReplay.context.layers);
    }
    return options;
  };

  const runV11ToV12Migrations = options => migrate(options, {
    migrateFrom: 'v11',
    migrateTo: 'v12'
  }, [upgradeSyncContext]);
  const runV12ToV11Migrations = options => migrate(options, {
    migrateFrom: 'v12',
    migrateTo: 'v11'
  }, [downgradeBootstrap, downgradeSyncContext, downgradeDownloadFile]);

  const storeKeys$1 = {
    lastSyncedReplay: 'v12LastSyncedReplay',
    miniappData: 'v12miniappData',
    syncContextResolveIds: 'v12SyncContextResolveIds'
  };

  const enhanceReplayActions = async options => {
    if (!isSyncContextAction(options.data)) {
      return options;
    }
    const {
      payload
    } = options.data;
    if (payload.action) {
      payload.action.timestamp = Date.now();
      const {
        miniappVersion,
        miniappPackageId
      } = getMiniappPackageIdAndVersion(options);
      if (options.contextOptions.fakeContext) {
        const lastSyncedReplay = options.getPayloadPerMiniapp({
          packageId: miniappPackageId,
          version: miniappVersion,
          key: storeKeys$1.lastSyncedReplay
        });
        if (lastSyncedReplay) {
          options.contextOptions.internalContext.lastSyncedReplay = lastSyncedReplay;
        }
      }
      const lastSyncedReplay = options.contextOptions.fakeContext ? options.getPayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        key: storeKeys$1.lastSyncedReplay
      }) : options.contextOptions.internalContext.lastSyncedReplay;
      payload.action.previousActionId = lastSyncedReplay ? lastSyncedReplay.actions[lastSyncedReplay.actions.length - 1].id : null;
    }
    return options;
  };

  function receiveMessages$1(options) {
    if (isBootstrapAction(options.data)) {
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v13',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v13-v12'
      };
      const {
        miniappVersion,
        miniappPackageId
      } = getMiniappPackageIdAndVersion(options);
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: options.data.payload.miniapp,
        key: storeKeys$1.miniappData
      });
      options.storePayloadPerMiniapp({
        packageId: miniappPackageId,
        version: miniappVersion,
        payload: options.data.payload.replay,
        key: storeKeys$1.lastSyncedReplay
      });
    }
    return options;
  }

  const handleOutgoingAction = async options => {
    if (!isResolveMessageAction(options.data)) {
      return options;
    }
    const {
      resolveId
    } = options.data;
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const resolveIdsStore = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$1.syncContextResolveIds
    });
    if (!resolveIdsStore || !resolveIdsStore[resolveId] || !options.data.payload.success) {
      return options;
    }
    const outgoingAction = resolveIdsStore[resolveId];
    const lastSyncedReplay = options.getPayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys$1.lastSyncedReplay
    });
    const updatedReplay = Vo(lastSyncedReplay, outgoingAction);
    options.storePayloadPerMiniapp({
      packageId: miniappPackageId,
      version: miniappVersion,
      payload: updatedReplay,
      key: storeKeys$1.lastSyncedReplay
    });
    return options;
  };

  const handleIncomingAction = _ref => {
    let {
      fromEditor
    } = _ref;
    return async options => {
      if (!isSyncContextAction(options.data)) {
        return options;
      }
      const {
        payload
      } = options.data;
      if (!payload.action || !options.contextOptions.fakeContext) return options;
      const {
        miniappVersion,
        miniappPackageId
      } = getMiniappPackageIdAndVersion(options);
      if (fromEditor) {
        const lastSyncedReplay = options.getPayloadPerMiniapp({
          packageId: miniappPackageId,
          version: miniappVersion,
          key: storeKeys$1.lastSyncedReplay
        });
        options.contextOptions.internalContext.lastSyncedReplay = Vo(lastSyncedReplay, payload.action);
      } else {
        options.storePayloadPerMiniapp({
          packageId: miniappPackageId,
          version: miniappVersion,
          payload: {
            ...options.getPayloadPerMiniapp({
              packageId: miniappPackageId,
              version: miniappVersion,
              key: storeKeys$1.syncContextResolveIds
            }),
            [options.data.resolveId]: payload.action
          },
          key: storeKeys$1.syncContextResolveIds
        });
      }
      return options;
    };
  };

  const runV12ToV13Migrations = options => migrate(options, {
    migrateFrom: 'v12',
    migrateTo: 'v13'
  }, [handleIncomingAction({
    fromEditor: false
  }), handleOutgoingAction, enhanceReplayActions]);
  const runV13ToV12Migrations = options => migrate(options, {
    migrateFrom: 'v13',
    migrateTo: 'v12'
  }, [receiveMessages$1, handleIncomingAction({
    fromEditor: true
  })]);

  const resolveIdMap = new Map();
  const loadingIdMap = new Map();
  const migrateLoadingFlag = options => {
    const {
      data
    } = options;

    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    if (isConfigureUIAction(data) && 'loading' in data.payload) {
      resolveIdMap.set(data.resolveId, data.resolveId);
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      if (data.payload.loading === true) {
        if (loadingIdMap.size === 0) {
          data.payload.loadingId = '';
        }
      }
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      if (data.payload.loading === false && loadingIdMap.size > 0) {
        const [loadingId] = Array.from(loadingIdMap)[0];
        data.payload.loadingId = loadingId;
        loadingIdMap.delete(loadingId);
      }
    }
    return options;
  };

  function receiveMessages(options) {
    if (isBootstrapAction(options.data)) {
      // NOTE: this needed only for v4, should be removed with v5-v4 migrations
      options.data.payload = {
        ...options.data.payload,
        platformVersion: 'v14',
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        version: 'v14-v13'
      };
    }
    if (isResolveMessageAction(options.data)) {
      if (resolveIdMap.has(options.data.resolveId) && options.data.payload.result && typeof options.data.payload.result === 'object' && 'loadingId' in options.data.payload.result) {
        resolveIdMap.delete(options.data.resolveId);
        loadingIdMap.set(options.data.payload.result.loadingId, options.data.payload.result.loadingId);
      }
    }
    return options;
  }

  const storeKeys = {
    redirectToPackageIdResolveIds: 'v13RedirectToPackageIdResolveIds'
  };

  const isMobile = () => !isWebProtocol() && (isAndroidProtocol$1() || isIOSProtocol$1());

  const getResolveIdStore = options => {
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const payloadIdentity = {
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys.redirectToPackageIdResolveIds
    };
    const originalResolveIdsStore = options.getPayloadPerMiniapp(payloadIdentity);
    const resolveIdsStore = originalResolveIdsStore !== null && originalResolveIdsStore !== void 0 ? originalResolveIdsStore : new Set();
    if (!originalResolveIdsStore) {
      options.storePayloadPerMiniapp({
        ...payloadIdentity,
        payload: resolveIdsStore
      });
    }
    return resolveIdsStore;
  };
  const handleRedirectToPackageIdRequest = async options => {
    // We process only `redirect-to-package-id` for mobile platforms
    if (!isRedirectToPackageIdAction(options.data) || !isMobile()) {
      return options;
    }
    const resolveIdsStore = getResolveIdStore(options);
    resolveIdsStore.add(options.data.resolveId);
    return options;
  };

  const isPayloadWithCustomResult = payload => typeof payload.result === 'object' && payload.result !== null && 'result' in payload.result;
  const handleRedirectToPackageIdResult = options => {
    // Process only `resolve-message` from mobile platforms
    if (!isResolveMessageAction(options.data) || !isMobile()) {
      return options;
    }
    const {
      miniappVersion,
      miniappPackageId
    } = getMiniappPackageIdAndVersion(options);
    const payloadIdentity = {
      packageId: miniappPackageId,
      version: miniappVersion,
      key: storeKeys.redirectToPackageIdResolveIds
    };
    const resolveIdsStore = options.getPayloadPerMiniapp(payloadIdentity);

    // We didn't register this resolveId, so we can skip migration
    if (!resolveIdsStore || !resolveIdsStore.has(options.data.payload.resolveId)) {
      return options;
    }
    const payload = options.data.payload;
    if (isPayloadWithCustomResult(payload)) {
      options.data.payload.result = payload.result.result;
    }
    resolveIdsStore.delete(options.data.resolveId);
    return options;
  };

  // NOTE: This is applied to messages going to the platform, from a version lower than the platform.
  const runV13ToV14Migrations = options => migrate(options, {
    migrateFrom: 'v13',
    migrateTo: 'v14'
  }, [migrateLoadingFlag, handleRedirectToPackageIdRequest]);

  // NOTE: This is applied to messages coming from the platform, from a version greater than the SDK.
  const runV14ToV13Migrations = options => migrate(options, {
    migrateFrom: 'v14',
    migrateTo: 'v13'
  }, [receiveMessages, handleRedirectToPackageIdResult]);

  // The versioning scheme is not really reliable. Ofc we can try to parse incoming strings
  // but I think it just easier to map it to incremental numbers.
  const allMigrations = new Map([['v4', 4], ['v5', 5], ['v6', 6], ['v7', 7], ['v8', 8], ['v9', 9], ['v10', 10], ['v11', 11], ['v12', 12], ['v13', 13], ['v14', 14]]);
  let ValidationError = /*#__PURE__*/function (ValidationError) {
    ValidationError[ValidationError["INVALID_SOURCE"] = 0] = "INVALID_SOURCE";
    ValidationError[ValidationError["INVALID_TARGET"] = 1] = "INVALID_TARGET";
    ValidationError[ValidationError["NOT_SUPPORTED"] = 2] = "NOT_SUPPORTED";
    return ValidationError;
  }({});
  function validateMigrationVersions(source, target, direction, onInvalid) {
    const sourceIndex = allMigrations.get(source);
    const targetIndex = allMigrations.get(target);
    if (!sourceIndex) {
      onInvalid(ValidationError.INVALID_SOURCE, source);
      return false;
    }
    if (!targetIndex) {
      onInvalid(ValidationError.INVALID_TARGET, target);
      return false;
    }

    // client sdk > platform. Run down from 6 to 7 or up from 7 to 6
    // current implementation does not support this and corrupt data
    // in prod client apps shouldn't get version from the portal
    // but locally developers may install sdk with client version higher than the platform
    if (direction === 'up' && sourceIndex > targetIndex || direction === 'down' && sourceIndex < targetIndex) {
      onInvalid(ValidationError.NOT_SUPPORTED);
      return false;
    }
    return true;
  }
  const runMigrationsUp = asyncPipeline(runV4ToV5Migrations, runV5ToV6Migrations, runV6ToV7Migrations, runV7ToV8Migrations, runV8ToV9Migrations, runV9ToV10Migrations, runV10ToV11Migrations, runV11ToV12Migrations, runV12ToV13Migrations, runV13ToV14Migrations);
  const runMigrationsDown = asyncPipeline(runV14ToV13Migrations, runV13ToV12Migrations, runV12ToV11Migrations, runV11ToV10Migrations, runV10ToV9Migrations, runV9ToV8Migrations, runV8ToV7Migrations, runV7ToV6Migrations, runV6ToV5Migrations, runV5ToV4Migrations);

  if (!window.runPrivateAPIMigrations) {
    const createRunPrivateAPIMigrations = () => {
      /**
       * Internal map to store payloads per miniapp.
       * This is used to ensure that we can retrieve the payloads for each miniapp
       * when they are in the same process.
       * IMPORTANT::: storing only bootstrap payloads can be done via the bootstrap payload "miniapp"
       * property, cause yet in the "contextOptions" the internalContext is not yet updated with the miniapp
       * information. Any other payloads should be storing data using the "packageId" and "version"
       * properties, which are available in the "contextOptions.internalContext" object.
       */
      const payloadMapPerMiniapp = new Map();
      const storePayloadPerMiniapp = _ref => {
        let {
          packageId,
          version,
          key,
          payload
        } = _ref;
        payloadMapPerMiniapp.set("".concat(packageId, "-").concat(version, "-").concat(key), {
          packageId,
          version,
          payload
        });
      };
      const getPayloadPerMiniapp = _ref2 => {
        var _payloadMapPerMiniapp;
        let {
          packageId,
          version,
          key
        } = _ref2;
        return (_payloadMapPerMiniapp = payloadMapPerMiniapp.get("".concat(packageId, "-").concat(version, "-").concat(key))) === null || _payloadMapPerMiniapp === void 0 ? void 0 : _payloadMapPerMiniapp.payload;
      };
      const contextMap = new Map();
      const createFakeContextOptions = () => {
        return {
          processMessage: data => window.messageJSONHandler(JSON.stringify(data)),
          internalContext: {},
          fakeContext: true
        };
      };
      const getDefaultContextPerMiniapp = options => {
        // for fresher SDKs only
        if (options.contextOptions && !options.contextOptions.fakeContext) {
          return options.contextOptions;
        }
        const contextKey = options.data.sid;
        if (!contextMap.has(contextKey)) {
          contextMap.set(contextKey, createFakeContextOptions());
        }
        return contextMap.get(contextKey);
      };

      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      return async (data, _ref3, contextOptions // always can be undefined
      ) => {
        let {
          send,
          platformVersion,
          sdkVersion
        } = _ref3;
        const currentVersion = !send ? platformVersion : sdkVersion;
        const targetVersion = !send ? sdkVersion : platformVersion;

        // NOTE:: we need to fake the 'contextOptions' object cause the migration script will run for the older
        // versions of the SDK and the 'contextOptions' object will not be provided.

        contextOptions = getDefaultContextPerMiniapp({
          data,
          currentVersion,
          targetVersion,
          contextOptions,
          storePayloadPerMiniapp,
          getPayloadPerMiniapp
        });
        const miniapp = contextOptions.internalContext.miniapp;

        // NOTE::: suppress logging for fake miniapps and for default case, when miniapp yet is not set
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        const suppressLogging = !miniapp || miniapp.fakeMiniapp;
        const direction = send ? 'up' : 'down';
        const getMiniappSuffix = () => {
          if (!(miniapp !== null && miniapp !== void 0 && miniapp.packageId)) return '';
          const version = miniapp.appVersion ? "@".concat(miniapp.appVersion) : '';
          return " for the ".concat(miniapp.packageId).concat(version);
        };
        const logValidationError = suppressLogging ? noop : (errorCode, value) => {
          const suffix = getMiniappSuffix();
          if (errorCode === ValidationError.INVALID_SOURCE || errorCode === ValidationError.INVALID_TARGET) {
            console.error("Invalid migration version: ".concat(value, ". Migrations have been skipped").concat(suffix, "."));
          } else {
            console.error("Error: Executing the ".concat(direction, " migration from ").concat(currentVersion, " to ").concat(targetVersion, " is not supported. Please update the platform version. Migrations have been skipped").concat(suffix, "."));
          }
        };
        if (!validateMigrationVersions(currentVersion, targetVersion, direction, logValidationError)) {
          return data;
        }

        /**
         * We always want to up migrations down for messages that are received from the
         * platform (private API). This is to ensure that the SDK always works with the
         * latest version of the messages.
         */
        if (!send) {
          return (await runMigrationsDown({
            data,
            currentVersion,
            targetVersion,
            contextOptions,
            storePayloadPerMiniapp,
            getPayloadPerMiniapp
          })).data;
        }

        /**
         * We also want to run migrations up for messages that are being sent to the
         * platform (private API). This is because we might be loading the SDK in an older
         * version of the platform.
         */
        if (send) {
          return (await runMigrationsUp({
            data,
            currentVersion,
            targetVersion,
            contextOptions,
            storePayloadPerMiniapp,
            getPayloadPerMiniapp
          })).data;
        }
        return data;
      };
    };
    window.runPrivateAPIMigrations = createRunPrivateAPIMigrations();
  }

})();
